import { AdgoPage } from './app.po';

describe('Adgo App', () => {
    let page: AdgoPage;

    beforeEach(() => {
        page = new AdgoPage();
    });

    it('should display welcome message', () => {
        page.navigateTo();
        expect(page.getParagraphText()).toEqual('Welcome to Adgo!');
    });
});
