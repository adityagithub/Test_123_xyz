import { Component } from '@angular/core'

@Component({
  selector: 'fw-app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  constructor() {
  }
}
