import { OverlayModule } from '@angular/cdk/overlay';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FwSearchBarModule } from 'src/app/core/components';
import { MaterialModule } from 'src/app/core/material.module';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { SettingsMenuComponent } from './settings-menu/settings-menu.component';
import { ToolbarComponent } from './toolbar.component';
import { NotificationShortInfoComponent } from 'src/app/modules/user/notifications/short-info/short-info.component';
import { ConferenceControlsComponent } from 'src/app/modules/rooms/room/conference/controls/controls.component';

@NgModule({
  declarations: [
    ToolbarComponent,
    SettingsMenuComponent
  ],
  imports: [
    RouterModule,
    MaterialModule,
    FwCoreModule,
    FwSearchBarModule,
    NotificationShortInfoComponent,
    ConferenceControlsComponent
  ],
  exports: [
    ToolbarComponent,
    SettingsMenuComponent
  ],
  providers: [
  ]
})
export class ToolbarModule {
}
