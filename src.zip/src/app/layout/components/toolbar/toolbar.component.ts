import {
  AfterViewInit, ChangeDetectionStrategy, ChangeDetectorRef, Component, Inject,
  OnDestroy, OnInit, ViewChild, ViewEncapsulation
} from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { FlexibleConnectedPositionStrategy } from '@angular/cdk/overlay';
import { DOCUMENT } from '@angular/common';
import { MatMenuTrigger } from '@angular/material/menu';
import { LayoutConfig } from 'src/app/core/layoutConfig';
import { FwSidebarService } from 'src/app/core/components/sidebar/sidebar.service';
import { FwConfigService } from 'src/app/core/services/config.service';
import { RoomModel } from 'src/app/modules/rooms/room/room.models';
import { RoomService } from 'src/app/modules/rooms/room/room.service';
import { UserModel } from 'src/app/shared/models/user.model';
import { UserService } from 'src/app/shared/services/user.service';
import { EventModel } from 'src/app/shared/models/event.model';
import { EventService } from 'src/app/shared/services/event.service';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';

@Component({
  selector: 'fw-toolbar',
  templateUrl: './toolbar.component.html',
  styleUrls: ['./toolbar.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  encapsulation: ViewEncapsulation.None
})
export class ToolbarComponent implements OnInit, OnDestroy, AfterViewInit {

  resourceBaseUrl: string;
  horizontalNavbar: boolean;
  rightNavbar: boolean;
  hiddenNavbar: boolean;
  userStatusOptions: any[];
  docElement: any;
  overlayPositionStrategy: FlexibleConnectedPositionStrategy;
  isOpen: boolean;
  roomData: RoomModel;

  layoutSettings: LayoutConfig

  currentUser: UserModel;
  eventData: EventModel;
  showEventName: boolean = true;

  private _unsubscribeAll: Subject<any> = new Subject();

  @ViewChild('notificationMenuTrigger') notificationMenuTrigger: MatMenuTrigger;
  @ViewChild('userMenuTrigger') userMenuTrigger: MatMenuTrigger;

  constructor(
    private _appConfig: AppSettingService,
    private _fwConfigService: FwConfigService,
    private _ecSidebarService: FwSidebarService,
    @Inject(DOCUMENT) private document: any,
    private _changeDetectorRef: ChangeDetectorRef,
    private _eventService: EventService,
    private _userService: UserService,
    private _roomService: RoomService,
    private _signalrService: SignalrService
  ) {
    this.resourceBaseUrl = this._appConfig.settings.resourceBaseUrl;
  }

  ngAfterViewInit(): void {

  }

  ngOnInit(): void {
    this.docElement = document.documentElement;

    this._fwConfigService.config
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((settings: LayoutConfig) => {
        this.layoutSettings = settings;
        this.horizontalNavbar = settings.layout.navbar.position === 'top';
        this.rightNavbar = settings.layout.navbar.position === 'right';
        this.hiddenNavbar = settings.layout.navbar.hidden === true;
      });

    this._eventService.event$.pipe(takeUntil(this._unsubscribeAll)).subscribe(data => {
      this.eventData = data;
      this._changeDetectorRef.markForCheck();
    });

    this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe(data => {
      this.currentUser = data;
      this._changeDetectorRef.markForCheck();
    });

    this._roomService.roomDetails$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((room: RoomModel) => {
        this.roomData = room;
        this._changeDetectorRef.markForCheck();
      });
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  toggleSidebarOpen(key: any): void {
    this._ecSidebarService.getSidebar(key).toggleOpen();
  }

  search(value: any): void {
    console.log(value);
  }

  loadTest(): void {
    this._eventService.clearCache().subscribe(res => {
      this._eventService.getEvent().subscribe();
      this._eventService.getRooms().subscribe();
      this._eventService.getSchedules().subscribe();
      this._eventService.getSpeakers().subscribe();
      this._eventService.getSponsors().subscribe();
      this._eventService.getHandouts().subscribe();
      this._eventService.getAttendees().subscribe();
    });
  }

  startSignalr(): void {
    this._signalrService.startSignalR((res) => { console.log(res) });
  }

  stopSignalr(): void {
    this._signalrService.stopSignalR((res) => { console.log(res) });
  }

  toggleFullscreen(): void {
    if (this.docElement.requestFullscreen) {
      this.docElement.requestFullscreen();
    } else if (this.docElement.mozRequestFullScreen) {
      /* Firefox */
      this.docElement.mozRequestFullScreen();
    } else if (this.docElement.webkitRequestFullscreen) {
      /* Chrome, Safari and Opera */
      this.docElement.webkitRequestFullscreen();
    } else if (this.docElement.msRequestFullscreen) {
      /* IE/Edge */
      this.docElement.msRequestFullscreen();
    }

    if (document.fullscreenElement) {
      if (this.document.exitFullscreen) {
        this.document.exitFullscreen();
      } else if (this.document.mozCancelFullScreen) {
        /* Firefox */
        this.document.mozCancelFullScreen();
      } else if (this.document.webkitExitFullscreen) {
        /* Chrome, Safari and Opera */
        this.document.webkitExitFullscreen();
      } else if (this.document.msExitFullscreen) {
        /* IE/Edge */
        this.document.msExitFullscreen();
      }
    }
  }

  openNotificationMenu(): void {
    this.notificationMenuTrigger.openMenu();
    this.userMenuTrigger.closeMenu();
  }

  openUserMenu(): void {
    this.notificationMenuTrigger.closeMenu();
    this.userMenuTrigger.openMenu();
  }

  onRoomJoined(joined: boolean): void {
    this.showEventName = !(this.currentUser.isHostOrCoHost() && joined);
  }
}
