import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';
import * as _ from 'lodash';

import { AdgoConfigService } from 'app/core/services/config.service';
import { AdgoSidebarService } from 'app/core/components/sidebar/sidebar.service';

import { navigation } from 'app/mock-data/navigation/navigation';

@Component({
    selector     : 'toolbar',
    templateUrl  : './toolbar.component.html',
    styleUrls    : ['./toolbar.component.scss'],
    encapsulation: ViewEncapsulation.None
})

export class ToolbarComponent implements OnInit, OnDestroy
{
    horizontalNavbar: boolean;
    rightNavbar: boolean;
    hiddenNavbar: boolean;
    languages: any;
    navigation: any;
    
    dateNow = Date.now();

    private _unsubscribeAll: Subject<any>;

    constructor(
        private _adgoConfigService: AdgoConfigService,
        private _adgoSidebarService: AdgoSidebarService,
        private _translateService: TranslateService
    )
    {

        this.navigation = navigation;

        this._unsubscribeAll = new Subject();

        setInterval(() => {
            this.dateNow = Date.now();
        }, 1000);
    }


    ngOnInit(): void
    {
        this._adgoConfigService.config
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe((settings) => {
                this.horizontalNavbar = settings.layout.navbar.position === 'top';
                this.rightNavbar = settings.layout.navbar.position === 'right';
                this.hiddenNavbar = settings.layout.navbar.hidden === true;
            });
    }


    ngOnDestroy(): void
    {
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }


    toggleSidebarOpen(key): void
    {
        this._adgoSidebarService.getSidebar(key).toggleOpen();
    }

 
    search(value): void
    {
        console.log(value);
    }
}
