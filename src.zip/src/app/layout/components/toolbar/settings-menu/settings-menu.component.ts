import { Overlay, OverlayRef } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';
import {
  AfterViewInit, ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef, Inject,
  Input, OnDestroy, OnInit, TemplateRef, ViewChild, ViewContainerRef, ViewEncapsulation
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { equals } from 'ramda';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ConferenceService } from 'src/app/modules/rooms/room/conference/conference.service';
import { IMediaSettingsSerializable, MediaSettingsData } from 'src/app/modules/rooms/room/media-settings/media-settings.models';
import { EventModel } from 'src/app/shared/models/event.model';
import { UserModel } from 'src/app/shared/models/user.model';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import { MessageService } from 'src/app/shared/services/message.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { UserService } from 'src/app/shared/services/user.service';
import { UserSettings, UserSettingsGroup, UserSettingsKeys } from '../../right-panel/settings/settings.models';

@Component({
  selector: 'toolbar-settings-menu',
  templateUrl: './settings-menu.component.html',
  styleUrls: ['./settings-menu.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SettingsMenuComponent implements OnInit, OnDestroy, AfterViewInit {
  private _overlayRef: OverlayRef;
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  @Input() currentUser: UserModel;
  @Input() eventData: EventModel;
  panelOpened: boolean;

  userSettings: UserSettings[];
  notificationEnabled: boolean = true;

  @ViewChild('settingsMenuOrigin') private _settingsMenuOrigin: ElementRef<any>;
  @ViewChild('settingsMenuPanel') private _settingsMenuPanel: TemplateRef<any>;

  constructor(
    private _appConfig: AppSettingService,
    private _changeDetectorRef: ChangeDetectorRef,
    private _overlay: Overlay,
    private _viewContainerRef: ViewContainerRef,
    private _conferenceService: ConferenceService,
    private _sharedService: SharedService,
    private _matDialog: MatDialog,
    private _userService: UserService,
    private _messageService: MessageService,
    private _router: Router
  ) {

    this._userService.userSettings$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe(settings => {
        this.userSettings = settings;
        if(settings) {
          let setting = this.userSettings.find(s => s.key == UserSettingsKeys.disableAlert);
          if (setting) {
            this.notificationEnabled = !setting.value;
          }
        }
        this._changeDetectorRef.markForCheck();
      });
  }

  ngAfterViewInit(): void {

  }

  ngOnInit(): void {

  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
    if (this._overlayRef) {
      this.panelOpened = false;
      this._overlayRef.dispose();
    }
  }

  openPanel(): void {
    if (!this._settingsMenuPanel || !this._settingsMenuOrigin) {
      return;
    }

    if (this.panelOpened) {
      return;
    }

    if (!this._overlayRef) {
      this._createOverlay();
    }

    this._overlayRef.attach(new TemplatePortal(this._settingsMenuPanel, this._viewContainerRef));
    this.panelOpened = true;
  }

  closePanel(): void {
    this.panelOpened = false;
    this._overlayRef.detach();
    this._changeDetectorRef.markForCheck();
  }

  private _createOverlay(): void {
    this._overlayRef = this._overlay.create({
      hasBackdrop: true,
      backdropClass: 'fw-backdrop',
      scrollStrategy: this._overlay.scrollStrategies.block(),
      positionStrategy: this._overlay.position()
        .flexibleConnectedTo(this._settingsMenuOrigin.nativeElement)
        .withLockedPosition()
        .withDefaultOffsetX(54)
        .withPush(true)
        .withPositions([
          {
            originX: 'start',
            originY: 'bottom',
            overlayX: 'start',
            overlayY: 'bottom'
          },
          {
            originX: 'start',
            originY: 'top',
            overlayX: 'start',
            overlayY: 'bottom'
          },
          {
            originX: 'end',
            originY: 'bottom',
            overlayX: 'end',
            overlayY: 'top'
          },
          {
            originX: 'end',
            originY: 'top',
            overlayX: 'end',
            overlayY: 'bottom'
          }
        ])
    });

    this._overlayRef.backdropClick().subscribe(() => {
      this.panelOpened = false;
      this._overlayRef.detach();
      this._changeDetectorRef.markForCheck();
    });
  }


  openMediaSettingDialog(): void {
    import('src/app/modules/rooms/room/media-settings/media-settings.component').then(res => {

      let dialogData = new MediaSettingsData({} as MediaSettingsData);
      const obj = this._sharedService.getDataFromLocalStorage(MediaSettingsData.localStorageSettingKey);
      if (!equals(obj, {})) {
        dialogData = new MediaSettingsData(obj);
      }

      const dialogRef = this._matDialog.open(res.MediaSettingsDialogComponent, {
        panelClass: 'media-setting-dialog',
        data: dialogData
      });

      dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe((settings: IMediaSettingsSerializable) => {
        if (settings) {
          this._conferenceService.updateMediaSettings(settings);
        }
      });
    })
  }

  openManageAttendeesDialog(): void {
    import('src/app/modules/warroom/manage-attendees/manage-attendees.component').then(res => {
      this._matDialog.open(res.ManageAttendeeComponent, {
        panelClass: 'manage-attendees-dialog',
        data: {},
        disableClose: true,
      });
    })
  }

  openBreakoutRoomDialog(): void {
    import('src/app/modules/warroom/breakout/breakout.component').then(res => {
      this._matDialog.open(res.BreakoutRoomComponent, {
        panelClass: 'breakout-room-dialog',
        data: {},
        disableClose: true,
      });
    })
  }

  openBroadcastMessageDialog(): void {
    import('src/app/modules/warroom/broadcast-message/broadcast-message.component').then(res => {
      this._matDialog.open(res.BroadcastMessageComponent, {
        panelClass: 'broadcast-message-dialog',
        data: {},
        disableClose: true,
      });
    })
  }

  openRecordingListDialog(): void {
    import('src/app/modules/warroom/recordings/recording-list/recording-list.component').then(res => {
      let dialogRef = this._matDialog.open(res.FwRecordingListComponent, {
        panelClass: 'recprding-list-dialog',
        data: {},
        disableClose: true,
      });
      dialogRef.componentInstance.openInDialog = true;
    })
  }

  async updateNotificationAlertsSetting(value: boolean): Promise<void> {
    let setting = this.userSettings.find(s => s.key == UserSettingsKeys.disableAlert);
    if (setting == null) {
      setting = new UserSettings();
      setting.group = UserSettingsGroup.general;
      setting.key = UserSettingsKeys.disableAlert;
      setting.label = UserSettingsKeys.getLabel(setting.key);
    }
    setting.value = value;
    await this._userService.addUpdateUserSetting(setting);
  }

  openWarRoomDialog(): void {

    if (this._router.url.includes('/war-room')) {
      this._messageService.showInfoMessage('You are already in war room. Hence it can not be open in popup.');
      return;
    }

    import('src/app/modules/warroom/warroom.component').then(res => {
      let dialogRef = this._matDialog.open(res.WarroomComponent, {
        panelClass: 'warroom-dialog',
        data: {},
        disableClose: true,
      });
      dialogRef.componentInstance.openInDialog = true;
    })
  }

  openCustomizationDialog(): void {
    import('src/app/modules/warroom/customization/customization.component').then(res => {
      let dialogRef = this._matDialog.open(res.CustomizationComponent, {
        panelClass: 'customization-dialog',
        data: {},
        disableClose: true,
      });
      dialogRef.componentInstance.openInDialog = true;
    })
  }
}