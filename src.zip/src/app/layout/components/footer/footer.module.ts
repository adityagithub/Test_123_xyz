import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatMenuModule } from '@angular/material/menu';
import { MatBadgeModule } from '@angular/material/badge';
import { FwCoreModule } from 'src/app/core/fw.core.module';

import { FooterComponent } from './footer.component';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatSliderModule } from '@angular/material/slider';
import { ConferenceControlsComponent } from 'src/app/modules/rooms/room/conference/controls/controls.component';

@NgModule({
  declarations: [
    FooterComponent
  ],
  imports: [
    MatProgressBarModule,
    RouterModule,
    MatMenuModule,
    MatButtonModule,
    MatIconModule,
    MatToolbarModule,
    MatSliderModule,
    MatBadgeModule,
    FwCoreModule,
    ConferenceControlsComponent
  ],
  exports: [
    FooterComponent
  ]
})
export class FooterModule {
}
