import { Component, OnInit } from '@angular/core';
import { Subject, takeUntil } from 'rxjs';
import { ConferenceService } from 'src/app/modules/rooms/room/conference/conference.service';

@Component({
  selector: 'fw-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {
  private _unsubscribeAll: Subject<any> = new Subject();
  roomJoined: boolean;
  constructor(
    private _conferenceService: ConferenceService) {
  }

  ngOnInit(): void {
    this._conferenceService.onRoomJoined$.pipe(takeUntil(this._unsubscribeAll)).subscribe(joined => {
      if (joined) {
        this.roomJoined = joined;
      }
    });
    this._conferenceService.onRoomLeft$.pipe(takeUntil(this._unsubscribeAll)).subscribe(left => {
      if (left) {
        this.roomJoined = false;
      }
    });
  }
}
