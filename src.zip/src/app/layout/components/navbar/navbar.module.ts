import { NgModule } from '@angular/core';

import { AdgoSharedModule } from 'app/shared/shared.module';

import { NavbarComponent } from 'app/layout/components/navbar/navbar.component';
import { NavbarHorizontalStyle1Module } from 'app/layout/components/navbar/horizontal/horizontal.module';
import { NavbarVerticalStyle1Module } from 'app/layout/components/navbar/vertical/vertical.module';

@NgModule({
    declarations: [
        NavbarComponent
    ],
    imports     : [
        AdgoSharedModule,
        NavbarHorizontalStyle1Module,
        NavbarVerticalStyle1Module,
    ],
    exports     : [
        NavbarComponent
    ]
})
export class NavbarModule
{
}
