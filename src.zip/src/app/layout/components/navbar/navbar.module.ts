import { NgModule } from '@angular/core';

import { FwCoreModule } from 'src/app/core/fw.core.module';

import { NavbarComponent } from './navbar.component';
import { NavbarHorizontalStyleModule } from './horizontal/horizontal.module';
import { NavbarVerticalStyleModule } from './vertical/vertical.module';

@NgModule({
  declarations: [
    NavbarComponent
  ],
  imports: [
    FwCoreModule,
    NavbarHorizontalStyleModule,
    NavbarVerticalStyleModule
  ],
  exports: [
    NavbarComponent
  ]
})
export class NavbarModule {
}
