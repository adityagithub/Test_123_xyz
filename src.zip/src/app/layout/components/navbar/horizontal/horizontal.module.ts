import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

import { FwNavigationModule } from 'src/app/core/components';
import { FwCoreModule } from 'src/app/core/fw.core.module';

import { NavbarHorizontalStyleComponent } from './horizontal.component';

@NgModule({
  declarations: [
    NavbarHorizontalStyleComponent
  ],
  imports: [
    MatButtonModule,
    MatIconModule,

    FwCoreModule,
    FwNavigationModule
  ],
  exports: [
    NavbarHorizontalStyleComponent
  ]
})
export class NavbarHorizontalStyleModule {
}
