import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import { AdgoConfigService } from 'app/core/services/config.service';
import { AdgoNavigationService } from 'app/core/components/navigation/navigation.service';
import { AdgoSidebarService } from 'app/core/components/sidebar/sidebar.service';

@Component({
    selector     : 'navbar-horizontal',
    templateUrl  : './horizontal.component.html',
    styleUrls    : ['./horizontal.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class NavbarHorizontalStyle1Component implements OnInit, OnDestroy
{
    adgoConfig: any;
    navigation: any;

    // Private
    private _unsubscribeAll: Subject<any>;

    /**
     * Constructor
     *
     * @param {AdgoConfigService} _adgoConfigService
     * @param {AdgoNavigationService} _adgoNavigationService
     * @param {AdgoSidebarService} _adgoSidebarService
     */
    constructor(
        private _adgoConfigService: AdgoConfigService,
        private _adgoNavigationService: AdgoNavigationService,
        private _adgoSidebarService: AdgoSidebarService
    )
    {
        // Set the private defaults
        this._unsubscribeAll = new Subject();
    }

    // -----------------------------------------------------------------------------------------------------
    // @ Lifecycle hooks
    // -----------------------------------------------------------------------------------------------------

    /**
     * On init
     */
    ngOnInit(): void
    {
        // Get current navigation
        this._adgoNavigationService.onNavigationChanged
            .pipe(
                filter(value => value !== null),
                takeUntil(this._unsubscribeAll)
            )
            .subscribe(() => {
                this.navigation = this._adgoNavigationService.getCurrentNavigation();
            });

        // Subscribe to the config changes
        this._adgoConfigService.config
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe((config) => {
                this.adgoConfig = config;
            });
    }

    /**
     * On destroy
     */
    ngOnDestroy(): void
    {
        // Unsubscribe from all subscriptions
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();
    }
}
