import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Subject } from 'rxjs';
import { filter, takeUntil } from 'rxjs/operators';

import { FwConfigService } from 'src/app/core/services/config.service';
import { FwNavigationService } from 'src/app/core/components/navigation/navigation.service';
import { FwSidebarService } from 'src/app/core/components/sidebar/sidebar.service';
import { UserModel } from 'src/app/shared/models/user.model';
import { UserService } from 'src/app/shared/services/user.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { CustomizationService } from 'src/app/modules/warroom/customization/customization.service';

@Component({
  selector: 'navbar-horizontal-style',
  templateUrl: './horizontal.component.html',
  styleUrls: ['./horizontal.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class NavbarHorizontalStyleComponent implements OnInit, OnDestroy {
  user: UserModel;
  fwConfig: any;
  navigation: any;
  logoUrl: string;

  private _unsubscribeAll: Subject<any>;

  constructor(
    private _fwConfigService: FwConfigService,
    private _ecNavigationService: FwNavigationService,
    private _sidebarService: FwSidebarService,
    private _userService: UserService,
    private _sharedService: SharedService,
    private _customizationService: CustomizationService
  ) {
    this._unsubscribeAll = new Subject();
  }

  ngOnInit(): void {
    this._userService.user$.pipe(takeUntil(this._unsubscribeAll))
      .subscribe(u => {
        this.user = u;
      });

    this._customizationService.customization$.pipe(takeUntil(this._unsubscribeAll))
      .subscribe(res => {
        if (res) {
          this.logoUrl = res.logoImageUrl;
        }
      });

    this._ecNavigationService.onNavigationChanged
      .pipe(
        filter(value => value !== null),
        takeUntil(this._unsubscribeAll)
      )
      .subscribe(() => {
        this.navigation = this._ecNavigationService.getCurrentNavigation();
      });

    this._fwConfigService.config
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((config) => {
        this.fwConfig = config;
      });
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }
}
