import { NgModule } from '@angular/core';
import { MatBadgeModule } from '@angular/material/badge';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

import { FwNavigationModule } from 'src/app/core/components';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { NavbarVerticalStyleComponent } from './vertical.component';
import { MaterialModule } from 'src/app/core/material.module';

@NgModule({
  declarations: [
    NavbarVerticalStyleComponent
  ],
  imports: [
    MaterialModule,
    FwCoreModule,
    FwNavigationModule
  ],
  exports: [
    NavbarVerticalStyleComponent
  ]
})
export class NavbarVerticalStyleModule {
}
