import { Component, OnDestroy, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { delay, filter, take, takeUntil } from 'rxjs/operators';

import { FwConfigService } from 'src/app/core/services/config.service';
import { FwNavigationService } from 'src/app/core/components/navigation/navigation.service';
import { FwPerfectScrollbarDirective } from 'src/app/core/directives/fw-perfect-scrollbar/fw-perfect-scrollbar.directive';
import { FwSidebarService } from 'src/app/core/components/sidebar/sidebar.service';
import { UserService } from 'src/app/shared/services/user.service';
import { UserModel } from 'src/app/shared/models/user.model';
import { MatDialog } from '@angular/material/dialog';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import { EventService } from 'src/app/shared/services/event.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { CustomizationService } from 'src/app/modules/warroom/customization/customization.service';

@Component({
  selector: 'navbar-vertical-style',
  templateUrl: './vertical.component.html',
  styleUrls: ['./vertical.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class NavbarVerticalStyleComponent implements OnInit, OnDestroy {
  user: UserModel;
  fwConfig: any;
  navigation: any;
  resourceBaseUrl: string;
  logoUrl: string;
  trademarkText: string;

  private _fwPerfectScrollbar: FwPerfectScrollbarDirective;
  private _unsubscribeAll: Subject<any> = new Subject();

  constructor(
    private _dialog: MatDialog,
    private _fwConfigService: FwConfigService,
    private _ecNavigationService: FwNavigationService,
    private _ecSidebarService: FwSidebarService,
    private _userService: UserService,
    private _router: Router,
    private _settingService: AppSettingService,
    private _eventService: EventService,
    private _sharedService: SharedService,
    private _customizationService: CustomizationService
  ) {
    this.resourceBaseUrl = this._settingService.settings.resourceBaseUrl;
  }

  // eslint-disable-next-line accessor-pairs
  @ViewChild(FwPerfectScrollbarDirective, { static: true })
  set directive(theDirective: FwPerfectScrollbarDirective) {
    if (!theDirective) {
      return;
    }

    this._fwPerfectScrollbar = theDirective;

    this._ecNavigationService.onItemCollapseToggled
      .pipe(
        delay(500),
        takeUntil(this._unsubscribeAll)
      )
      .subscribe(() => {
        this._fwPerfectScrollbar.update();
      });

    this._router.events
      .pipe(
        filter((event) => event instanceof NavigationEnd),
        take(1)
      )
      .subscribe(() => {
        setTimeout(() => {
          this._fwPerfectScrollbar.scrollToElement('navbar .nav-link.active', -120);
        });
      }
      );
  }

  ngOnInit(): void {
    this._userService.user$.pipe(takeUntil(this._unsubscribeAll))
      .subscribe(u => {
        this.user = u;
      });

    this._router.events
      .pipe(
        filter((event) => event instanceof NavigationEnd),
        takeUntil(this._unsubscribeAll)
      ).subscribe(() => {
        if (this._ecSidebarService.getSidebar('navbar')) {
          this._ecSidebarService.getSidebar('navbar').close();
        }
      }
      );

    this._ecNavigationService.onNavigationChanged
      .pipe(
        filter(value => value !== null),
        takeUntil(this._unsubscribeAll)
      )
      .subscribe(() => {
        this.navigation = this._ecNavigationService.getCurrentNavigation();
      });

    this._fwConfigService.config
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((config) => {
        this.fwConfig = config;
      });

    this._customizationService.customization$.pipe(takeUntil(this._unsubscribeAll))
      .subscribe(res => {
        if (res) {
          this.logoUrl = res.logoImageUrl;
          this.trademarkText = res.trademarkText;
        }
      });
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  toggleSidebarOpened(): void {
    this._ecSidebarService.getSidebar('navbar').toggleOpen();
  }

  toggleSidebarFolded(): void {
    this._ecSidebarService.getSidebar('navbar').toggleFold();
  }

  openUserProfileDialog(): void {
    import('src/app/modules/user/profile-dialog/profile-dialog.component').then(res => {
      this._dialog.open(res.ProfileDialogComponent, {
        width: '600px',
        panelClass: 'profile-dialog-container',
        data: {},
        disableClose: true,
      });
    })
  }
}
