import { ChangeDetectorRef, Component, OnInit, ViewEncapsulation, Input, OnChanges, SimpleChanges } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { RoomModel } from 'src/app/modules/rooms/room/room.models';
import { UserModel } from 'src/app/shared/models/user.model';
import { EventModel, EventScheduleModel, EventSpeakerModel, EventSponsorModel } from 'src/app/shared/models/event.model';
import { EventService } from 'src/app/shared/services/event.service';

@Component({
  selector: 'summary-panel',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class SummaryPanelComponent implements OnInit, OnChanges {
  @Input() currentUser: UserModel;
  @Input() eventData: EventModel;
  @Input() roomData: RoomModel;
  speakers: EventSpeakerModel[];
  sponsors: EventSponsorModel[];
  schedules: EventScheduleModel[];

  speakersEnabled: boolean;
  sponsorsEnabled: boolean;

  private _unsubscribeAll: Subject<any> = new Subject();

  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _eventService: EventService) {

  }

  ngOnInit(): void {
    this._eventService.speakers$
      .pipe(takeUntil(this._unsubscribeAll)).subscribe(data => {
        this.speakers = data;
        this._changeDetectorRef.markForCheck();
      });

    this._eventService.sponsors$
      .pipe(takeUntil(this._unsubscribeAll)).subscribe(data => {
        this.sponsors = data;
        this._changeDetectorRef.markForCheck();
      });
  }

  ngOnChanges(changes: SimpleChanges): void {
    if ('eventData' in changes) {
      this.speakersEnabled = (this.eventData.settings.speakersEnabled || this.currentUser.isHostOrCoHost());
      this.sponsorsEnabled = (this.eventData.settings.sponsorsEnabled || this.currentUser.isHostOrCoHost());
    }
  }
}
