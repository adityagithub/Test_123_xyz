import { Injectable } from '@angular/core';
import { EnumRightPanelMenu, RightPanelMenu } from './right-panel.models';
import { RoomNavigationModel } from 'src/app/shared/models/event.model';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class RightPanelService {
  private _rightPanelFolded: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private _activeMenuItem: BehaviorSubject<EnumRightPanelMenu> = new BehaviorSubject(EnumRightPanelMenu.summary);

  constructor(
  ) {
  }

  getMenuItems(): RightPanelMenu[] {
    const menuItems = [
      {
        id: 1,
        name: 'About',
        icon: 'summary',
        systemName: 'summary',
        active: true
      },
      {
        id: 2,
        name: 'Schedules',
        icon: 'schedules',
        systemName: 'schedules',
        active: true
      },
      {
        id: 3,
        name: 'Live Chat',
        icon: 'chats',
        systemName: 'chats',
        active: true
      },
      {
        id: 4,
        name: 'Attendees',
        icon: 'attendees',
        systemName: 'attendees',
        active: true
      },
      {
        id: 7,
        name: 'Handouts',
        icon: 'handouts',
        systemName: 'handouts',
        active: true
      },
      {
        id: 8,
        name: 'My Matches',
        icon: 'matches',
        systemName: 'matches',
        active: false
      },
      {
        id: 9,
        name: 'Settings',
        icon: 'settings',
        systemName: 'settings',
        active: true
      }

    ];
    return menuItems;
  }

  prepareDropdownNavigations(data: RoomNavigationModel[]): RoomNavigationModel[] {
    const mainRooms = data.filter(x => x.roomType !== 'customroom');
    const customRooms = data.filter(x => x.roomType === 'customroom');
    const customRoomRoot = {
      roomId: 999,
      roomName: 'Custom Rooms',
      roomType: 'customroom',
      children: customRooms,
      displayOrder: null,
      isEnabled: true
    } as RoomNavigationModel;
    mainRooms.push(customRoomRoot);
    return mainRooms;
  }

  get onActiveMenuChange$(): Observable<EnumRightPanelMenu> {
    return this._activeMenuItem.asObservable();
  }

  setActiveMenu(menu: EnumRightPanelMenu) {
    this._activeMenuItem.next(menu);
  }

  setRightPanelFolded(folded: boolean) {
    this._rightPanelFolded.next(folded);
  }

  get rightPanelFolded$(): Observable<boolean> {
    return this._rightPanelFolded.asObservable();
  }
}
