
export class UserSettings {
    id: string;
    label: string;
    key: string;
    group: string;
    value: boolean;
}

export class UserSettingsKeys {
    static disableAlert = "app.general.notification.alerts";
    static rightPanelMinmized = "app.layout.rightpanel.minimized";
    static darkThemeEnabled = 'app.theme.dark.enabled';

    static keyLebelMap = new Map<string, string>([
        [UserSettingsKeys.disableAlert, "Disable Alert"],
        [UserSettingsKeys.rightPanelMinmized, "Right Panel Minimized"],
        [UserSettingsKeys.darkThemeEnabled, "Dark Theme"]
    ]);

    static getLabel(key: string): string {
        return UserSettingsKeys.keyLebelMap.get(key);
    }
}

export class UserSettingsKeysLabelMap {

}

export class UserSettingsGroup {
    static general = 'general';
    static theme = 'theme';
    static rightPanel = 'right panel';
}
