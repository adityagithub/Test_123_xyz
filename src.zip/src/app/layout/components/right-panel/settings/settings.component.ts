import { ChangeDetectionStrategy, ChangeDetectorRef, Component, HostBinding, OnDestroy, OnInit } from '@angular/core';
import { MaterialCssVarsService } from 'angular-material-css-vars';
import { Subject, takeUntil } from 'rxjs';
import { FwNavigationService } from 'src/app/core/components/navigation/navigation.service';
import { FwSidebarService } from 'src/app/core/components/sidebar/sidebar.service';
import { LayoutConfig } from 'src/app/core/layoutConfig';
import { FwConfigService } from 'src/app/core/services/config.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { UserSettings, UserSettingsGroup, UserSettingsKeys } from './settings.models';
import { UserService } from 'src/app/shared/services/user.service';
import { FwUtils } from 'src/app/core/utils';

@Component({
  selector: 'settings-panel',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class SettingsPanelComponent implements OnInit, OnDestroy {

  fwConfig: LayoutConfig;
  date: Date;
  events: any[];
  settings: UserSettings[];
  settingsMap: Record<string, UserSettings[]>;
  isDarkMode: boolean;
  theme: string;
  color: string;

  @HostBinding('class.bar-closed') barClosed: boolean;

  private _unsubscribeAll: Subject<any>;

  constructor(
    private _cdk: ChangeDetectorRef,
    private _fwConfigService: FwConfigService,
    private _ecNavigationService: FwNavigationService,
    private _ecSidebarService: FwSidebarService,
    private _materialCssVarsService: MaterialCssVarsService,
    private _sharedService: SharedService,
    private _userService: UserService
  ) {
    this.barClosed = true;
    this._unsubscribeAll = new Subject();
  }

  ngOnInit(): void {

    this._fwConfigService.config
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((config: LayoutConfig) => {
        this.fwConfig = config;
      });

    this._userService.userSettings$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe(settings => {

        if (!settings?.length) {
          settings = this.initAndGetDefaultSettings();
        }

        this.settingsMap = FwUtils.groupBy(settings, x => x.group);
        let setting = settings.find(s => s.key == UserSettingsKeys.darkThemeEnabled);
        if (setting) {
          this.themeModeChanged(setting.value);
        }

        this._cdk.markForCheck();
      });
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
    this._ecNavigationService.removeNavigationItem('custom-function');
  }

  toggleSidebarOpen(key): void {
    this._ecSidebarService.getSidebar(key).toggleOpen();
  }

  async settingValueChanged(item: UserSettings): Promise<void> {
    if (item.key == UserSettingsKeys.darkThemeEnabled) {
      this.themeModeChanged(item.value);
    }
    await this._userService.addUpdateUserSetting(item);
  }

  themeModeChanged(dark: boolean): void {
    this.isDarkMode = dark;
    this.fwConfig.colorTheme = dark ? 'isDarkTheme' : 'isLightTheme';
    this._fwConfigService.config = this.fwConfig;
    localStorage.setItem('color-theme', this.fwConfig.colorTheme);
    let docStyle = document.documentElement.style;
    this._sharedService.setStypeVariableInDocumentNode(dark, docStyle);
    if (dark) { this._materialCssVarsService.setDarkTheme(true); }
    else { this._materialCssVarsService.setDarkTheme(false); }
    this._cdk.markForCheck();
  }

  onColorChange($event: any) {
    this._materialCssVarsService.setPrimaryColor($event);
    this.fwConfig.colorCode = $event;
    localStorage.setItem('color-code', this.fwConfig.colorCode);
    this._fwConfigService.config = this.fwConfig;
    this._cdk.markForCheck();
  }

  private initAndGetDefaultSettings(): UserSettings[] {

    let settings = [
      {
        id: FwUtils.generateGUID(),
        group: UserSettingsGroup.general,
        key: UserSettingsKeys.disableAlert,
        label: UserSettingsKeys.getLabel(UserSettingsKeys.disableAlert),
        value: false
      },
      {
        id: FwUtils.generateGUID(),
        group: UserSettingsGroup.theme,
        key: UserSettingsKeys.darkThemeEnabled,
        label: UserSettingsKeys.getLabel(UserSettingsKeys.darkThemeEnabled),
        value: false
      }] as UserSettings[];

    settings.forEach(async s => await this._userService.addUpdateUserSetting(s));

    return settings;
  }
}
