import { ScrollingModule } from '@angular/cdk/scrolling';
import { NgModule } from '@angular/core';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { RouterModule } from '@angular/router';
import { PickerModule } from '@ctrl/ngx-emoji-mart';
import { FwProgressBarModule, FwSidebarModule } from 'src/app/core/components';
import { MaterialModule } from 'src/app/core/material.module';
import { AttendeesListComponent } from './attendees/attendee-list/attendee-list.component';
import { AttendeeListItemComponent } from './attendees/attendee-list/list-item/list-item.component';
import { AttendeesPanelComponent } from './attendees/attendees.component';
import { ChatAttachmentComponent } from './chat-panel/chat-attachment/chat-attachment.component';
import { ChatEmojiComponent } from './chat-panel/chat-emoji/chat-emoji.component';
import { ChatPanelComponent } from './chat-panel/chat-panel.component';
import { ChatPanelService } from './chat-panel/chat-panel.service';
import { ChatPanelViewComponent } from './chat-panel/chat-view/chat-view.component';
import { HandoutsListComponent } from './handouts/handouts-list/handouts-list.component';
import { HandoutsPanelComponent } from './handouts/handouts.component';
import { RightPanelComponent } from './right-panel.component';
import { ScheduleListComponent } from './schedule/schedule-list/schedule-list.component';
import { SchedulePanelComponent } from './schedule/schedule.component';
import { SettingsPanelComponent } from './settings/settings.component';
import { SummaryPanelComponent } from './summary/summary.component';
import { HandoutsListItemComponent } from './handouts/handouts-list/handouts-list-item/handouts-list-item.component';
import { DownloadChatModule } from 'src/app/modules/warroom/download-chat/download-chat.module';
import { PrivateRoomInviteComponent } from './attendees/attendee-list/private-room-invite/private-room-invite.component';
import { NgxSpinnerModule } from 'ngx-spinner';

@NgModule({
    declarations: [
        RightPanelComponent,
        SummaryPanelComponent,
        SchedulePanelComponent,
        ScheduleListComponent,
        ChatPanelComponent,
        ChatPanelViewComponent,
        ChatEmojiComponent,
        ChatAttachmentComponent,
        AttendeesPanelComponent,
        AttendeesListComponent,
        AttendeeListItemComponent,
        HandoutsPanelComponent,
        HandoutsListComponent,
        SettingsPanelComponent,
        HandoutsListItemComponent,
        PrivateRoomInviteComponent
    ],
    providers: [
        ChatPanelService
    ],
    exports: [
        RightPanelComponent,
        SummaryPanelComponent,
        SchedulePanelComponent,
        ScheduleListComponent,
        ChatPanelComponent,
        ChatPanelViewComponent,
        ChatEmojiComponent,
        ChatAttachmentComponent,
        AttendeesPanelComponent,
        AttendeesListComponent,
        AttendeeListItemComponent,
        HandoutsPanelComponent,
        HandoutsListComponent,
        SettingsPanelComponent,
        HandoutsListItemComponent
    ],
    imports: [
        MaterialModule,
        ScrollingModule,
        RouterModule,
        FwCoreModule,
        FwProgressBarModule,
        PickerModule,
        FwSidebarModule,
        DownloadChatModule,
        NgxSpinnerModule
    ]
})
export class RightPanelModule {
}
