import { ChangeDetectorRef, Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { FormControl } from '@angular/forms';
import { firstValueFrom, Observable, Subject } from 'rxjs';
import { map, startWith, takeUntil } from 'rxjs/operators';
import { RoomModel } from 'src/app/modules/rooms/room/room.models';
import { RoomService } from 'src/app/modules/rooms/room/room.service';
import { EventScheduleModel, RoomNavigationModel } from 'src/app/shared/models/event.model';
import { EventService } from 'src/app/shared/services/event.service';
import { RightPanelService } from '../../right-panel.service';

@Component({
  selector: 'schedule-list',
  templateUrl: './schedule-list.component.html',
  styleUrls: ['./schedule-list.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ScheduleListComponent implements OnInit {
  private _unsubscribeAll: Subject<any> = new Subject();
  private _schedules: EventScheduleModel[];
  private _roomData: RoomModel;
  private _allNavigations: RoomNavigationModel[];

  filteredSchedules: EventScheduleModel[];
  searchControl = new FormControl('');
  autoCompleteNavigations: RoomNavigationModel[];
  filteredAutoCompleteNavigations: Observable<RoomNavigationModel[]>;
  @Input() warroom: boolean;
  @Input() roomSection: boolean;
  @Input() eventSection: boolean;

  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _eventService: EventService,
    private _rightPanelService: RightPanelService,
    private _roomService: RoomService) { }

  ngOnInit(): void {
    this._registerEvents();
  }

  @Input() set roomData(value: RoomModel) {
    this._roomData = value;
    this._updateAutoCompleteNavigations();
  }

  get roomData(): RoomModel {
    return this._roomData;
  }

  @Input()
  set schedules(value: EventScheduleModel[]) {
    this._schedules = this.filteredSchedules = value;
    if (this.filteredSchedules) {
      this.filteredSchedules.forEach(async s => {
        s.roomUrl = await this._getJoinRoomUrl(s.roomId);
      });
    }
  }

  get schedules(): EventScheduleModel[] {
    return this._schedules;
  }

  private _filterSchedulesByTerm(search: string): void {
    const searchTerm = search.toLowerCase();
    if (searchTerm === '') {
      this.filteredSchedules = this.schedules;
    } else {
      this.filteredSchedules = this.schedules?.filter((s) => {
        return s.title.toLowerCase().includes(searchTerm) ||
          s.roomName.toLowerCase().includes(searchTerm) ||
          s.description?.toLowerCase().includes(searchTerm) ||
          s.scheduleStatus?.toLowerCase().includes(searchTerm) ||
          s.startDateUtc.toString().includes(searchTerm);
      });
    }
  }

  private _filter(value: string): RoomNavigationModel[] {
    const filterValue = value.toLowerCase();
    this._filterSchedulesByTerm(filterValue);
    return this.autoCompleteNavigations?.filter(option => option.roomName.toLowerCase().includes(filterValue) ||
      option.children?.some(m => m.roomName.toLowerCase().includes(filterValue)));
  }

  private _registerEvents(): void {
    this._eventService.navigations$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((data) => {
        this._allNavigations = data;
        this._updateAutoCompleteNavigations();
      });
  }

  private _updateAutoCompleteNavigations() {
    if (this._allNavigations) {
      this.autoCompleteNavigations = this._rightPanelService.prepareDropdownNavigations(this._allNavigations);
      if (this.roomData) {
        this.autoCompleteNavigations = this.autoCompleteNavigations.find(n => n.roomId === this.roomData.roomId)?.children;
      }
      this.filteredAutoCompleteNavigations = this.searchControl.valueChanges.pipe(
        startWith(''),
        map((value: string) => this._filter(value || ''))
      );
      this._changeDetectorRef.markForCheck();
    }
  }

  private async _getJoinRoomUrl(roomId: number): Promise<string> {
    const rooms = await firstValueFrom(this._eventService.rooms$);
    if (!rooms) { return ''; }
    const roomData = rooms.find(r => r.roomId === roomId);
    if (roomData) {
      return this._roomService.getRoomUrl(roomId, roomData.roomType, roomData.roomName);
    }
    const booths = rooms.flatMap(r => { return r.booths });
    const boothData = booths.find(r => r.roomId === roomId);
    const url = this._roomService.getRoomUrl(roomId, boothData?.roomType, boothData?.roomName, boothData?.parentRoomId);
    return url;
  }
}
