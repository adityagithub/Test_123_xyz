import { ChangeDetectorRef, Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { FwNavigationItem } from 'src/app/core/types';
import { RoomModel } from 'src/app/modules/rooms/room/room.models';
import { RoomService } from 'src/app/modules/rooms/room/room.service';
import { EventModel, EventScheduleModel } from 'src/app/shared/models/event.model';
import { EventService } from 'src/app/shared/services/event.service';

@Component({
  selector: 'schedule-panel',
  templateUrl: './schedule.component.html',
  styleUrls: ['./schedule.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class SchedulePanelComponent implements OnInit {
  roomData: RoomModel;
  eventData: EventModel
  roomSchedules: EventScheduleModel[];
  eventSchedules: EventScheduleModel[];
  roomNavigations: FwNavigationItem[];
  @Input() warroom: boolean = false;
  @Input() roomSection: boolean = false;
  @Input() eventSection: boolean = false;

  @Input() roomDataFromWarroom: RoomModel;

  private _unsubscribeAll: Subject<any> = new Subject();

  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _eventService: EventService,
    private _roomService: RoomService) {

  }

  ngOnInit(): void {
    this._eventService.event$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe(data => {
        this.eventData = data;
        this._changeDetectorRef.markForCheck();
      });
    this._eventService.schedules$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe(schedules => {
        this.eventSchedules = schedules?.sort((a, b) => new Date(b.startDateUtc).getTime() - new Date(a.startDateUtc).getTime()).sort((a, b) => { return ('' + b.scheduleStatus).localeCompare(a.scheduleStatus) });
        this.roomSchedules = this.eventSchedules?.filter(x => x.roomId === this.roomData?.roomId || x.parentRoomId === this.roomData?.roomId);
        this._changeDetectorRef.markForCheck();
      });
    this._roomService.roomDetails$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((room: RoomModel) => {
        if (this.warroom && this.roomSection) {
          return;
        }
        this.roomData = room;
        this.roomSchedules = this.eventSchedules?.filter(x => x.roomId === this.roomData?.roomId || x.parentRoomId === this.roomData?.roomId);
        this._changeDetectorRef.markForCheck();
      });

    if (this.warroom && this.roomSection && this.roomDataFromWarroom) {
      this.roomData = this.roomDataFromWarroom;
      this.roomSchedules = this.eventSchedules?.filter(x => x.roomId === this.roomData?.roomId || x.parentRoomId === this.roomData?.roomId);
      this._changeDetectorRef.markForCheck();
    }
  }
}
