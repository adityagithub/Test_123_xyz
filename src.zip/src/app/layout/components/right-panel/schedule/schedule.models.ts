
export interface RoomMap {
    key: number;
    value: string;
}
