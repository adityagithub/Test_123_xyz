import {
  AfterViewInit, ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ViewChild, ViewEncapsulation
} from '@angular/core';
import { MatTabGroup } from '@angular/material/tabs';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { FwConfigService } from 'src/app/core/services/config.service';
import { RoomModel } from 'src/app/modules/rooms/room/room.models';
import { RoomService } from 'src/app/modules/rooms/room/room.service';
import { NotificationModel } from 'src/app/shared/models/notifications.models';
import { NotificationsService } from 'src/app/shared/services/notifications.service';
import { UserModel, UserStatusEnum } from 'src/app/shared/models/user.model';
import { UserService } from 'src/app/shared/services/user.service';
import { EventModel } from 'src/app/shared/models/event.model';
import { ChatDataModel, ChatsDataModel, ChatSectionType, CommandType, SignalDataModel, SignalLevel } from 'src/app/shared/models/signalr.models';
import { EventService } from 'src/app/shared/services/event.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { ChatPanelService } from '../chat-panel/chat-panel.service';
import { EnumRightPanelMenu } from '../right-panel.models';
import { RightPanelService } from '../right-panel.service';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';

@Component({
  selector: 'attendees-panel',
  templateUrl: './attendees.component.html',
  styleUrls: ['./attendees.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AttendeesPanelComponent implements OnInit, AfterViewInit, OnDestroy {
  eventData: EventModel;
  roomData: RoomModel;
  selectedContact: UserModel;
  currentUser: UserModel;
  appConfig: any;
  profileActive: any;
  privateChatInputData: ChatsDataModel;
  userStatusMap = UserStatusEnum;
  isDownloadChatDisabled: boolean;
  chatBlockedWords: string[];
  resourceBaseUrl: string;

  @ViewChild('attendeesTabGroup') attendeesTabGroup: MatTabGroup;
  @Input() warroom: boolean = false;
  @Input() roomSection: boolean = false;
  @Input() eventSection: boolean = false;
  @Input() roomDataFromWarroom: RoomModel;

  private _unsubscribeAll: Subject<any> = new Subject();
  privateChatOpenSubject: Subject<void> = new Subject<void>();

  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _fwConfigService: FwConfigService,
    private _userService: UserService,
    private _eventService: EventService,
    private _roomService: RoomService,
    private _chatPanelService: ChatPanelService,
    private _signalrService: SignalrService,
    private _rightPanelService: RightPanelService,
    private _notificationService: NotificationsService,
    private _appSettingService: AppSettingService
  ) {
    this.resourceBaseUrl = this._appSettingService.settings.resourceBaseUrl;
  }

  ngOnInit(): void {
    this._fwConfigService.config
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((config: any) => {
        this.appConfig = config;
        this._changeDetectorRef.markForCheck();
      });

    this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe((user) => {
      this.currentUser = user;
      if(this.currentUser.userId == this.selectedContact?.userId){
        this.selectedContact = this.currentUser;
      }
      this.isDownloadChatDisabled = !this.eventData?.settings?.downloadChatsForAttendeeEnabled;
      if (this.currentUser?.isHostOrCoHost()) {
        this.isDownloadChatDisabled = false;
      }
      this._changeDetectorRef.markForCheck();
    });

    this._eventService.event$.pipe(takeUntil(this._unsubscribeAll)).subscribe(ev => {
      this.eventData = ev;
      this.chatBlockedWords = ev?.settings?.chatBlockingWords?.split(',');
      this.isDownloadChatDisabled = !this.eventData?.settings?.downloadChatsForAttendeeEnabled;
      if (this.currentUser?.isHostOrCoHost()) {
        this.isDownloadChatDisabled = false;
      }
      this._changeDetectorRef.markForCheck();
    });

    this._roomService.roomDetails$.pipe(takeUntil(this._unsubscribeAll))
      .subscribe((room: RoomModel) => {
        this.roomData = room;
        if(this.warroom && this.roomSection){
          this.roomData = this.roomDataFromWarroom;
        }        
        this._changeDetectorRef.markForCheck();
      });

    this._rightPanelService.onActiveMenuChange$.pipe(takeUntil(this._unsubscribeAll)).subscribe(data => {
      if (data === EnumRightPanelMenu.attendees && this.attendeesTabGroup) {
        this.attendeesTabGroup.selectedIndex = 0;
        this._changeDetectorRef.markForCheck();
      }
    });
  }

  ngAfterViewInit(): void {
    this._registerSignalrEvents();
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  showPrivateChatView(contact: UserModel): void {
    this.selectedContact = contact;
    const senderId = this.currentUser.userId;
    const receiverId = contact.userId;
    this._chatPanelService.getPrivateChats(senderId, receiverId)
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((privateChats) => {
        this.privateChatInputData = {
          receiverId,
          receiverName: '',
          receiverType: ChatSectionType.private,
          senderId,
          senderName: this.currentUser.getFullName(true),
          chats: privateChats.chats
        };
        this._changeDetectorRef.markForCheck();

        setTimeout(() => {
          this.privateChatOpenSubject.next();
        }, 200);
      });
  }

  hidePrivateChatView(): void {
    this.selectedContact = null;
    this._changeDetectorRef.markForCheck();
  }

  onPrivateChatSent(data: ChatDataModel): void {
    this._sendPrivateChatNotification(data.receiverId, data.message);
  }

  private _registerSignalrEvents(): void {
    this._signalrService.onNewMessage$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((s: ChatDataModel) => {
        if (s && s.chatSection === ChatSectionType.private) {
          this.privateChatInputData?.chats?.push(s);
          this._changeDetectorRef.markForCheck();
        }
      });
  }

  private _sendPrivateChatNotification(memberId: number, privateMessage: string): void {
    const notification = {
      notificationMessage: privateMessage,
      notificationSentBy: this.currentUser.userId,
      notificationSentFor: memberId.toString(),
      notificationType: 'invitation',
      eventId: this.eventData.eventId,
      virtualEventId: this.eventData.virtualEventId
    } as NotificationModel;

    this._notificationService.addUserNotification(notification)
      .pipe(takeUntil(this._unsubscribeAll)).subscribe(async res => {
        if (!res) {
          return;
        }
        const signalData = {
          receiverId: memberId,
          command: CommandType.newNotification,
          signalLevel: SignalLevel.person,
          data: {}
        } as SignalDataModel;
        await this._signalrService.sendSignal(signalData)
      });
  }

 }
