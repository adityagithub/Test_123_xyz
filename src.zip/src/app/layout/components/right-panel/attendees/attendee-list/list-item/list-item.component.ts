import {
  Component, Input, OnInit, Output, EventEmitter,
  OnChanges, SimpleChanges, ChangeDetectorRef
} from '@angular/core';
import { RoomModel } from 'src/app/modules/rooms/room/room.models';
import { UserModel, UserRoleAction, UserStatusEnum } from 'src/app/shared/models/user.model';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import { MessageService } from 'src/app/shared/services/message.service';

@Component({
  selector: 'member-list-item',
  templateUrl: './list-item.component.html'
})
export class AttendeeListItemComponent implements OnInit, OnChanges {
  isScreenPresenter: boolean;
  resourceBaseUrl: string;

  constructor(
    private _cdr: ChangeDetectorRef,
    private _settingService: AppSettingService,
    private _messageService: MessageService) {
    this.resourceBaseUrl = this._settingService.settings.resourceBaseUrl;
  }

  @Input() currentUser: UserModel;
  @Input() member: UserModel;
  @Input() section: 'room' | 'event';
  @Input() roleLevel: boolean;
  @Input() roomData: RoomModel;
  @Input() screenAppendId: number;
  @Output() openChat = new EventEmitter<UserModel>();
  @Output() onChangeRole = new EventEmitter<UserRoleAction>();
  @Output() onSetAudioMuted = new EventEmitter<boolean>();
  @Output() onSetVideoMuted = new EventEmitter<boolean>();
  @Output() onInvite = new EventEmitter<UserModel>();
  @Output() onHideFromScreen = new EventEmitter<boolean>();
  statusEnum = UserStatusEnum;
  privateChatEnabled: boolean;
  isPrivateOrBreakoutRoom: boolean;
  @Input() hideMicAndVideoIcon: boolean = false;

  ngOnInit(): void {
    this.member.unread = 0;
    this.isScreenPresenter = (this.member.userId - this.screenAppendId) > 0;
    this._cdr.markForCheck();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if ('roomData' in changes) {
      this.privateChatEnabled = this.currentUser.isHostOrCoHost() || this.roomData?.settings?.privateChatEnabled;
      this._cdr.markForCheck();
      if (this.roomData) {
        this.isPrivateOrBreakoutRoom = this.roomData.roomType === 'private' || this.roomData.roomType === 'breakout';
      }
    }
  }

  openPrivateChat() {
    this.openChat.emit(this.member);
  }

  changeUserRole(action: UserRoleAction) {
    this.onChangeRole.emit(action);
  }

  setAudioMuted(member: UserModel) {
    this.onSetAudioMuted.emit(member.hasAudio);
  }

  setVideoMuted(member: UserModel) {
    this.onSetVideoMuted.emit(member.hasVideo);
  }

  sendVideoCallLink(): void {
    this.onInvite.emit(this.member);
  }

  hideFromScreen(): void {
    this.onHideFromScreen.emit(true);
  }

  showOnScreen(): void {
    this.onHideFromScreen.emit(false);
  }

  openProfileView(member: UserModel) {
    if (member.isJoinFromGenericLink()) {
      this._messageService.showErrorMessage('Profile detail not found.');
      return;
    }
    let url = this.resourceBaseUrl + '/public/profile/' + btoa(member.userId.toString());
    window.open(url, "_blank");
  }

  getProfileViewUrl(vUserId: number): string {
    let url = this.resourceBaseUrl + '/public/profile/' + btoa(vUserId.toString());
    return url;
  }
}
