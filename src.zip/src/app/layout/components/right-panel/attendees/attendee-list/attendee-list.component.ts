import {
  AfterViewInit, ChangeDetectorRef, Component, EventEmitter, Input, OnChanges, OnDestroy, OnInit,
  Output, SimpleChanges, ViewChild, ViewEncapsulation
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatAccordion } from '@angular/material/expansion';
import { BehaviorSubject, combineLatest, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ConfirmDialogComponent } from 'src/app/core/components/confirm-dialog/confirm-dialog.component';
import { ConfirmDialogComponentData } from 'src/app/core/components/confirm-dialog/confirm.dialog.models';
import { ConferenceComponent } from 'src/app/modules/rooms/room/conference/conference.component';
import { ConferenceService } from 'src/app/modules/rooms/room/conference/conference.service';
import { PrivateRoomModel, RoomModel } from 'src/app/modules/rooms/room/room.models';
import { RoomService } from 'src/app/modules/rooms/room/room.service';
import { NotificationModel } from 'src/app/shared/models/notifications.models';
import { NotificationsService } from 'src/app/shared/services/notifications.service';
import { ChangeRoleRequest, UserModel, UserRoleAction, UserStatusEnum } from 'src/app/shared/models/user.model';
import { UserService } from 'src/app/shared/services/user.service';
import { EventModel } from 'src/app/shared/models/event.model';
import { ChatDataModel, ChatSectionType, CommandType, SignalDataModel, SignalLevel } from 'src/app/shared/models/signalr.models';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import { EventService } from 'src/app/shared/services/event.service';
import { MessageService } from 'src/app/shared/services/message.service';
import { RegistryService } from 'src/app/shared/services/registry.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { PrivateRoomInviteComponent } from './private-room-invite/private-room-invite.component';

@Component({
  selector: 'attendee-list',
  templateUrl: './attendee-list.component.html',
  styleUrls: ['./attendee-list.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class AttendeesListComponent implements OnInit, AfterViewInit, OnChanges, OnDestroy {
  private _members: UserModel[];
  private _unsubscribeAll: Subject<any> = new Subject();
  eventData: EventModel;
  @ViewChild('accordion') accordion: MatAccordion;

  @Input() section: 'room' | 'event';
  @Input() roomData: RoomModel;
  @Input() expand: boolean;
  @Input() selectedContact: UserModel;
  @Output() openChat = new EventEmitter<UserModel>();

  currentUser: UserModel;
  searchTerm: string;
  totalAttendeeCount: number = 0;
  actualTotalAttendeeCount: number = 0;
  screenAppendId: number;

  hostCohost: UserModel[];
  speakers: UserModel[];
  attendees: UserModel[];
  filteredHostCohost: UserModel[];
  filteredSpeakers: UserModel[];
  filteredAttendees: UserModel[];

  // eslint-disable-next-line no-useless-escape
  specialCharacterFormat = /[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
  resourceBaseUrl: string;
  eventMembers: UserModel[];

  userStatusType = UserStatusEnum;
  filters: {
    status$: BehaviorSubject<string>;
    query$: BehaviorSubject<string>;
  } = {
      status$: new BehaviorSubject('online'),
      query$: new BehaviorSubject('')
    };

  @Input() warroom: boolean;
  @Input() roomSection: boolean;
  @Input() eventSection: boolean;

  constructor(
    private _matDialog: MatDialog,
    private _changeDetectorRef: ChangeDetectorRef,
    private _messageService: MessageService,
    private _userService: UserService,
    private _notificationService: NotificationsService,
    private _eventService: EventService,
    private _roomService: RoomService,
    private _signalrService: SignalrService,
    private _confereceService: ConferenceService,
    private _settingService: AppSettingService,
    private _registryService: RegistryService
  ) {
    this.screenAppendId = this._confereceService.getScreePresenterAppendId();
    this.resourceBaseUrl = this._settingService.settings.resourceBaseUrl;
  }

  ngOnInit(): void {
    this._userService.user$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((user) => {
        this.currentUser = user;
        this._changeDetectorRef.markForCheck();
      });

    this._eventService.event$.pipe(takeUntil(this._unsubscribeAll))
      .subscribe((ev: EventModel) => {
        this.eventData = ev;
        this._changeDetectorRef.markForCheck();
      });

    if (this.section === 'event') {
      this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe(user => {
        if (user && this.members) {
          const userInList = this.members.find(m => m.userId === user.userId);
          if (userInList) {
            userInList.firstName = user.firstName;
            userInList.lastName = user.lastName;
            userInList.nickName = user.nickName;
            userInList.fullName = user.getFullName();
            this._changeDetectorRef.markForCheck();
          }
        }
      });
      this._eventService.attendees$.pipe(takeUntil(this._unsubscribeAll))
        .subscribe((att: UserModel[]) => {
          this.members = att; // ?.sort((a, b) => (a.firstName > b.firstName) ? 1 : -1);
          this._changeDetectorRef.markForCheck();
        });
    }

    if (this.section === 'room') {
      this._confereceService.members$.pipe(takeUntil(this._unsubscribeAll))
        .subscribe((att: UserModel[]) => {
          if (this.warroom && this.roomSection) {
            return;
          }
          this.members = att; // ?.sort((a, b) => (a.firstName > b.firstName) ? 1 : -1);
          this._changeDetectorRef.detectChanges();
        });

      if (this.warroom && this.roomSection) {
        this._eventService.attendees$.pipe(takeUntil(this._unsubscribeAll))
          .subscribe((att: UserModel[]) => {
            this.eventMembers = att; // ?.sort((a, b) => (a.firstName > b.firstName) ? 1 : -1);
            this.members = this.eventMembers.filter(f => f.roomId == this.roomData.roomId && f.status == UserStatusEnum.inacall)
            this._changeDetectorRef.markForCheck();
          });
        this._signalrService.onNewSignal$.pipe(takeUntil(this._unsubscribeAll)).subscribe(st => {
          if (st && st.command === CommandType.userStatusChanged) {
            const targetAtt = this.eventMembers.find(a => a.userId === st.data.userId);
            if (targetAtt) {
              targetAtt.status = st.data.status;
              targetAtt.roomId = st.data.roomId;
              targetAtt.roomName = this._eventService.findRoom(st.data.roomId)?.roomName;
              this.members = this.eventMembers.filter(f => f.roomId == this.roomData.roomId && f.status == UserStatusEnum.inacall)
              this._changeDetectorRef.markForCheck();
            }
          }
        });
      } else {
        this._eventService.attendees$.pipe(takeUntil(this._unsubscribeAll))
          .subscribe((att: UserModel[]) => {
            if (att && att.length) {
              this.members?.forEach(m => {
                let realtimeUpdatedOne = att.find(a => a.userId == m.userId);
                if (realtimeUpdatedOne) {
                  m.firstName = realtimeUpdatedOne.firstName;
                  m.lastName = realtimeUpdatedOne.lastName;
                  m.fullName = realtimeUpdatedOne.fullName;
                  m.nickName = realtimeUpdatedOne.nickName;
                }
              });
              this._changeDetectorRef.detectChanges();
            }
          });
      }
    }

    this._registerSignalrEvents();

    combineLatest([this.filters.status$, this.filters.query$])
      .subscribe(([status, query]) => {
        // Reset the filtered attendees
        this.filteredHostCohost = this.hostCohost;
        this.filteredSpeakers = this.speakers;
        this.filteredAttendees = this.attendees;

        // Filter by Status
        if (status && status !== 'all') {
          this.filteredHostCohost = this._filterMembersByStatus(this.filteredHostCohost, status);
          this.filteredSpeakers = this._filterMembersByStatus(this.filteredSpeakers, status);
          this.filteredAttendees = this._filterMembersByStatus(this.filteredAttendees, status);
        }

        // Filter by search query
        if (query) {
          this.filteredHostCohost = this.filteredHostCohost?.filter((s) => { return s.getFullName()?.toLowerCase()?.includes(query.toLowerCase()) });
          this.filteredSpeakers = this.filteredSpeakers?.filter((s) => { return s.getFullName()?.toLowerCase()?.includes(query.toLowerCase()) });
          this.filteredAttendees = this.filteredAttendees?.filter((s) => { return s.getFullName()?.toLowerCase()?.includes(query.toLowerCase()) });
        }
        this._calculateMembersCount();
        this._updateMeOnTopIndex();
        this._changeDetectorRef.markForCheck();
      });
  }

  private _filterMembersByStatus(members: UserModel[], status: string) {
    if (!members) { return; }
    if (status === 'online') {
      members = members.filter((a) => a.status !== UserStatusEnum.offline &&
        a.status !== UserStatusEnum.none &&
        a.status !== UserStatusEnum.away);
    } else if (status === 'offline') {
      members = members.filter((a) => a.status === UserStatusEnum.offline ||
        a.status === UserStatusEnum.none ||
        a.status === UserStatusEnum.away);
    } else {
      members = members.filter((a) => this.userStatusType[a.status] === status);
    }
    return members;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if ('expand' in changes) {
      if (this.accordion && this.expand) {
        this.accordion.openAll();
      }
    }
  }

  ngAfterViewInit(): void {
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  set members(value: UserModel[]) {
    this._members = value;
    if (this._members) {
      this._prepareUserGroupList();
      this.filterByStatus(this.filters.status$?.value);
    }
    this._changeDetectorRef.detectChanges();
  };

  private _prepareUserGroupList() {
    this.hostCohost = this.filteredHostCohost = this.members
      .filter((x) => { return this._userService.isHostOrCoHost(x) });
    this.speakers = this.filteredSpeakers = this.members
      .filter((x) => { return this._userService.isPresenter(x) });
    this.attendees = this.filteredAttendees = this.members
      .filter((x) => { return this._userService.isAttendee(x) });
  }

  private _updateMeOnTopIndex() {
    if (this.currentUser.isHostOrCoHost()) {
      this._spliceCurrentUserFirst(this.filteredHostCohost);
    } else if (this.currentUser.isPresenter()) {
      this._spliceCurrentUserFirst(this.filteredSpeakers);
    } else {
      this._spliceCurrentUserFirst(this.filteredAttendees);
    }
  }

  private _spliceCurrentUserFirst(userList: UserModel[]) {
    if (!userList || !userList.length) { return; }
    const me = userList.find(x => x.userId === this.currentUser.userId);
    if (me) {
      const myData = userList.splice(userList.indexOf(me), 1)[0];
      userList.unshift(myData);
    }
  }

  get members(): UserModel[] {
    return this._members;
  }

  openPrivateChat(contact: UserModel) {
    contact.unread = 0;
    this.openChat.emit(contact);
  }

  changeUserRole(action: UserRoleAction, attendee: UserModel) {
    const dialogRef = this._matDialog.open(ConfirmDialogComponent, {
      data: {
        Title: 'Are you sure?',
        Message: 'Change <b>' + attendee.firstName + '</b>\'s role to <b>' + this.getRoleDisplayName(action) + '</b>',
        CancelText: 'No',
        OkText: 'Yes'
      }
    });
    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
      if (result) {
        const request = { action, userId: attendee.userId } as ChangeRoleRequest;
        this._userService.changeUserRole(request).subscribe(s => {
          const signalDataModel = {
            receiverId: attendee.userId,
            command: CommandType.memberRoleChange,
            signalLevel: SignalLevel.event,
            data: { userRoles: s.updatedRoles }
          } as SignalDataModel;
          this._signalrService.sendSignal(signalDataModel).then(res => {
            this._eventService.getAttendees().pipe(takeUntil(this._unsubscribeAll)).subscribe();
          });
        });
      }
    });
  }

  async setAudioMuted(mute: boolean, attendee: UserModel): Promise<void> {

    if (this.currentUser.userId === attendee.userId) {
      mute == true ? await this.muteMic() : await this.unmuteMic();
      return;
    }
    if (attendee.isHostOrCoHost()) {
      this._messageService.showErrorMessage('You cannot mute/unmute host or cohost', true);
      return;
    }
    const res = await this._signalrService.sendMuteUnmuteSignal(mute, attendee);
    if (res) {
      // TODO
    }
  }

  async setVideoMuted(mute: boolean, attendee: UserModel): Promise<void> {
    if (this.currentUser.userId === attendee.userId) {
      mute == true ? await this.muteVideo() : await this.unmuteVideo();
      return;
    }
    if (attendee.isHostOrCoHost()) {
      this._messageService.showErrorMessage('You cannot mute/unmute host or cohost', true);
      return;
    }
    // TODO
  }

  private _calculateMembersCount(): void {
    this.totalAttendeeCount = 0;
    this.actualTotalAttendeeCount = 0;
    if (this.filteredHostCohost) {
      this.actualTotalAttendeeCount += this.filteredHostCohost.length;
      this.totalAttendeeCount += this.filteredHostCohost.filter(f => !f.hideFromScreen).length;
    }
    if (this.filteredSpeakers) {
      this.actualTotalAttendeeCount += this.filteredSpeakers.length;
      this.totalAttendeeCount += this.filteredSpeakers.filter(f => !f.hideFromScreen).length;
    }
    if (this.filteredAttendees) {
      this.actualTotalAttendeeCount += this.filteredAttendees.length;
      this.totalAttendeeCount += this.filteredAttendees.filter(f => !f.hideFromScreen).length;
    }
    this._changeDetectorRef.markForCheck();
  }

  clearSearch(): void {
    this.searchTerm = '';
    this.filterByQuery('')
  }

  private _registerSignalrEvents(): void {
    this._signalrService.onNewSignal$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe(async (signal: SignalDataModel) => {
        if (signal && signal.command === CommandType.userStatusChanged) {
          const eAttendee = this.members?.find(x => x.userId === signal.data.userId);
          if (eAttendee) {
            eAttendee.status = signal.data.status;
          }
          this.filterByStatus(this.filters.status$?.value)
          this._changeDetectorRef.markForCheck();
        }
        if (signal && signal.command === CommandType.attendeeLeft) {
          const leftAttendee = this.members?.find(a => a.userId === signal.data.userId);
          if (leftAttendee) {
            leftAttendee.raisedHand = false;
          }
        }
      });

    this._signalrService.onNewMessage$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((s: ChatDataModel) => {
        if (s && s.chatSection === ChatSectionType.private) {
          const att = this.members?.find(x => x.userId === s.senderId);
          if (att && (!this.selectedContact || this.selectedContact.userId !== att.userId)) {
            att.unread += 1;
          }
          this._changeDetectorRef.markForCheck();
        }
      });
  }

  inviteToPrivateRoom(member: UserModel): void {
    if (!member) { return; }
    this._matDialog.open(PrivateRoomInviteComponent, {
      data: {
        currentUser: this.currentUser,
        eventData: this.eventData,
        member: member
      }
    });
  }

  hideFromScreen(hide: boolean): void {

    const dialogRef = this._matDialog.open(ConfirmDialogComponent, {
      data: {
        Title: 'Please confirm',
        Message: hide ? 'Do you want to hide yourself from screen?' : 'Do you want to show yourself on screen?',
        CancelText: 'Cancel',
        OkText: 'Yes'
      }
    });
    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(async result => {
      if (result) {
        const signalDataModel = {
          receiverIds: [this.currentUser.userId],
          command: CommandType.hideFromScreen,
          signalLevel: SignalLevel.event,
          data: { extra: { hide: hide } }
        } as SignalDataModel;
        this._signalrService.sendSignal(signalDataModel).then(res => {
          this.currentUser.hideFromScreen = hide;
          this._confereceService.updateConfereceMember(this.currentUser);
        });
      }
    });
  }



  filterByQuery(search: string): void {
    this.filters.query$.next(search);
  }

  filterByStatus(status: any): void {
    this.filters.status$.next(status);
  }

  getRoleDisplayName(userAction: UserRoleAction): string {
    if (userAction === UserRoleAction.make_attendee) {
      return 'Attendee';
    } else if (userAction === UserRoleAction.make_cohost) {
      return 'Co-Host';
    } else if (userAction === UserRoleAction.make_presenter) {
      return 'Presenter';
    }
  }

  //#region

  //Mute unmute audio/video for Current User in case of host/cohost or presenter

  async muteVideo(): Promise<void> {
    const conference = this.getConfereceComponentRef();
    await conference?.muteVideo();
    this._changeDetectorRef.markForCheck();
  }

  async unmuteVideo(): Promise<void> {
    const conference = this.getConfereceComponentRef();
    await conference?.unmuteVideo();
    this._changeDetectorRef.markForCheck();
  }

  async muteMic(): Promise<void> {
    const conference = this.getConfereceComponentRef();
    await conference?.muteAudio();
    this._changeDetectorRef.markForCheck();
  }

  async unmuteMic(): Promise<void> {
    const conference = this.getConfereceComponentRef();
    await conference?.unmuteAudio();
    this._changeDetectorRef.markForCheck();
  }

  getConfereceComponentRef(): ConferenceComponent {
    return this._registryService.getComponent('conference') as ConferenceComponent;
  }

  //#endregion

}
