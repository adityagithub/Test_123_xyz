import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { NgxSpinnerService } from 'ngx-spinner';
import { Subject, takeUntil } from 'rxjs';
import { PrivateRoomModel } from 'src/app/modules/rooms/room/room.models';
import { RoomService } from 'src/app/modules/rooms/room/room.service';
import { EventModel } from 'src/app/shared/models/event.model';
import { NotificationModel } from 'src/app/shared/models/notifications.models';
import { ChatDataModel, ChatSectionType, CommandType, SignalDataModel, SignalLevel } from 'src/app/shared/models/signalr.models';
import { UserModel } from 'src/app/shared/models/user.model';
import { NotificationsService } from 'src/app/shared/services/notifications.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';

@Component({
  selector: 'fw-private-room-invite',
  templateUrl: './private-room-invite.component.html',
  styleUrls: ['./private-room-invite.component.scss']
})
export class PrivateRoomInviteComponent {

  isConfirmed: boolean;
  isSuccess: boolean;
  currentUser: UserModel;
  eventData: EventModel;
  member: UserModel;
  room: PrivateRoomModel;
  errorMessage: string;

  private _unsubscribeAll: Subject<any> = new Subject();

  constructor(
    public dialogRef: MatDialogRef<PrivateRoomInviteComponent>,
    @Inject(MAT_DIALOG_DATA) _data: any,
    private _roomService: RoomService,
    private _notificationService: NotificationsService,
    private _signalrService: SignalrService,
    private _spinnerService: NgxSpinnerService
  ) {
    this.member = _data.member;
    this.currentUser = _data.currentUser;
    this.eventData = _data.eventData;
    this.room = _data.room;
  }

  confirmInvite(ev: any): void {

    this.errorMessage = '';

    this._spinnerService.show();


    const privateRoomData = {
      participantIds: this.member.userId + ',' + this.currentUser.userId,
      roomName: 'Private Room',
      allowGuestInvite: true,
      allowHandouts: true,
      allowPollsAndSurvey: true,
      allowRecording: true
    } as PrivateRoomModel;

    this._roomService.createPrivateRoom(privateRoomData).pipe(takeUntil(this._unsubscribeAll)).subscribe(room => {
      if (room) {

        this.room = room;

        const invitationMessage = `I would like to invite you to a private room. Please join using this <a class="private_room_invite_link" data-roomid="${room.privateRoomId}">link</a>`;
        const notification = {
          notificationMessage: invitationMessage,
          notificationSentBy: this.currentUser.userId,
          notificationSentFor: this.member.userId.toString(),
          notificationType: 'invitation',
          eventId: this.eventData.eventId,
          virtualEventId: this.eventData.virtualEventId
        } as NotificationModel;

        this._notificationService.addUserNotification(notification)
          .pipe(takeUntil(this._unsubscribeAll)).subscribe(async notification => {

            try {

              if (!notification) { throw new Error('notification null'); };

              const message = {
                messageId: '',
                message: invitationMessage,
                messageType: 'text',
                createdDateUtc: new Date(),
                receiverId: this.member.userId,
                receiverName: this.member.getFullName(true),
                senderName: this.currentUser.getFullName(true),
                senderId: this.currentUser.userId,
                chatSection: ChatSectionType.private
              } as ChatDataModel;

              let res = await this._signalrService.sendMessage(message);

              if(!res) { throw new Error('res null'); }

              this.isConfirmed = true;
              this.isSuccess = true;
              this._spinnerService.hide();

              const signalData = {
                receiverId: this.member.userId,
                command: CommandType.newNotification,
                signalLevel: SignalLevel.person,
                data: {}
              } as SignalDataModel;
              await this._signalrService.sendSignal(signalData);

            } catch {
              this.isConfirmed = true;
              this.isSuccess = false;
              this._spinnerService.hide();
              this.errorMessage = 'Failed to send invitation to <b>' + this.member.getFullName() + '</b>' ;
            }
          });
      } else {
        this.isConfirmed = true;
        this.isSuccess = false;
        this._spinnerService.hide();
        this.errorMessage = 'Failed to send invitation to <b>' + this.member.getFullName() + '</b>' ;
      }
    });
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }
}
