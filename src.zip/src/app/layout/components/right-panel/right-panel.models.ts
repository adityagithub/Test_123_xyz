
export interface RightPanelMenu {
  id: number;
  name: string;
  systemName: string;
  icon: string;
  active: boolean
}

export type section = 'room' | 'event';

export enum EnumRightPanelMenu {
  'summary' = 'summary',
  'schedules' = 'schedules',
  'chats' = 'chats',
  'attendees' = 'attendees',
  'handouts' = 'handouts',
  'matches' = 'matches',
  'settings' = 'settings'
}
