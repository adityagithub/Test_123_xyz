import { AfterViewInit, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { FwSidebarService } from 'src/app/core/components/sidebar/sidebar.service';
import { RightPanelService } from './right-panel.service';
import { appAnimations } from 'src/app/core/animations';
import { FwProgressBarService } from 'src/app/core/components/progress-bar/progress-bar.service';
import { MenuItem } from 'src/app/shared/models/shared.model';
import { EventService } from 'src/app/shared/services/event.service';
import { UserService } from 'src/app/shared/services/user.service';
import { UserModel } from 'src/app/shared/models/user.model';
import { ConferenceService } from 'src/app/modules/rooms/room/conference/conference.service';
import { EventModel } from 'src/app/shared/models/event.model';
import { EnumRightPanelMenu } from './right-panel.models';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { ChatDataModel, ChatSectionType } from 'src/app/shared/models/signalr.models';
import { SharedService } from 'src/app/shared/services/shared.service';

@Component({
  selector: 'right-panel',
  templateUrl: './right-panel.component.html',
  styleUrls: ['./right-panel.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: appAnimations
})
export class RightPanelComponent implements OnInit, AfterViewInit, OnDestroy {
  menuItems: MenuItem[];
  selectedMenu: MenuItem;
  currentUser: UserModel;
  eventData: EventModel;
  roomJoined: boolean;
  unreadChatMessageCount: number = 0;
  unreadPrivateChatMessageCount: number = 0;
  panelOpened: boolean = false;

  private _unsubscribeAll: Subject<any> = new Subject();

  constructor(
    private _rightPanelService: RightPanelService,
    private _userService: UserService,
    private _sidebarService: FwSidebarService,
    private _progressbarService: FwProgressBarService,
    private _eventService: EventService,
    private _changeDetectorRef: ChangeDetectorRef,
    private _confereceService: ConferenceService,
    private _signalrService: SignalrService,
    private _sharedService: SharedService,
  ) {
  }

  ngOnInit(): void {
    this.unfoldSidebarTemporarily();

    this.menuItems = this._rightPanelService.getMenuItems();

    this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe(user => {
      this.currentUser = user;
      this._prepareRightPanelMenuItems();
      this._changeDetectorRef.markForCheck();
    });

    this._eventService.event$.pipe(takeUntil(this._unsubscribeAll)).subscribe(ev => {
      this.eventData = ev;
      this._prepareRightPanelMenuItems();
      this._changeDetectorRef.markForCheck();
    });

    this._confereceService.onRoomJoined$.pipe(takeUntil(this._unsubscribeAll)).subscribe(joined => {
      this.roomJoined = true;
      this._changeDetectorRef.markForCheck();
    });

    this._confereceService.onRoomLeft$.pipe(takeUntil(this._unsubscribeAll)).subscribe(left => {
      this.roomJoined = false;
      this._changeDetectorRef.markForCheck();
    });

    this._rightPanelService.onActiveMenuChange$.pipe(takeUntil(this._unsubscribeAll)).subscribe(data => {
      this.setActiveMenu(data);
      this._changeDetectorRef.markForCheck();
    });

    this._signalrService.onNewMessage$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((message: ChatDataModel) => {
        if ((this.selectedMenu.systemName != 'chats' || !this.panelOpened)
          && (message.chatSection == ChatSectionType.event || message.chatSection == ChatSectionType.room)) {
          this.unreadChatMessageCount += 1;
        } else if (this.selectedMenu.systemName != 'attendees' && message.chatSection == ChatSectionType.private) {
          this.unreadPrivateChatMessageCount += 1;
        }
      })

    const eventId = this._eventService.getEventId();

    this.loadRightPanelData(eventId);

    this._rightPanelService.rightPanelFolded$.pipe(takeUntil(this._unsubscribeAll)).subscribe(folded => {
      this.panelOpened = !folded;
      if( this.panelOpened && this.selectedMenu.systemName == 'chats'){
        this.unreadChatMessageCount = 0;
      }
      this._changeDetectorRef.markForCheck();
    });
  }

  private _prepareRightPanelMenuItems() {
    this.menuItems = this._rightPanelService.getMenuItems();
    let isHostOrCoHost = this.currentUser.isHostOrCoHost();
    if (this.eventData) {
      const scheduleMenu = this.menuItems.find(a => a.systemName === 'schedules');
      if (scheduleMenu) {
        scheduleMenu.active = this.eventData.settings.schedulesEnabled || isHostOrCoHost;
        scheduleMenu.name = this.eventData.settings.scheduleLabel;
      }
      const attendeeMenu = this.menuItems.find(a => a.systemName === 'attendees');
      if (attendeeMenu) {
        attendeeMenu.active = this.eventData.settings.peopleSectionEnabled || isHostOrCoHost;
        attendeeMenu.name = this.eventData.settings.attendeeLabel;
      }

      if (this.selectedMenu?.systemName == 'schedules') {
        this.selectedMenu.active = this.eventData.settings.schedulesEnabled || isHostOrCoHost;
        this.selectedMenu.name = this.eventData.settings.scheduleLabel;
      }
      if (this.selectedMenu?.systemName == 'attendees') {
        this.selectedMenu.active = this.eventData.settings.peopleSectionEnabled || isHostOrCoHost;
        this.selectedMenu.name = this.eventData.settings.attendeeLabel;
      }
    }
  }

  private setActiveMenu(data: EnumRightPanelMenu) {
    let menu = this.menuItems.find(m => m.systemName === data);
    if (!menu) {
      menu = this.menuItems[0];
    }
    this.selectedMenu = menu;
  }

  ngAfterViewInit(): void {

  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  foldSidebarTemporarily(): void {
    this._sidebarService.getSidebar('right-panel').foldTemporarily();
    this._rightPanelService.setRightPanelFolded(true);
  }

  unfoldSidebarTemporarily(): void {
    this._sidebarService.getSidebar('right-panel').unfoldTemporarily();
    this._rightPanelService.setRightPanelFolded(false);
  }

  toggleSidebarOpen(): void {
    this._sidebarService.getSidebar('right-panel').toggleOpen();
  }

  toggleContent(menu: MenuItem): void {
    const sidebar = this._sidebarService.getSidebar('right-panel');
    if (sidebar) {
      if (sidebar.folded) {
        this.unfoldSidebarTemporarily();
      } else {
        this.foldSidebarTemporarily();
      }
    }

    this.selectedMenu = menu;
    if (this.selectedMenu.systemName == 'chats') {
      this.unreadChatMessageCount = 0;
    }
    if (this.selectedMenu.systemName == 'attendees') {
      this.unreadPrivateChatMessageCount = 0;
    }
  }

  private loadRightPanelData(eventId: number) {
    if (eventId <= 0) { return; }

    this._eventService.getSpeakers()
      .pipe(takeUntil(this._unsubscribeAll)).subscribe(data => { });

    this._eventService.getHandouts()
      .pipe(takeUntil(this._unsubscribeAll)).subscribe(data => { });
  }
}
