import { ChangeDetectorRef, Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Subject, takeUntil } from 'rxjs';
import { RoomModel } from 'src/app/modules/rooms/room/room.models';
import { RoomService } from 'src/app/modules/rooms/room/room.service';
import { EventHandoutsModel } from 'src/app/shared/models/event.model';
import { EventService } from 'src/app/shared/services/event.service';

@Component({
  selector: 'handouts-panel',
  templateUrl: './handouts.component.html',
  styleUrls: ['./handouts.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class HandoutsPanelComponent implements OnInit {
  roomData: RoomModel;
  roomHandouts: EventHandoutsModel[];
  eventHandouts: EventHandoutsModel[];

  private _unsubscribeAll: Subject<any> = new Subject();

  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _eventService: EventService,
    private _roomService: RoomService) {

  }

  ngOnInit(): void {
    this._eventService.handouts$.pipe(takeUntil(this._unsubscribeAll))
      .subscribe((handouts: EventHandoutsModel[]) => {
        this.eventHandouts = handouts;
        this.roomHandouts = this.eventHandouts?.filter(h => h.roomIds?.includes(this.roomData?.roomId));
        this._changeDetectorRef.markForCheck();
      });
    this._roomService.roomDetails$.pipe(takeUntil(this._unsubscribeAll))
      .subscribe((room: RoomModel) => {
        this.roomData = room;
        this.roomHandouts = this.eventHandouts?.filter(h => h.roomIds?.includes(this.roomData?.roomId));
        this._changeDetectorRef.markForCheck();
      });
  }
}
