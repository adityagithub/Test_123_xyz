import { Component, Inject, Input, OnInit } from '@angular/core';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import { EventHandoutsModel } from 'src/app/shared/models/event.model';
import { MessageService } from 'src/app/shared/services/message.service';

@Component({
  selector: 'handouts-list-item',
  templateUrl: './handouts-list-item.component.html',
  styleUrls: ['./handouts-list-item.component.scss']
})
export class HandoutsListItemComponent implements OnInit {
  @Input() handout: EventHandoutsModel;
  downloading: boolean;

  constructor(
    private _appConfig: AppSettingService,
    public _messageService: MessageService) {

  }

  ngOnInit(): void {
  }

  downloadDocument(event: any) {
    event.preventDefault();
    const documentUrl = this.handout.filePath.replace('~', '');
    const downloadUrl = this._appConfig.settings.resourceBaseUrl + documentUrl;
    this.downloading = true;
    fetch(downloadUrl)
      .then(resp => resp.blob())
      .then(blob => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = this.handout.fileName;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        this.downloading = false;
      })
      .catch(() => {
        this.downloading = false;
        this._messageService.showErrorMessage('Sorry! An error occurred while downloading the file, please try again...')
      });
  };

  getDoctypeMapping(extension: string): string {
       if(extension.match(/\.(jpg|jpeg|png|gif)$/i)) return 'img';
       if(extension.match(/\.(pdf)$/i)) return 'pdf';
       if(extension.match(/\.(txt|rtf)$/i)) return 'txt';
       if(extension.match(/\.(doc|docx)$/i)) return 'doc';
       if(extension.match(/\.(xls|xlsx)$/i)) return 'xls';
       if(extension.match(/\.(ppt|pptx)$/i)) return 'ppt';
       if(extension.match(/\.(7z|arj|rar|gz|tar|z|zip)$/i)) return 'zip';
       if(extension.match(/\.(csv)$/i)) return 'csv';
       return 'file'
  }
}
