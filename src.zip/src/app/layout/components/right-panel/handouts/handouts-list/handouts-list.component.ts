import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Inject, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable, Subject } from 'rxjs';
import { appAnimations } from 'src/app/core/animations';
import { RoomModel } from 'src/app/modules/rooms/room/room.models';
import { EventHandoutsModel, RoomNavigationModel } from 'src/app/shared/models/event.model';
import { EventService } from 'src/app/shared/services/event.service';
import { RightPanelService } from '../../right-panel.service';
import { takeUntil, map, startWith } from 'rxjs/operators';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';

@Component({
  selector: 'handouts-list',
  templateUrl: './handouts-list.component.html',
  styleUrls: ['./handouts-list.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: appAnimations
})
export class HandoutsListComponent implements OnInit {
  private _roomData: RoomModel;
  private _handouts: EventHandoutsModel[];
  private _allNavigations: RoomNavigationModel[];

  filteredHandouts: EventHandoutsModel[];
  searchControl = new FormControl('');
  autoCompleteNavigations: RoomNavigationModel[];
  filteredAutoCompleteNavigations: Observable<RoomNavigationModel[]>;
  downloading: boolean;

  private _unsubscribeAll: Subject<any> = new Subject();

  constructor(
    private _appConfig: AppSettingService,
    private _changeDetectorRef: ChangeDetectorRef,
    private _eventService: EventService,
    private _rightPanelService: RightPanelService) { }

  ngOnInit(): void {
    this._registerEvents();
  }

  @Input() set roomData(value: RoomModel) {
    this._roomData = value;
    this._updateAutoCompleteNavigations();
  }

  get roomData(): RoomModel {
    return this._roomData;
  }

  @Input() set handouts(value: EventHandoutsModel[]) {
    this._handouts = this.filteredHandouts = value;
  }

  get handouts(): EventHandoutsModel[] {
    return this._handouts;
  }

  private _filterHandoutsByTerm(search: string): void {
    const searchTerm = search.toLowerCase();
    if (searchTerm === '') {
      this.filteredHandouts = this._handouts;
    } else {
      this.filteredHandouts = this._handouts?.filter((s) => {
        return s.fileName.toLowerCase().includes(searchTerm) ||
          s.roomNames?.map(m => m.toLowerCase())?.includes(searchTerm);
      });
    }
  }

  private _filter(value: string): RoomNavigationModel[] {
    const filterValue = value.toLowerCase();
    this._filterHandoutsByTerm(filterValue);
    return this.autoCompleteNavigations?.filter(option => option.roomName.toLowerCase().includes(filterValue) ||
      option.children?.some(m => m.roomName.toLowerCase().includes(filterValue)));
  }

  private _registerEvents(): void {
    this._eventService.navigations$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((data) => {
        this._allNavigations = data;
        this._updateAutoCompleteNavigations();
      });
  }

  private _updateAutoCompleteNavigations() {
    if (this._allNavigations) {
      this.autoCompleteNavigations = this._rightPanelService.prepareDropdownNavigations(this._allNavigations);
      if (this.roomData) {
        this.autoCompleteNavigations = this.autoCompleteNavigations.find(n => n.roomId === this.roomData.roomId)?.children;
      }
      this.filteredAutoCompleteNavigations = this.searchControl.valueChanges.pipe(
        startWith(''),
        map(value => this._filter(value || ''))
      );
      this._changeDetectorRef.markForCheck();
    }
  }
}
