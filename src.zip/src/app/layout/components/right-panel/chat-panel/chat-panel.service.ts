import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { ApiResponse } from 'src/app/shared/models/shared.model';
import { map } from 'rxjs/operators';
import { ChatPagedDataModel } from 'src/app/shared/models/signalr.models';

@Injectable()
export class ChatPanelService {
  private _privateChats: BehaviorSubject<ChatPagedDataModel> = new BehaviorSubject(null);
  private _roomChats: BehaviorSubject<ChatPagedDataModel> = new BehaviorSubject(null);
  private _eventChats: BehaviorSubject<ChatPagedDataModel> = new BehaviorSubject(null);

  constructor(private _httpClient: HttpClient) {
  }

  get privateChats$(): Observable<ChatPagedDataModel> {
    return this._privateChats.asObservable();
  }

  get roomChats$(): Observable<ChatPagedDataModel> {
    return this._roomChats.asObservable();
  }

  get eventChats$(): Observable<ChatPagedDataModel> {
    return this._eventChats.asObservable();
  }

  getPrivateChats(senderId: number, receiverId: number): Observable<ChatPagedDataModel> {
    if (!senderId || !receiverId) {
      this._privateChats.next({} as ChatPagedDataModel);
      return of({} as ChatPagedDataModel);
    }
    return this._httpClient.get<ApiResponse<ChatPagedDataModel>>('api/chat/private-chats', {
      params: { senderId, receiverId }
    }).pipe(map((response: ApiResponse<ChatPagedDataModel>) => {
      this._privateChats.next(response.data);
      return response.data;
    }));
  }

  getRoomChats(roomId: number): Observable<ChatPagedDataModel> {
    if (!roomId) {
      this._roomChats.next({} as ChatPagedDataModel);
      return of({} as ChatPagedDataModel);
    }
    return this._httpClient.get<ApiResponse<ChatPagedDataModel>>('api/chat/room-chats', {
      params: { roomId }
    }).pipe(map((response: ApiResponse<ChatPagedDataModel>) => {
      this._roomChats.next(response.data);
      return response.data;
    }));
  }

  getEventChats(eventId: number): Observable<ChatPagedDataModel> {
    if (!eventId) {
      this._eventChats.next({} as ChatPagedDataModel);
      return of({} as ChatPagedDataModel);
    }
    return this._httpClient.get<ApiResponse<ChatPagedDataModel>>('api/chat/event-chats', {
      params: { eventId }
    }).pipe(map((response: ApiResponse<ChatPagedDataModel>) => {
      this._eventChats.next(response.data);
      return response.data;
    })
    );
  }
}