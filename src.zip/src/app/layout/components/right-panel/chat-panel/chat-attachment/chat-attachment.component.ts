import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chat-attachment',
  templateUrl: './chat-attachment.component.html',
  styleUrls: ['./chat-attachment.component.scss']
})
export class ChatAttachmentComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }
}
