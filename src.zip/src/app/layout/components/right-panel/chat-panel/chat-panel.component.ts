import { ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { RoomModel } from 'src/app/modules/rooms/room/room.models';
import { RoomService } from 'src/app/modules/rooms/room/room.service';
import { UserModel } from 'src/app/shared/models/user.model';
import { UserService } from 'src/app/shared/services/user.service';
import {
  ChatDataModel, ChatsDataModel,
  ChatSectionType, JoinRoomModel, LeaveRoomModel
} from 'src/app/shared/models/signalr.models';
import { EventService } from 'src/app/shared/services/event.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { ChatPanelService } from './chat-panel.service';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import { EventModel } from 'src/app/shared/models/event.model';

@Component({
  selector: 'chat-panel',
  templateUrl: './chat-panel.component.html',
  styleUrls: ['./chat-panel.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ChatPanelComponent implements OnInit, OnDestroy {
  user: UserModel;
  eventData: EventModel;
  roomData: RoomModel;
  eventChatInputData: ChatsDataModel;
  roomChatData: ChatsDataModel;
  isRoomChatDisabled: boolean;
  isEventChatDisabled: boolean;
  chatBlockedWords: string[];

  private _unsubscribeAll: Subject<any> = new Subject();
  tabChangeEventsSubject: Subject<void> = new Subject<void>();

  @Input() warroom: boolean = false;
  @Input() roomSection: boolean = false;
  @Input() eventSection: boolean = false;
  @Input() roomDataFromWarroom: RoomModel;

  constructor(
    private _appSettings: AppSettingService,
    private _chatPanelService: ChatPanelService,
    private _userService: UserService,
    private _eventService: EventService,
    private _roomService: RoomService,
    private _changeDetectorRef: ChangeDetectorRef,
    private _signalrService: SignalrService
  ) {
  }

  async ngOnInit(): Promise<void> {
    this._userService.user$.subscribe((user: UserModel) => {
      this.user = user;

      if(this.roomChatData) {
        this.roomChatData.senderName = this.user.getFullName();
      }
      if(this.eventChatInputData) {
        this.eventChatInputData.senderName = this.user.getFullName();
      }

      this._changeDetectorRef.markForCheck();
    });

    this._eventService.event$.subscribe((ev: EventModel) => {
      this.eventData = ev;
      this.chatBlockedWords = ev?.settings?.chatBlockingWords?.split(',');
      this._changeDetectorRef.markForCheck();
    });

    this._roomService.roomDetails$.subscribe(async (room: RoomModel) => {
      if (this.warroom && this.roomSection && this.roomDataFromWarroom) {
        return;
      }
      this.roomData = room;
      
     
      if (!this.roomData) {
        this.roomChatData = undefined;
        return;
      }
      let roomChatDisabled = !(this.user.isHostOrCoHost() || (this.roomData.settings.isEnabled && this.roomData.settings.groupChatEnabled));
      let groupChatDisabled = !(this.user.isHostOrCoHost() || this.roomData.settings.groupChatEnabled);

      this.isRoomChatDisabled = roomChatDisabled;
      this.isEventChatDisabled = groupChatDisabled;
      const joinRequest = { roomId: this.roomData.roomId, roomType: this.roomData.roomType } as JoinRoomModel;
      const joinRes = await this._signalrService.joinRoom(joinRequest);
      if (joinRes) {
        this._chatPanelService.getRoomChats(this.roomData.roomId)
          .pipe(takeUntil(this._unsubscribeAll))
          .subscribe((roomChat) => {
            this.roomChatData = {
              receiverId: this.roomData.roomId,
              receiverName: this.roomData.roomType,
              receiverType: ChatSectionType.room,
              senderId: this.user.userId,
              senderName: this.user.getFullName(),
              chats: roomChat?.chats
            };
            this._changeDetectorRef.markForCheck();
          });
      }
    });

    const eventId = this._eventService.getEventId();
    this._chatPanelService.getEventChats(eventId)
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((eventChat) => {
        this.eventChatInputData = {
          receiverId: eventId,
          receiverName: '',
          receiverType: ChatSectionType.event,
          senderId: this.user.userId,
          senderName: this.user.getFullName(true),
          chats: eventChat.chats
        };
        this._changeDetectorRef.markForCheck();
      });

    this._signalrService.onNewMessage$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((message: ChatDataModel) => {
        if (message) {
          const att = this._eventService.findAttendee(message.senderId);
          if (att) {
            if (att.avatar) {
              message.avatarUrl = att.getAvatarUrl(this._appSettings.settings.resourceBaseUrl);
            }
            message.alt = att.alt?.toUpperCase();
          }
          if (message.chatSection === ChatSectionType.room) {
            this.roomChatData.chats.push(message);
          } else if (message.chatSection === ChatSectionType.event) {
            this.eventChatInputData.chats.push(message);
          }
        }
      });

    if (this.warroom && this.roomSection && this.roomDataFromWarroom) {
      this.roomData = this.roomDataFromWarroom;
      this.isRoomChatDisabled = this.isEventChatDisabled = !this.roomData.settings.groupChatEnabled;
      const joinRequest = { roomId: this.roomData.roomId, roomType: this.roomData.roomType } as JoinRoomModel;
      const joinRes = await this._signalrService.joinRoom(joinRequest);
      if (joinRes) {
        this._chatPanelService.getRoomChats(this.roomData.roomId)
          .pipe(takeUntil(this._unsubscribeAll))
          .subscribe((roomChat) => {
            this.roomChatData = {
              receiverId: this.roomData.roomId,
              receiverName: this.roomData.roomType,
              receiverType: ChatSectionType.room,
              senderId: this.user.userId,
              senderName: this.user.getFullName(),
              chats: roomChat?.chats
            };
            this._changeDetectorRef.markForCheck();
          });
      }
    }
  }

  ngAfterViewInit(): void {

  }

  ngOnDestroy(): void {
    const leaveRequest = { roomId: this.roomData?.roomId, roomType: this.roomData?.roomType } as LeaveRoomModel;
    this._signalrService.leaveRoom(leaveRequest);
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  onTabChanged($event) {
    setTimeout(() => {
      this.tabChangeEventsSubject.next();
    }, 500);
  }
}
