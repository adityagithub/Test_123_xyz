import {
  AfterViewChecked, AfterViewInit, ChangeDetectorRef,
  Component, ElementRef, EventEmitter, Input, OnDestroy,
  OnInit, Output, Renderer2, ViewChild, ViewEncapsulation
} from '@angular/core';
import { NgForm } from '@angular/forms';
import { differenceInMinutes } from 'date-fns';
import { Observable, Subject, takeUntil } from 'rxjs';
import { FwPerfectScrollbarDirective } from 'src/app/core/directives/fw-perfect-scrollbar/fw-perfect-scrollbar.directive';
import { ChatDataModel, ChatsDataModel } from 'src/app/shared/models/signalr.models';
import { EventService } from 'src/app/shared/services/event.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { EmojiSearch } from '@ctrl/ngx-emoji-mart';
import { FwMatchMediaService } from 'src/app/core/services/match-media.service';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import * as Filter from 'bad-words';
import { FwSidebarService } from 'src/app/core/components/sidebar/sidebar.service';

@Component({
  selector: 'chat-panel-view',
  templateUrl: './chat-view.component.html',
  styleUrls: ['./chat-view.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ChatPanelViewComponent implements OnInit, AfterViewInit, AfterViewChecked, OnDestroy {

  specialCharacterFormat = /[ `!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
  emoji_regex = /^(?:[\u2700-\u27bf]|(?:\ud83c[\udde6-\uddff]){2}|[\ud800-\udbff][\udc00-\udfff]|[\u0023-\u0039]\ufe0f?\u20e3|\u3299|\u3297|\u303d|\u3030|\u24c2|\ud83c[\udd70-\udd71]|\ud83c[\udd7e-\udd7f]|\ud83c\udd8e|\ud83c[\udd91-\udd9a]|\ud83c[\udde6-\uddff]|[\ud83c[\ude01-\ude02]|\ud83c\ude1a|\ud83c\ude2f|[\ud83c[\ude32-\ude3a]|[\ud83c[\ude50-\ude51]|\u203c|\u2049|[\u25aa-\u25ab]|\u25b6|\u25c0|[\u25fb-\u25fe]|\u00a9|\u00ae|\u2122|\u2139|\ud83c\udc04|[\u2600-\u26FF]|\u2b05|\u2b06|\u2b07|\u2b1b|\u2b1c|\u2b50|\u2b55|\u231a|\u231b|\u2328|\u23cf|[\u23e9-\u23f3]|[\u23f8-\u23fa]|\ud83c\udccf|\u2934|\u2935|[\u2190-\u21ff])+$/;

  @ViewChild('replyForm', { static: false })
  private _replyForm: NgForm

  @ViewChild('replyInput', { static: false })
  private _replyInput: ElementRef

  @ViewChild('messages', { static: false })
  private _messagesContainer: ElementRef

  @ViewChild('messages', { read: FwPerfectScrollbarDirective, static: false })
  private _chatViewScrollbar: FwPerfectScrollbarDirective;

  chatInputMessage: string;
  isDesktop: boolean = true;
  @Input() warroom: boolean;
  @Input() roomSection: boolean;
  @Input() eventSection: boolean;

  private _unsubscribeAll: Subject<any> = new Subject();

  constructor(
    private _renderer: Renderer2,
    private _changeDetectorRef: ChangeDetectorRef,
    private _fwMatchMediaService: FwMatchMediaService,
    private _appSettings: AppSettingService,
    private _signalrService: SignalrService,
    private _eventService: EventService,
    private _emojiSearch: EmojiSearch,
    private _sidebarService: FwSidebarService,
  ) {
    if (this._fwMatchMediaService.isActive('lt')) {
      this.isDesktop = false;
    }
  }

  ngOnInit(): void {

    this._signalrService.onNewMessage$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((message: ChatDataModel) => {
        if (message) {
          setTimeout(() => {
            this._prepareChatForReplies();
          }, 500);
        }
      });

    this.scrollNow?.pipe(takeUntil(this._unsubscribeAll))?.subscribe(() => {
      this._prepareChatForReplies(500);
    });

  }

  ngAfterViewInit(): void {
    // TODO Expression change error was throwing when opening any private chat
    // this._prepareChatForReplies();
  }

  ngAfterViewChecked(): void {
    this.onReplyInputResize(null);
  }

  // ngOnChanges(changes: SimpleChanges): void {
  //   if ('data' in changes) {
  //     if (this.data && this.data.chats) {
  //       this.data.chats.forEach(c => {
  //         const att = this._eventService.findAttendee(c.senderId);
  //         if (att) {
  //           if (att.avatar) {
  //             c.avatarUrl = att.getAvatarUrl(this._appSettings.settings.resourceBaseUrl);
  //           }
  //           c.alt = att.alt;
  //         }
  //       });
  //     }
  //     this._prepareChatForReplies();
  //     this._changeDetectorRef.markForCheck();
  //   }
  // }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true)
    this._unsubscribeAll.complete()
  }

  @Input() marginHeight: number;
  @Input() chatDisabled: boolean;
  @Input() isPrivateChat: boolean;
  @Input() chatBlockedWords: string[] = [];

  private _data: ChatsDataModel;
  get data(): ChatsDataModel {
    return this._data;
  }

  @Input() set data(values: ChatsDataModel) {
    if (values && values.chats) {
      values.chats.forEach(c => {
        const att = this._eventService.findAttendee(c.senderId);
        if (att) {
          if (att.avatar) {
            c.avatarUrl = att.getAvatarUrl(this._appSettings.settings.resourceBaseUrl);
          }
          c.senderName = att.getFullName(true);
          c.alt = att.alt;
        }
      });
      this._data = values;
    }
    this._prepareChatForReplies();
    this._changeDetectorRef.markForCheck();
  }

  @Input() scrollNow: Observable<void>;

  @Output() onPrivateChatSent = new EventEmitter<ChatDataModel>();

  private _prepareChatForReplies(speed = 100): void {
    if (this._chatViewScrollbar) {
      this._chatViewScrollbar.update();
      this._chatViewScrollbar.scrollToBottom(0, speed);
      this._replyInput.nativeElement.focus();
    }
  }

  shouldShowContactAvatar(message: ChatDataModel, i: number): boolean {
    if (message.senderId !== this.data.senderId && i === 0) { return true; }

    return (message.senderId !== this.data.senderId &&
      ((this.data.chats[i - 1] && this.data.chats[i - 1].senderId !== message.senderId))) ||
      (message.senderId !== this.data.senderId && (this.data.chats[i - 1] && this.data.chats[i - 1].senderId === message.senderId) &&
        differenceInMinutes(new Date(message.createdDateUtc), new Date(this.data.chats[i - 1].createdDateUtc)) > 0);
  }

  isFirstMessageOfGroup(message: { senderId: number; }, i: number): boolean {
    return (i === 0 || (this.data.chats[i - 1] && this.data.chats[i - 1].senderId !== message.senderId))
  }

  isLastMessageOfGroup(message: { senderId: any; createdDateUtc: Date }, i: number): boolean {
    return (i === this.data.chats.length - 1 || (this.data.chats[i + 1] && this.data.chats[i + 1].senderId !== message.senderId) ||
      (this.data.chats[i + 1] && this.data.chats[i + 1].senderId === message.senderId &&
        differenceInMinutes(new Date(this.data.chats[i + 1].createdDateUtc), new Date(message.createdDateUtc)) >= 1))
  }

  async reply(event: { preventDefault: () => void; }): Promise<void> {
    event.preventDefault();

    if (this.chatDisabled) {
      return;
    }

    let msg = this._replyForm.form.value.chatInputMessage as string;

    if (!msg) {
      this._prepareChatForReplies();
      return;
    }

    const isEmoji = this.emoji_regex.test(msg);

    if (!isEmoji) {
      try {
        var filter = new Filter({ emptyList: true, placeHolder: '#' });
        //filter.list.push(this.chatBlockedWords);
        this.chatBlockedWords.forEach(w => {
          if (w) {
            filter.addWords(w);
          }
        });

        if (filter?.list?.length) {
          msg = filter.clean(msg);
        }

      } catch (e) {
      }
    }

    if (this.specialCharacterFormat.test(msg)) {
      // TODO
    }

    const message = {
      messageId: '',
      message: msg,
      messageType: isEmoji ? 'emoji' : 'text',
      createdDateUtc: new Date(),
      receiverId: this.data.receiverId,
      receiverName: this.data.receiverName,
      senderName: this.data.senderName,
      senderId: this.data.senderId,
      chatSection: this.data.receiverType
    } as ChatDataModel;

    this.data.chats.push(message);

    this._replyForm.reset();

    this._signalrService.sendMessage(message).then(r => {
      this._prepareChatForReplies();
      if (this.isPrivateChat) {
        this.onPrivateChatSent.next(message);
      }
    });
  }

  onReplyInputResize(e: any): void {
    if (!this._replyInput || !this._replyInput.nativeElement) { return; }

    const textArea = this._replyInput.nativeElement;
    if (!textArea || textArea.rows >= 8) {
      return;
    }

    let height = (textArea.offsetHeight + this.marginHeight);
    if (!this.isDesktop) { height = height + 32 }
    this._renderer.setStyle(this._messagesContainer.nativeElement, 'height', `calc(100vh - ${height}px)`);
  }

  onChatInputChange(txt: any): void {
    if (txt) {
      // if (/^\d+$/.test(txt)) {
      //   return;
      // }
      // if (txt.length === 2) {
      //   const ispecialChar = this.specialCharacterFormat.test(txt);
      //   if (!ispecialChar) { return; }

      //   const emoji = this._emojiSearch.search(txt).map(m => m.native);
      //   if (emoji && emoji.length) {
      //     this.chatInputMessage = emoji[0];
      //   }
      // } else if (txt.length > 2) {
      //   const last3Char = txt.slice(-3);
      //   const lastTwoChar = last3Char.slice(-2);
      //   const thirdLastChar = last3Char[0];
      //   const secondLastChar = last3Char[1];
      //   if (secondLastChar === ' ') { return; }
      //   const lastChar = last3Char[2];
      //   if (lastChar === ' ') { return; }

      //   if (lastTwoChar.match(/[a-z]/i)) { return; }
      //   if ((thirdLastChar !== ' ' && thirdLastChar.match(/[a-z]/i))) { return; }

      //   const emoji = this._emojiSearch.search(lastTwoChar).map(m => m.native);
      //   if (emoji && emoji.length) {
      //     this.chatInputMessage = this.chatInputMessage.slice(0, -2);
      //     this.chatInputMessage += emoji[0];
      //   }
      // }
    }
  }

  onEmojiSelected(event: any): void {
    if (!this.chatInputMessage) { this.chatInputMessage = '' }
    this.chatInputMessage += event.native;
    this._changeDetectorRef.markForCheck();
  }

  onChatScrollUp(event: any): void {
    console.log('scrolled up', event);
  }
}