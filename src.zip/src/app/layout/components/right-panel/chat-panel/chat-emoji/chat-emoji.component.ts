import {
  AfterViewInit, ChangeDetectorRef, Component, ElementRef, EventEmitter,
  OnDestroy, OnInit, Output, TemplateRef, ViewChild, ViewContainerRef, ViewEncapsulation
} from '@angular/core';
import { FwMatchMediaService } from 'src/app/core/services/match-media.service';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { Overlay, OverlayRef } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';

@Component({
  selector: 'chat-emoji',
  templateUrl: './chat-emoji.component.html',
  styleUrls: ['./chat-emoji.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ChatEmojiComponent implements OnInit, AfterViewInit, OnDestroy {
  isDesktop = true;
  set = 'twitter';
  private _overlayRef: OverlayRef
  @ViewChild('messagesOrigin') private _messagesOrigin: ElementRef
  @ViewChild('messagesPanel') private _messagesPanel: TemplateRef<any>

  private _unsubscribeAll: Subject<any> = new Subject()

  @Output() emojiSelected: EventEmitter<any>

  constructor(
    private _fwMatchMediaService: FwMatchMediaService,
    private _changeDetectorRef: ChangeDetectorRef,
    private _viewContainerRef: ViewContainerRef,
    private _overlay: Overlay) {
    this.emojiSelected = new EventEmitter()
  }

  ngOnInit(): void {
  }

  ngAfterViewInit(): void {
    if (this._fwMatchMediaService.isActive('lt')) {
      this.isDesktop = false
      this._changeDetectorRef.detectChanges()
    }
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();

    if (this._overlayRef) {
      this._overlayRef.dispose();
    }
  }

  openPanel(): void {
    if (!this._messagesPanel || !this._messagesOrigin) {
      return
    }

    if (!this._overlayRef) {
      this._createOverlay()
    }

    this._overlayRef.attach(new TemplatePortal(this._messagesPanel, this._viewContainerRef))

    this._changeDetectorRef.detectChanges();
  }

  addEmoji(event: any) {
    console.log(event.emoji);
    this.emojiSelected.emit(event.emoji);
    this.closePanel();
  }

  closePanel(): void {
    this._overlayRef.detach()
  }

  loadEmoji = ((set, sheetSize) => 'assets/images/emoji-mart.png')

  private _createOverlay(): void {
    this._overlayRef = this._overlay.create({
      hasBackdrop: true,
      backdropClass: 'fw-backdrop-on-mobile',
      panelClass: 'cdk-emoji-panel',
      scrollStrategy: this._overlay.scrollStrategies.block(),
      positionStrategy: this._overlay.position()
        .flexibleConnectedTo(this._messagesOrigin.nativeElement)
        .withLockedPosition()
        .withPush(true)
        .withPositions([
          {
            originX: 'end',
            originY: 'bottom',
            overlayX: 'end',
            overlayY: 'top'
          },
          {
            originX: 'start',
            originY: 'bottom',
            overlayX: 'start',
            overlayY: 'top'
          },
          {
            originX: 'start',
            originY: 'top',
            overlayX: 'start',
            overlayY: 'bottom'
          },

          {
            originX: 'end',
            originY: 'top',
            overlayX: 'end',
            overlayY: 'bottom'
          }
        ])
    })

    this._overlayRef.backdropClick().subscribe(() => {
      this._overlayRef.detach()
    })
  }
}
