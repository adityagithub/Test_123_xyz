import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { FwCoreModule } from 'src/app/core/fw.core.module';

import { ContentComponent } from './content.component';

@NgModule({
  declarations: [
    ContentComponent
  ],
  imports: [
    RouterModule,
    FwCoreModule
  ],
  exports: [
    ContentComponent
  ]
})
export class ContentModule {
}
