import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AdgoSharedModule } from 'app/shared/shared.module';

import { ContentComponent } from 'app/layout/components/content/content.component';

@NgModule({
    declarations: [
        ContentComponent
    ],
    imports     : [
        RouterModule,
        AdgoSharedModule
    ],
    exports     : [
        ContentComponent
    ]
})
export class ContentModule
{
}
