import { NgModule } from '@angular/core';

import { VerticalLayout1Module } from 'app/layout/vertical/vertical.module';

import { HorizontalLayout1Module } from 'app/layout/horizontal/horizontal.module';

@NgModule({
    imports: [
        VerticalLayout1Module,
        HorizontalLayout1Module
    ],
    exports: [
        VerticalLayout1Module,
        HorizontalLayout1Module
    ]
})
export class LayoutModule
{
}
