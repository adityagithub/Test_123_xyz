import { NgModule } from '@angular/core';
import { GuidedTourModule } from 'ngx-guided-tour';
import { FwProgressBarModule, FwSidebarModule } from '../core/components';
import { MaterialModule } from '../core/material.module';
import { FwCoreModule } from '../core/fw.core.module';
import { LayoutComponent } from './layout.component';
import { VerticalLayoutModule } from './vertical/vertical-layout.module';
import { NavbarVerticalStyleModule } from './components/navbar/vertical/vertical.module';
import { ContentModule } from './components/content/content.module';
import { FooterModule } from './components/footer/footer.module';
import { NavbarModule } from './components/navbar/navbar.module';
import { RightPanelModule } from './components/right-panel/right-panel.module';
import { ToolbarModule } from './components/toolbar/toolbar.module';

@NgModule({
  declarations: [
    LayoutComponent
  ],
  imports: [
    MaterialModule,
    VerticalLayoutModule,
    GuidedTourModule,
    FwProgressBarModule,
    FwCoreModule,
    FwSidebarModule,
    NavbarVerticalStyleModule,
    RightPanelModule,
    ContentModule,
    FooterModule,
    NavbarModule,
    ToolbarModule,
  ],
  exports: [
    VerticalLayoutModule
  ]
})
export class LayoutModule {
}
