import { Platform } from '@angular/cdk/platform';
import { DOCUMENT } from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectorRef, Component, HostListener,
  Inject, OnDestroy, OnInit, ViewEncapsulation
} from '@angular/core';
import { Title } from '@angular/platform-browser';
import { GuidedTourService } from 'ngx-guided-tour';
import { Subject, interval } from 'rxjs';
import { map, takeUntil } from 'rxjs/operators';
import { FwMatchMediaService } from 'src/app/core/services/match-media.service';
import { FwNavigationService } from 'src/app/core/components/navigation/navigation.service';
import { FwSidebarService } from 'src/app/core/components/sidebar/sidebar.service';
import { FwConfigService } from 'src/app/core/services/config.service';
import { FwSplashScreenService } from 'src/app/core/services/splash-screen.service';
import { IconService } from '../core/services/icon.service';
import { FwNavigationItem } from '../core/types';
import { appNavigation } from '../app.navigation';
import { EventModel, RoomNavigationModel } from '../shared/models/event.model';
import { EventService } from '../shared/services/event.service';
import { SharedService } from '../shared/services/shared.service';
import { SignalrService } from '../shared/services/signalr.service';
import { CommandType, SignalDataModel } from '../shared/models/signalr.models';
import { EnumRoomType } from '../modules/rooms/room/room.models';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { UserModel } from '../shared/models/user.model';
import { UserService } from '../shared/services/user.service';
import { HelpComponent } from '../modules/pages/help/help.component';
import { RoomService } from '../modules/rooms/room/room.service';
import { MessageService } from '../shared/services/message.service';
import { MaterialCssVarsService } from 'angular-material-css-vars';
import { LayoutConfig } from '../core/layoutConfig';
import { NicknameEditorDialogComponent } from '../modules/user/nickname-editor-dialog/nickname-editor-dialog.component';
import { NotificationsService } from '../shared/services/notifications.service';
import { CustomizationService } from '../modules/warroom/customization/customization.service';
import { UserSettings, UserSettingsKeys } from './components/right-panel/settings/settings.models';

@Component({
  selector: 'layout',
  templateUrl: './layout.component.html',
  styleUrls: ['./layout.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class LayoutComponent implements OnInit, AfterViewInit, OnDestroy {
  isMobileLayout: boolean;
  authenticated: boolean;
  appConfig: LayoutConfig;
  eventData: EventModel;
  currentUser: UserModel;
  userSettings: UserSettings[];

  private _unsubscribeAll: Subject<any> = new Subject();

  constructor(
    @Inject(DOCUMENT) private document: any,
    private _fwConfigService: FwConfigService,
    private _matchMediaService: FwMatchMediaService,
    private _navigationService: FwNavigationService,
    private _fwSidebarService: FwSidebarService,
    private _splashScreenService: FwSplashScreenService,
    private _platform: Platform,
    private _iconService: IconService,
    private _changeDetectorRef: ChangeDetectorRef,
    private _guidedTourService: GuidedTourService,
    private _sharedService: SharedService,
    private _titleService: Title,
    private _userService: UserService,
    private _eventService: EventService,
    private _roomService: RoomService,
    private _signalrService: SignalrService,
    private _route: ActivatedRoute,
    private _dialog: MatDialog,
    private _router: Router,
    private _messageService: MessageService,
    private _materialCssVarsService: MaterialCssVarsService,
    private _activatedRoute: ActivatedRoute,
    private _notificationsService: NotificationsService,
    private _customizationService: CustomizationService
  ) {
    // let encriptedUrl = this._router.url.replace(SharedService.originalToken, SharedService.encriptedToken);
    // this._router.navigateByUrl(encriptedUrl);
    if (this._platform.ANDROID || this._platform.IOS) {
      this.document.body.classList.add('is-mobile');
    }
    this.appConfig = this._fwConfigService.defaultConfig;

    this._setTheme();
  }

  ngOnInit(): void {
    this._sharedService.paramToken = this._route.snapshot.paramMap.get('t');
    this._registerEvents();
    this._notificationsService.getUnreadNotifications().pipe(takeUntil(this._unsubscribeAll)).subscribe({});
  }

  ngAfterViewInit(): void {
    this.checkAndOpenNicknameEditorDialog();
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  toggleSidebarOpen(key: string): void {
    this._fwSidebarService.getSidebar(key).toggleOpen();
  }

  startTour(useOrb: boolean): void {
    this._guidedTourService.startTour(this._sharedService.getAppTours(useOrb));
  }

  private _registerEvents(): void {

    this._fwConfigService.config
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((config: LayoutConfig) => {
        this.appConfig = config;
        if (this.isMobileLayout) {
          this.appConfig.layout.footer.hidden = false;
        }
        this._changeDetectorRef.markForCheck();
      });

    this._userService.user$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((user: UserModel) => {
        this.currentUser = user;
      });

    this._userService.userSettings$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe(settings => {
        this.userSettings = settings;     
      });

    this._eventService.event$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((data: EventModel) => {
        if (data) {
          this._titleService.setTitle('Fireworks™ - ' + data.eventTitle);
          this.authenticated = true;
          this.eventData = data;
          this._changeDetectorRef.markForCheck();
        }
      });

    this._eventService.navigations$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((navs: RoomNavigationModel[]) => {
        if (navs) {
          let appNavs = appNavigation;
          const mainNavs = this._prepareAppNavigations(navs);
          if (this.currentUser && !this.currentUser.isHostOrCoHost()) {
            appNavs = appNavigation.filter(f => f.id !== 'admin');
          }
          appNavs.find(x => x.id === 'rooms').children = mainNavs;
          if (!appNavs.find(n => n.id === 'other')) {
            const utils = this._getUtilityMenuItems();
            appNavs.push(utils);
          }
          this._navigationService.unregister('main');
          this._navigationService.register('main', appNavs);
          this._navigationService.setCurrentNavigation('main');
          this._changeDetectorRef.detectChanges();
        }
      });

    this._signalrService.onBackendUpdated$
      .pipe(takeUntil(this._unsubscribeAll)).subscribe(command => {
        if (command) {
          if (command.command === CommandType.eventDataUpdated) {
            this._eventService.getEvent().pipe(takeUntil(this._unsubscribeAll)).subscribe();
            this._eventService.getSchedules().pipe(takeUntil(this._unsubscribeAll)).subscribe();
            this._eventService.getRooms().pipe(takeUntil(this._unsubscribeAll)).subscribe();
            this._eventService.getHandouts().pipe(takeUntil(this._unsubscribeAll)).subscribe();
          }
          if (command.command === CommandType.attendeeDataUpdated) {
            this._eventService.getAttendees().pipe(takeUntil(this._unsubscribeAll)).subscribe();
          }
          if (command.command === CommandType.handoutsDataUpdated) {
            this._eventService.getHandouts().pipe(takeUntil(this._unsubscribeAll)).subscribe();
          }
          if (command.command === CommandType.scheduleDataUpdated) {
            this._eventService.getSchedules().pipe(takeUntil(this._unsubscribeAll)).subscribe();
          }
          if (command.command === CommandType.speakerDataUpdated) {
            this._eventService.getSpeakers().pipe(takeUntil(this._unsubscribeAll)).subscribe();
          }
          if (command.command === CommandType.sponsorsDataUpdated) {
            this._eventService.getSponsors().pipe(takeUntil(this._unsubscribeAll)).subscribe();
          }
          if (command.command === CommandType.roomDataUpdated) {
            this._eventService.getRooms().pipe(takeUntil(this._unsubscribeAll)).subscribe();
            this._eventService.getSchedules().pipe(takeUntil(this._unsubscribeAll)).subscribe();
            this._eventService.getHandouts().pipe(takeUntil(this._unsubscribeAll)).subscribe();
          }
        }
      });

    this._signalrService.onClientReconnected$.pipe(takeUntil(this._unsubscribeAll)).subscribe(s => {
      this._realoadBackendData();
    });

    this._signalrService.onNewSignal$.pipe(takeUntil(this._unsubscribeAll)).subscribe(async (data: SignalDataModel) => {
      if (data && data.command === CommandType.memberRoleChange) {
        if (data.receiverId === this.currentUser.userId || data.receiverIds?.includes(this.currentUser.userId)) {
          const user = this._userService.getCurrentUser();
          user.userRoles = data.data.userRoles;
          this._userService.setCurrentUser(user);
          this._eventService.updateRoomNavigationOnRoleChange();

          if (user.isCohost()) {
            this._messageService.showInfoMessage('You are a co-host now');
          } else if (user.isPresenter()) {
            this._messageService.showInfoMessage('You are a presenter now');
          } else {
            this._messageService.showInfoMessage('You are attendee now');
          }
        }
        this._eventService.getAttendees().pipe(takeUntil(this._unsubscribeAll)).subscribe();
      }

      // if (data && data.command === CommandType.userStatusChanged) {
      //   if (data.receiverId === this.currentUser.userId) {
      //     const currentUser = this._userService.getCurrentUser();
      //     currentUser.status = data.data.status;
      //     this._userService.setCurrentUser(currentUser);
      //     this._eventService.getAttendees().subscribe();
      //   }
      // }

      if (data && (data.command === CommandType.profileUpdated || data.command == CommandType.hideFromScreen)) {
        this._eventService.getAttendees().pipe(takeUntil(this._unsubscribeAll)).subscribe();
      }

      if (data && (data.command === CommandType.messageToEvent || data.command === CommandType.messageToRooms)) {
        let setting = this.userSettings.find(s => s.key == UserSettingsKeys.disableAlert);
        if (setting?.value) {
          this._messageService.showBroadcastMessageNotification(data.data.extra.message, true, data.data.extra.seconds);
        }
        this._notificationsService.getUnreadNotifications().pipe(takeUntil(this._unsubscribeAll)).subscribe({});
      }

      if (data && data.command === CommandType.eventDataUpdated) {
        this._eventService.getEvent().pipe(takeUntil(this._unsubscribeAll)).subscribe();
        this._eventService.getSchedules().pipe(takeUntil(this._unsubscribeAll)).subscribe();
        this._eventService.getRooms().pipe(takeUntil(this._unsubscribeAll)).subscribe();
        this._eventService.getHandouts().pipe(takeUntil(this._unsubscribeAll)).subscribe();
      }

      if (data && data.command === CommandType.roomDataUpdated) {
        this._eventService.getRooms().pipe(takeUntil(this._unsubscribeAll)).subscribe();
        this._eventService.getSchedules().pipe(takeUntil(this._unsubscribeAll)).subscribe();
        this._eventService.getHandouts().pipe(takeUntil(this._unsubscribeAll)).subscribe();
      }

      if (data && data.command === CommandType.customizationByHostCohost) {
        this._customizationService.getCustomizationDetail().then(res => { });
      }

      if (data && data.command === CommandType.newNotification) {
        if (data.receiverId === this.currentUser.userId || data.receiverIds?.includes(this.currentUser.userId)) {
          this._notificationsService.getUnreadNotifications().pipe(takeUntil(this._unsubscribeAll)).subscribe();
        }
      }

      if (data && data.command === CommandType.remoteClientReconnected) {
        this._realoadBackendData();
      }

    });

    this.intervalService30Sec();

    this._customizationService.customization$.pipe(takeUntil(this._unsubscribeAll)).subscribe(res => {
      if (res) {
        this._customizationService.setAppFavicon(res.faviconUrl);
        if (res.trademarkText) {
          this._customizationService.setAppTitle(res.trademarkText + "™ - " + this.eventData.eventTitle);
        } else {
          this._customizationService.setAppTitle(this.eventData.eventTitle);
        }
      }
    });
    this._customizationService.getCustomizationDetail().then(res => { });
  }

  private _prepareAppNavigations(data: RoomNavigationModel[]): FwNavigationItem[] {
    const lobbyRoom = data.find(x => x.roomType === EnumRoomType.reception);
    let mainRooms = data.filter(x => x.roomType !== EnumRoomType.customRoom && x.roomType !== EnumRoomType.reception);
    const customRooms = data.filter(x => x.roomType === EnumRoomType.customRoom);

    if (this.currentUser && !this.currentUser.isHostOrCoHost()) {
      mainRooms = mainRooms.filter(f => f.roomType !== 'greenroom');
    }

    let mainRoomNavs = mainRooms.map(m => ({
      id: m.roomId.toString(),
      title: m.roomName,
      type: 'item',
      icon: m.roomType,
      url: this.getRoomUrl(m)
    } as FwNavigationItem));

    if (lobbyRoom) {
      const lobbyRoomNav = [{
        id: lobbyRoom.roomId.toString(),
        title: lobbyRoom.roomName,
        type: 'item',
        icon: lobbyRoom.roomType,
        children: [],
        url: 'r/' + lobbyRoom.roomId + '/' + lobbyRoom.roomName.replace(/ /g, '-').toLowerCase()
      } as FwNavigationItem];
      mainRoomNavs = lobbyRoomNav.concat(mainRoomNavs);
    }

    if (customRooms.length) {
      const customRoomsNavs = customRooms.map(m => ({
        id: m.roomId.toString(),
        title: m.roomName,
        type: 'item',
        icon: 'customrooms',
        url: 's/' + m.roomId + '/' + m.roomName.replace(/ /g, '-').toLowerCase()
      } as FwNavigationItem));

      const customRoomRootNav = [{
        id: 'customrooms',
        title: 'Explore',
        type: 'collapsable',
        icon: 'customrooms',
        children: customRoomsNavs
      } as FwNavigationItem];
      mainRoomNavs = mainRoomNavs.concat(customRoomRootNav);
    }

    return mainRoomNavs;
  }

  private getRoomUrl(m: RoomNavigationModel) {
    if (['reception', 'lobby'].includes(m.roomType)) {
      return 'r/' + m.roomId + '/' + m.roomName.replace(/ /g, '-').toLowerCase();
    }
    return (['session', 'expo', 'networking'].includes(m.roomType) ? 'm/' : 's/') +
      m.roomId + '/' + m.roomName.replace(/ /g, '-').toLowerCase()
  }

  @HostListener('document:click', ['$event'])
  handleClick(event: Event): void {
    if (event.target instanceof HTMLAnchorElement) {
      const element = event.target as HTMLAnchorElement;
      if (element.className === 'private_room_invite_link') {
        event.preventDefault();
        event.stopPropagation();
        try {
          const roomId = event.target.getAttribute('data-roomid');
          if (roomId) {
            this._moveToPrivateRoom(parseInt(roomId));
          }
        } catch (e) {
        }
      }
    }
  }

  openHelpDialog(): void {
    this._dialog.open(HelpComponent, {
      data: {},
      panelClass: 'help-dialog-container'
    })
  }

  openSilentAuctionDialog(): void {
    import('../modules/silent-auction/silent-auction.component').then(res => {
      this._dialog.open(res.SilentAuctionComponent, {
        width: '80%',
        data: {},
        panelClass: 'silent-auction-dialog-container'
      })
    })
  }

  private _getUtilityMenuItems(): any {
    const otherGroupItem = {
      id: 'other',
      title: 'Other',
      type: 'group',
      children: []
    };
    if (this.eventData?.settings?.silentAuctionEnabled) {
      otherGroupItem.children.push({
        id: 'silent-auction',
        title: 'Silent Auction',
        type: 'item',
        icon: 'silent-auction',
        function: () => {
          this.openSilentAuctionDialog();
        }
      });
    }
    if (this.eventData?.settings?.donationButtonEnabled) {
      otherGroupItem.children.push({
        id: 'donation',
        title: this.eventData.donationButtonText,
        type: 'item',
        icon: 'donation',
        url: this.eventData.donationButtonLink,
        externalUrl: this.eventData.donationButtonLink,
        openInNewTab: true
      });
    }

    return otherGroupItem;
  }

  private _moveToPrivateRoom(roomId: number): void {
    const eId = this._route.snapshot.paramMap.get('id');
    const token = this._route.snapshot.paramMap.get('t');
    const url = `fireworks/${eId}/${token}/p/private/${roomId}/private-room`;
    this._sharedService.enableAutoJoinRoom(true);
    this._router.navigate([url], { replaceUrl: false });
    this._dialog.closeAll();
  }

  private _setTheme() {
    this._sharedService.setThemeColor('');
    const dark = (this.appConfig.colorTheme.toLowerCase() == 'isdarktheme');
    this._sharedService.setStypeVariableInDocumentNode(dark, this.document.documentElement.style);
    this._materialCssVarsService.setDarkTheme(dark);
  }

  private _realoadBackendData(): void {
    this._eventService.getEvent().pipe(takeUntil(this._unsubscribeAll)).subscribe();
    this._eventService.getSchedules().pipe(takeUntil(this._unsubscribeAll)).subscribe();
    this._eventService.getRooms().pipe(takeUntil(this._unsubscribeAll)).subscribe();
    this._eventService.getHandouts().pipe(takeUntil(this._unsubscribeAll)).subscribe();
    this._eventService.getSpeakers().pipe(takeUntil(this._unsubscribeAll)).subscribe();
    this._eventService.getSponsors().pipe(takeUntil(this._unsubscribeAll)).subscribe();
    this._eventService.getAttendees().pipe(takeUntil(this._unsubscribeAll)).subscribe();
  }

  checkAndOpenNicknameEditorDialog(): void {

    return;

    if (this._sharedService.donotShowNicknamePopup$) {
      return;
    }

    if (this.currentUser.isSystemUser()) {
      return;
    }

    if (!this._eventService.isNicknameEnabled()) {
      return;
    }

    //TODO
    // if (this.currentUser.nickName) {
    //   return;
    // }

    this._dialog.open(NicknameEditorDialogComponent, {
      data: {},
      restoreFocus: false,
      panelClass: 'nickname-editor-container',
      disableClose: true
    });
  }

  intervalService30Sec() {
    const source = interval(30000);
    source.pipe(takeUntil(this._unsubscribeAll)).subscribe(val => {
      this._sharedService.syncNicknameDoNotShowStatus();
    });
  }
}
