import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { FwSidebarModule } from 'src/app/core/components';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { ContentModule } from '../components/content/content.module';
import { FooterModule } from '../components/footer/footer.module';
import { NavbarModule } from '../components/navbar/navbar.module';
import { ToolbarModule } from '../components/toolbar/toolbar.module';
import { VerticalLayoutComponent } from '../vertical/vertical-layout.component';
import { NavbarVerticalStyleModule } from '../components/navbar/vertical/vertical.module';
import { RightPanelModule } from '../components/right-panel/right-panel.module';
import { MaterialModule } from 'src/app/core/material.module';

@NgModule({
  declarations: [
    VerticalLayoutComponent
  ],
  imports: [
    RouterModule,
    MaterialModule,
    FwCoreModule,
    FwSidebarModule,
    RightPanelModule,
    ContentModule,
    FooterModule,
    NavbarModule,
    ToolbarModule,
    NavbarVerticalStyleModule
  ],
  exports: [
    VerticalLayoutComponent
  ]
})
export class VerticalLayoutModule {
}
