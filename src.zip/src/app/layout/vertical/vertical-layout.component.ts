import { Component, ElementRef, OnDestroy, OnInit, Renderer2, ViewChild, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Data } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { InitialData } from 'src/app/app.model';
import { FwSidebarService } from 'src/app/core/components/sidebar/sidebar.service';
import { FwConfigService } from 'src/app/core/services/config.service';
import { UserModel } from 'src/app/shared/models/user.model';
import { RightPanelService } from '../components/right-panel/right-panel.service';
import { LayoutConfig } from 'src/app/core/layoutConfig';

@Component({
  selector: 'vertical-layout',
  templateUrl: './vertical-layout.component.html',
  styleUrls: ['./vertical-layout.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class VerticalLayoutComponent implements OnInit, OnDestroy {
  private _unsubscribeAll: Subject<any> = new Subject();
  user: UserModel;
  data: InitialData;
  fwConfig: any;
  rightPanelFolded: boolean;
  @ViewChild('rightPanelButtonToggle', { read: ElementRef }) rightPanelButtonToggle: ElementRef;

  constructor(
    private _activatedRoute: ActivatedRoute,
    private _fwConfigService: FwConfigService,
    private _renderer: Renderer2,
    private _sidebarService: FwSidebarService,
    private _rightPanelService: RightPanelService
  ) {
  }

  ngOnInit(): void {
    this._activatedRoute.data.subscribe((data: Data) => {
      this.data = data.initialData;
      this.user = this.data.user;
    });

    this._fwConfigService.config
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((config: LayoutConfig) => {
        this.fwConfig = config;
      });

    this._rightPanelService.rightPanelFolded$.pipe(takeUntil(this._unsubscribeAll)).subscribe(folded => {
      if (this.rightPanelButtonToggle?.nativeElement) {
        this.rightPanelFolded = folded; // Currently working, TODO Check
        folded
          ? this._renderer.setStyle(this.rightPanelButtonToggle?.nativeElement, 'right', '48px')
          : this._renderer.setStyle(this.rightPanelButtonToggle?.nativeElement, 'right', '400px');
      }
    })
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  toggleRightPanel(element: any): void {
    const sidebar = this._sidebarService.getSidebar('right-panel');
    if (sidebar) {
      this.rightPanelFolded = sidebar.unfolded; // Currently working, TODO Check
      if (sidebar.unfolded) {
        sidebar.foldTemporarily();
        this._renderer.setStyle(element.currentTarget, 'right', '48px');
      } else {
        sidebar.unfoldTemporarily();
        this._renderer.setStyle(element.currentTarget, 'right', '400px');
      }
      this._rightPanelService.setRightPanelFolded(this.rightPanelFolded);
    }
  }
}
