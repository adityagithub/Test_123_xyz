import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { forkJoin, Observable, of } from 'rxjs';
import { catchError, switchMap, map } from 'rxjs/operators';
import { InitialData } from './app.model';
import { UserService } from './shared/services/user.service';
import { EventService } from './shared/services/event.service';
import { SignalrService } from './shared/services/signalr.service';
import { MessageService } from './shared/services/message.service';


@Injectable({
  providedIn: 'root'
})
export class InitialDataResolver implements Resolve<InitialData> {
  constructor(
    private _userService: UserService,
    private _signalRService: SignalrService,
    private _eventService: EventService,
    private _messageService: MessageService
  ) {
  }

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> {
    const observable = this._signalRService._init();
    return observable.pipe(switchMap((r) => {
      return forkJoin([
        this._signalRService.joinEvent(),
        this._userService.getUserDetail(),
        this._userService.getUserSettings(),
        this._eventService.getEvent(),
        this._eventService.getSchedules(),
        this._eventService.getSponsors(),
        this._eventService.getRooms(),
        this._eventService.getAttendees()
      ]).pipe(map(([signInRes, user, event, rooms]) => ({
        signInRes,
        user,
        event,
        rooms
      })))
    }), catchError(error => this.handleError(error)))
  }

  private handleError(response: any): Observable<any> {
    this._messageService.showErrorMessage('Sorry! An error occurred while connecting the server.')
    return of(response)
  }
}
