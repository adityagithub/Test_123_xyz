import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, ValidatorFn, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { NgxDropzoneChangeEvent, NgxDropzoneModule } from 'ngx-dropzone';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { CommandType, SignalDataModel, SignalLevel } from 'src/app/shared/models/signalr.models';
import { EventService } from 'src/app/shared/services/event.service';
import { MessageService } from 'src/app/shared/services/message.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { UserModel } from '../../../shared/models/user.model';
import { UserService } from '../../../shared/services/user.service';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { MaterialModule } from 'src/app/core/material.module';
import { NicknameEditorComponent } from '../nickname-editor/nickname-editor.component';

@Component({
  selector: 'user-profile-dialog',
  templateUrl: './profile-dialog.component.html',
  styleUrls: ['./profile-dialog.component.scss'],
  encapsulation: ViewEncapsulation.None,
  standalone: true,
  imports: [
    FwCoreModule,
    MaterialModule,
    NgxSpinnerModule,
    NgxDropzoneModule,
    NicknameEditorComponent
  ]
})
export class ProfileDialogComponent implements OnInit {

  private _unsubscribeAll: Subject<any> = new Subject();

  constructor(
    private _formBuilder: FormBuilder,
    private _matDialogRef: MatDialogRef<ProfileDialogComponent>,
    private _appSettings: AppSettingService,
    private _userService: UserService,
    private _signalrService: SignalrService,
    private _eventService: EventService,
    private _messageService: MessageService,
    private _spinnerService: NgxSpinnerService) { }

  user: UserModel;
  imagePath: string;
  personalInfoPicName: string = '';
  userProfileImageName: string;
  profileImgFile: File;

  profileForm: FormGroup;
  submitted = false;

  ngOnInit(): void {
    this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe(user => {
      this.user = user;
      this.createProfileForm(user);
      const avtrUrl = this.user.getAvatarUrl(this._appSettings.settings.resourceBaseUrl);
      if (avtrUrl) {
        fetch(avtrUrl).then(async res => {
          if (res) {
            const blob = await res.blob();
            if (blob.size) {
              this.profileImgFile = blob as File;
            }
          }
        });
      }
    });
  }

  private createProfileForm(user: UserModel) {
    if (!user) { return; }

    this.profileForm = this._formBuilder.group({
      avatar: [user.avatar],
      title: [user.title],
      firstName: [user.firstName, Validators.required],
      lastName: [user.lastName, Validators.required],
      email: [user.email, [Validators.required, Validators.email]],
      phone: [
        user.phone,
        [
          Validators.required,
          Validators.minLength(4),
          Validators.maxLength(15)
        ]
      ],
      about: [user.about]
    });
  }

  get f(): { [key: string]: AbstractControl } {
    return this.profileForm.controls;
  }

  async onSubmit(): Promise<void> {
    this.submitted = true;
    if (this.profileForm.invalid) {
      return;
    }
    this._spinnerService.show();
    const payload = this.profileForm.value as UserModel;
    if (this.profileImgFile) {
      payload.avatar = await this.toBase64(this.profileImgFile) as string;
      payload.profileImageName = this.userProfileImageName;
    }
    const status = await this._userService.updateUserDetail(payload);
    if (status) {
      this._spinnerService.hide();
      this._messageService.showSuccessMessage('Profile updated successfully.');
      const signalData = {
        command: CommandType.profileUpdated,
        receiverId: this._eventService.getEventId(),
        signalLevel: SignalLevel.event,
        data: {}
      } as SignalDataModel;
      await this._signalrService.sendSignal(signalData);
      //this._matDialogRef.close();
    } else {
      this._spinnerService.hide();
      this._messageService.showErrorMessage('Sorry!, An error occurred while updating profile information.');
    }
  }

  toBase64 = file => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
  });

  onReset(): void {
    this.submitted = false;
    this.profileForm.reset();
  }

  async onImageUpload(event: NgxDropzoneChangeEvent) {

    if (event.rejectedFiles?.length) {
      if (event.rejectedFiles[0].reason == 'size') {
        this._messageService.showErrorMessage('Sorry, Max 4MB file size allowed!');
      }
      if (event.rejectedFiles[0].reason == 'type') {
        this._messageService.showErrorMessage('Sorry, This file type is not supported!');
      }
    }

    if (event.addedFiles && event.addedFiles.length) {
      const reader = new FileReader();
      const file = event.addedFiles[0];
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.profileImgFile = file;
        this.userProfileImageName = file.name;
      };
    }
  }

  async deleteImage(): Promise<void> {
    // TODO
    this.personalInfoPicName = '';
  }

  async onRemoved(event: any): Promise<void> {
    this.profileImgFile = null;
    this.userProfileImageName = '';
  }

  stripText(event: { key: string; }) {
    const seperator = '^[- +()0-9]+';
    const maskSeperator = new RegExp(seperator, 'g');
    const result = maskSeperator.test(event.key); return result;
  }

  linkedInClicked() {
    this._userService.linkedInCall().pipe(takeUntil(this._unsubscribeAll)).subscribe(res => {
      if (res) {
        const win = window.open(res, '_blank');
        win.focus();
      }
    });
  }

  nicknameEditorEnabled(): boolean {
    return this._eventService.isNicknameEnabled();
  }
  
  getDetailedProfileLink(): string {
    return '/account/myaccount#/myaccount'
  }
}
