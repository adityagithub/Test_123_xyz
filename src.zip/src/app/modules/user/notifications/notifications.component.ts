import { SelectionModel } from '@angular/cdk/collections';
import {
  AfterViewInit, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewChild, ViewEncapsulation
} from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { CommandType, SignalDataModel } from 'src/app/shared/models/signalr.models';
import { EventService } from 'src/app/shared/services/event.service';
import { MessageService } from 'src/app/shared/services/message.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { UserService } from '../../../shared/services/user.service';
import { NotificationListModel, NotificationModel } from '../../../shared/models/notifications.models';
import { NotificationsService } from '../../../shared/services/notifications.service';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import { RouterModule } from '@angular/router';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { MaterialModule } from 'src/app/core/material.module';

@Component({
  selector: 'notifications',
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss'],
  encapsulation: ViewEncapsulation.None,
  standalone: true,
  imports: [
    RouterModule,
    MaterialModule,
    NgxSpinnerModule,
    FwCoreModule
  ]
})
export class NotificationsComponent implements OnInit, OnDestroy, AfterViewInit {
  notifications: NotificationModel[];
  displayedColumns: string[] = ['notificationId', 'sender', 'notificationMessage', 'notificationDate', 'isMarkedAsRead'];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  chkReadNotification: boolean = true;
  selection = new SelectionModel<NotificationModel>(true, []);
  showMarkAllAsReadButton: boolean;
  totalCount: number = 0;
  unreadCount = 0;
  dataSource: MatTableDataSource<NotificationModel>;
  isLoadingResults = true;
  isRateLimitReached = false;
  searchTerm: string;
  defaultData: NotificationModel[] = [];
  resourceBaseUrl: string;

  private _unsubscribeAll: Subject<any> = new Subject<any>();

  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _notificationsService: NotificationsService,
    private _messageService: MessageService,
    private _spinnerService: NgxSpinnerService,
    public dialogRef: MatDialogRef<NotificationsComponent>,
    private _userService: UserService,
    private _eventService: EventService,
    private _signalrService: SignalrService,
    private _appSettingService: AppSettingService
  ) {
    this.resourceBaseUrl = this._appSettingService.settings?.resourceBaseUrl;
  }

  ngOnInit(): void {
    this._notificationsService.notifications$.pipe(takeUntil(this._unsubscribeAll)).subscribe(data => {
      this.notifications = data.notifications;
      this.totalCount = data.meta.totalCount;
      this.notifications.forEach(n => {
        n.sender = this._eventService.findAttendee(n.notificationSentBy)
      });
      this.dataSource = new MatTableDataSource<NotificationModel>(this.notifications ?? []);
      this._changeDetectorRef.markForCheck();
    });
  }

  ngAfterViewInit(): void {
    this.paginator.page.pipe(takeUntil(this._unsubscribeAll)).subscribe(() => {
      this._loadNotificationData('');
    });

    // If the user changes the sort order, reset back to the first page.
    this.selection?.changed.asObservable()
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe(s => {
        this.showMarkAllAsReadButton = this.selection.selected.length > 0;
      });

    this._loadNotificationData('');

    this._signalrService.onNewSignal$.pipe(takeUntil(this._unsubscribeAll)).subscribe(async (res: SignalDataModel) => {
      if (!res) {
        return;
      }
      const currentUser = this._userService.getCurrentUser();
      if (res.receiverId === currentUser.userId || res.receiverIds?.includes(currentUser.userId)) {
        if (res.command === CommandType.newNotification) {
          this._loadNotificationData(this.searchTerm);
        }
      }
    });
  }

  ngOnDestroy(): void {
    if (this.dataSource) {
      this.dataSource.disconnect();
    }
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  applyFilter(search: string) {
    if (!search) {
      search = '';
    }
    this.dataSource.filter = search.trim().toLowerCase();
    this.dataSource.paginator = this.paginator;
    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

  markSelectedAsRead() {
    const ids = [];
    this.selection.selected.forEach((s) => ids
      .push(s.notificationId));

    if (ids.length > 0) {
      this._spinnerService.show();
      this.isLoadingResults = true;
      this._notificationsService.updateNotifications({ notificationIds: ids, isMarkedAsRead: true })
        .pipe(takeUntil(this._unsubscribeAll)).subscribe({
          next: (result) => {
            this._spinnerService.hide();
            this.isLoadingResults = false;
            if (result) {
              this._messageService.showSuccessMessage('Notification(s) marked as read.');
            } else {
              this._messageService.showErrorMessage('An error occurred while updating notification status.');
            }
          },
          error: () => {
            this._spinnerService.hide();
            this.isLoadingResults = false;
            this._messageService.showErrorMessage('An error occurred while updating notification status.');
          }
        })
    }
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.notifications.length;
    return numSelected === numRows;
  }

  masterToggle() {
    this.isAllSelected()
      ? this.selection.clear()
      : this.notifications.forEach((row) => this.selection.select(row));
  }

  toggleRead(notification: NotificationModel): void {
    notification.isMarkedAsRead = !notification.isMarkedAsRead;
    this._notificationsService.updateNotifications({ notificationIds: [notification.notificationId], isMarkedAsRead: notification.isMarkedAsRead })
      .pipe(takeUntil(this._unsubscribeAll)).subscribe();
  }

  delete(notification: NotificationModel): void {
    this._notificationsService.deleteNotification(notification.notificationId)
      .pipe(takeUntil(this._unsubscribeAll)).subscribe();
  }

  private _loadNotificationData(searchTerm: string) {
    this._spinnerService.show();
    this._notificationsService.getNotifications({
      search: searchTerm,
      onlyUnread: false,
      pageIndex: this.paginator.pageIndex,
      pageSize: this.paginator.pageSize
    }).pipe(takeUntil(this._unsubscribeAll)).subscribe({
      next: (data: NotificationListModel) => {
        this._spinnerService.hide();
      },
      error: (_err: any) => {
        this._spinnerService.hide();
      }
    });
  }
}
