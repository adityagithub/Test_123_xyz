import {
  AfterViewInit, ChangeDetectorRef, Component, ElementRef,
  OnDestroy, OnInit, TemplateRef, ViewChild, ViewContainerRef, ViewEncapsulation
} from '@angular/core';
import { Overlay, OverlayRef } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { appAnimations } from 'src/app/core/animations';
import { NotificationListModel, NotificationModel } from '../../../../shared/models/notifications.models';
import { NotificationsService } from '../../../../shared/services/notifications.service';
import { MatDialog } from '@angular/material/dialog';
import { UserService } from 'src/app/shared/services/user.service';
import { EventService } from 'src/app/shared/services/event.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { MaterialModule } from 'src/app/core/material.module';
import { TimeAgoPipe, CalendarPipe, FromUnixPipe, MomentModule } from 'ngx-moment';

@Component({
  selector: 'notifications-short-info',
  templateUrl: './short-info.component.html',
  styleUrls: ['./short-info.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: appAnimations,
  standalone: true,
  imports: [
    FwCoreModule,
    MaterialModule,
    NgxSpinnerModule,
    MomentModule
  ],
  providers: [
    TimeAgoPipe,
    CalendarPipe,
    FromUnixPipe
  ],
})
export class NotificationShortInfoComponent implements OnInit, OnDestroy, AfterViewInit {
  notifications: NotificationModel[];
  @ViewChild('notificationsOrigin') private _notificationsOrigin: ElementRef<any>;
  @ViewChild('notificationsPanel') private _notificationsPanel: TemplateRef<any>;
  unreadCount = 0;
  isDataLoading: boolean;
  panelOpened: boolean;
  resourceBaseUrl: string;
  private _overlayRef: OverlayRef;
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _notificationsService: NotificationsService,
    private _overlay: Overlay,
    private _viewContainerRef: ViewContainerRef,
    private _spinnerService: NgxSpinnerService,
    private _dialog: MatDialog,
    private _userService: UserService,
    private _eventService: EventService,
    private _signalrService: SignalrService,
    private _appSettingService: AppSettingService
  ) {
    this.resourceBaseUrl = this._appSettingService.settings?.resourceBaseUrl;
  }

  ngAfterViewInit(): void {

  }

  ngOnInit(): void {
    this._notificationsService.unreadNotifications$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((notif: NotificationListModel) => {
        this.notifications = notif.notifications;
        if (this.notifications) {
          this.unreadCount = notif.meta.totalCount;
          this.notifications.forEach(n => {
            n.sender = this._eventService.findAttendee(n.notificationSentBy)
          });
        }
        this._changeDetectorRef.detectChanges();
      });
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
    if (this._overlayRef) {
      this._overlayRef.dispose();
    }
  }

  openPanel(): void {
    if (!this._notificationsPanel || !this._notificationsOrigin) {
      return;
    }

    if (!this._overlayRef) {
      this._createOverlay();
    }
    this.panelOpened = true;
    this._overlayRef.attach(new TemplatePortal(this._notificationsPanel, this._viewContainerRef));
  }

  closePanel(): void {
    this.panelOpened = false;
    this._overlayRef.detach();
  }

  private _createOverlay(): void {
    this._overlayRef = this._overlay.create({
      hasBackdrop: true,
      backdropClass: 'fw-backdrop',
      scrollStrategy: this._overlay.scrollStrategies.block(),
      positionStrategy: this._overlay.position()
        .flexibleConnectedTo(this._notificationsOrigin.nativeElement)
        .withLockedPosition()
        .withDefaultOffsetX(54)
        .withPush(true)
        .withPositions([
          {
            originX: 'start',
            originY: 'bottom',
            overlayX: 'start',
            overlayY: 'bottom'
          },
          {
            originX: 'start',
            originY: 'top',
            overlayX: 'start',
            overlayY: 'bottom'
          },
          {
            originX: 'end',
            originY: 'bottom',
            overlayX: 'end',
            overlayY: 'top'
          },
          {
            originX: 'end',
            originY: 'top',
            overlayX: 'end',
            overlayY: 'bottom'
          }
        ])
    });

    this._overlayRef.backdropClick().subscribe(() => {
      this.panelOpened = false;
      this._overlayRef.detach();
      this._changeDetectorRef.detectChanges();
    });
  }

  openDetailsDialog() {
    import('../notifications.component').then(res => {
      this._dialog.open(res.NotificationsComponent, {
        panelClass: 'notification-list-dialog',
        data: {},
        hasBackdrop: true
      });
      this.closePanel();
    })
  }
}
