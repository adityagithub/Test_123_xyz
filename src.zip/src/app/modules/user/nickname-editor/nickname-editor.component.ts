import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { takeUntil, debounceTime, distinctUntilChanged, pairwise, Subject } from 'rxjs';
import { UserModel } from '../../../shared/models/user.model';
import { UserService } from '../../../shared/services/user.service';
import { MessageService } from 'src/app/shared/services/message.service';
import { CommandType, SignalDataModel, SignalLevel } from 'src/app/shared/models/signalr.models';
import { EventService } from 'src/app/shared/services/event.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { MaterialModule } from 'src/app/core/material.module';
import { FwCoreModule } from 'src/app/core/fw.core.module';

@Component({
  selector: 'user-nickname-editor',
  templateUrl: './nickname-editor.component.html',
  styleUrls: ['./nickname-editor.component.scss'],
  standalone: true,
  imports: [
    FwCoreModule,
    MaterialModule
  ],
  exportAs: 'user-nickname-editor'
})
export class NicknameEditorComponent implements OnInit {

  private _unsubscribeAll: Subject<any> = new Subject();
  @ViewChild('nickNameControl') nickNameViewRef: ElementRef;
  formGroup: FormGroup;

  @Input() user: UserModel;
  @Input() controlEnabled: boolean = true;

  constructor(
    private _eventService: EventService,
    private _formBuilder: FormBuilder,
    private _userService: UserService,
    private _messageService: MessageService,
    private _signalrService: SignalrService) {

  }


  ngOnInit(): void {
    this.createForm(this.user);
  }


  get f(): { [key: string]: AbstractControl } {
    return this.formGroup.controls;
  }


  nickNameEditable: boolean = false;
  editNickName(): void {
    this.f['nickName'].enable();
    this.nickNameViewRef?.nativeElement?.focus();
    this.nickNameEditable = true;
  }

  doneEditNickName(disable: boolean = true): void {
    let name = this.f['nickName'].getRawValue();
    if (!name) { return; }
    this._userService.saveNickName(name).pipe(takeUntil(this._unsubscribeAll)).subscribe(async s => {
      if (s && s.status) {
        this.user.nickName = name;
        this.nickNameEditable = false;
        this._userService.setCurrentUser(this.user);
        this._messageService.showSuccessMessage('Details have been updated successfully');
        if (disable) {
          this.f['nickName'].disable();
        }
        const signalData = {
          command: CommandType.profileUpdated,
          receiverId: this._eventService.getEventId(),
          signalLevel: SignalLevel.event,
          data: {}
        } as SignalDataModel;
        await this._signalrService.sendSignal(signalData);
      }
    })
  }

  doneEditNickNameAsync(disable: boolean = true): Promise<any> {
    return new Promise<any>((resolve, reject) => {
      try {
        let name = this.f['nickName'].getRawValue();
        if (!name) { reject({ status: false }); return; }
        this._userService.saveNickName(name).pipe(takeUntil(this._unsubscribeAll)).subscribe(s => {
          if (s && s.status) {
            this.user.nickName = name;
            this.nickNameEditable = false;
            this._userService.setCurrentUser(this.user);
            if (disable) {
              this.f['nickName'].disable();
            }            
          } 
          resolve(s);
        })
      } catch (e) {
        reject({status: false, message: e.message});
      }
    })
  }

  cancelEditNickName(disable: boolean = true): void {
    this.nickNameEditable = false;
    this.f['nickName'].setValue(this.user.getFullName());
    if (disable) {
      this.f['nickName'].disable();
    }
  }

  private createForm(user: UserModel) {
    if (!user) { return; }

    this.formGroup = this._formBuilder.group({
      nickName: [this.user.nickName, [Validators.required, Validators.minLength(2), Validators.maxLength(50)]]
    });

    let nickNameControl = this.formGroup.get('nickName');

    if (!this.controlEnabled) {
      nickNameControl.disable();
    }

    nickNameControl.valueChanges
      .pipe(
        takeUntil(this._unsubscribeAll),
        debounceTime(300),
        distinctUntilChanged(),
        pairwise()
      ).subscribe(([prev, next]: [string, string]) => {
        if (!next || next.length <= 1) { return; }
        this._userService.validateNickName(next)
          .pipe(takeUntil(this._unsubscribeAll))
          .subscribe({
            next: (d) => {
              if (d.available) {
                nickNameControl.setErrors({ 'available': true });
              } else {
                nickNameControl.setErrors({ 'alreadyExist': true });
              }
            },
            error: (err) => {
              console.log(err);
            }
          })
      });
  }

  isValid(): boolean {    
    return this.f?.nickName?.hasError('available') || !this.f?.nickName?.hasError('alreadyExist');
  }
}
