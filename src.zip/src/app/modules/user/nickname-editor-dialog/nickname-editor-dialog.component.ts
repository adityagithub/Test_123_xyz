import { Component, OnInit, ViewChild } from '@angular/core';
import { Subject, takeUntil } from 'rxjs';
import { UserService } from '../../../shared/services/user.service';
import { UserModel } from '../../../shared/models/user.model';
import { NicknameEditorComponent } from '../nickname-editor/nickname-editor.component';
import { NgxSpinnerModule, NgxSpinnerService } from 'ngx-spinner';
import { MessageService } from 'src/app/shared/services/message.service';
import { MatDialogRef } from '@angular/material/dialog';
import { CommandType, SignalDataModel, SignalLevel } from 'src/app/shared/models/signalr.models';
import { EventService } from 'src/app/shared/services/event.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { DonotShowNickNameSyncDataModel } from 'src/app/shared/models/shared.model';
import { SharedService } from 'src/app/shared/services/shared.service';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { MaterialModule } from 'src/app/core/material.module';

@Component({
  selector: 'fw-nickname-editor-dialog',
  templateUrl: './nickname-editor-dialog.component.html',
  styleUrls: ['./nickname-editor-dialog.component.scss'],
  standalone: true,
  imports: [
    FwCoreModule,
    MaterialModule,
    NgxSpinnerModule,
    NicknameEditorComponent
  ],
  exportAs: 'fw-nickname-editor-dialog'
})
export class NicknameEditorDialogComponent implements OnInit {

  private _unsubscribeAll: Subject<any> = new Subject();

  user: UserModel;
  @ViewChild(NicknameEditorComponent) nicknameEditor: NicknameEditorComponent;

  constructor(
    private _eventService: EventService,
    private _userService: UserService,
    private _spinnerService: NgxSpinnerService,
    private _messageService: MessageService,
    private _signalrService: SignalrService,
    private _sharedService: SharedService,
    private _matDilogRef: MatDialogRef<NicknameEditorDialogComponent>) {

  }

  ngOnInit(): void {
    this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe(user => {
      this.user = user;
    });
  }

  async onSubmit($event: any): Promise<void> {
    if (this.nicknameEditor.isValid()) {
      try{
      this._spinnerService.show();
      this.nicknameEditor.doneEditNickNameAsync(false)
        .then(async res => {
         
          this._spinnerService.hide();
          if(res && !res.status){
            this._messageService.showErrorMessage(res.message);
            return;
          }

          this._messageService.showSuccessMessage('Details have been updated successfully');

          const signalData = {
            command: CommandType.profileUpdated,
            receiverId: this._eventService.getEventId(),
            signalLevel: SignalLevel.event,
            data: {}
          } as SignalDataModel;
          await this._signalrService.sendSignal(signalData);

          this._matDilogRef.close();
        }, (rejected) => {
          this._messageService.showErrorMessage('Sorry! An error occurred while processing your request');
          this._spinnerService.hide();
        }).catch(err => {
          this._messageService.showErrorMessage('Sorry! An error occurred while processing your request');
          this._spinnerService.hide();
        });
      } catch(e) {
        this._spinnerService.hide();
      }
    }
  }

  doNotShowAgainCheckboxChanged(event: MatCheckboxChange): void {
    if (event.checked) {
      let minutesToExpire = 2*60;
      var expires = new Date(Date.now() + (minutesToExpire * 60 * 1000)).getTime();
      let item = new DonotShowNickNameSyncDataModel();
      item.expiry = expires;
      this._sharedService.donotShowNicknamePopup = item;
    } else {
      this._sharedService.donotShowNicknamePopup = null;
    }
  }
}
