import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ApiResponse } from 'src/app/shared/models/shared.model';
import { SilentAuctionModel } from './silent-auction.models';

@Injectable()
export class SilentAuctionService {
  constructor(private _httpClient: HttpClient) {
  }

  getSilentAuctions(): Promise<SilentAuctionModel[]> {
    return new Promise<SilentAuctionModel[]>((resolve, reject) => {
      this._httpClient.get<ApiResponse<SilentAuctionModel[]>>('api/event/silent-auctions')
        .subscribe({
          next: (res) => resolve(res.data),
          // eslint-disable-next-line prefer-promise-reject-errors
          error: (_err) => reject([])
        })
    });
  }
}
