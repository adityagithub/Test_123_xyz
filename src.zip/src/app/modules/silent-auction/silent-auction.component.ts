import { Component, Inject, OnInit } from '@angular/core';
import { Subject, takeUntil } from 'rxjs';
import { EventModel } from 'src/app/shared/models/event.model';
import { MessageService } from 'src/app/shared/services/message.service';
import { UserModel } from '../../shared/models/user.model';
import { UserService } from '../../shared/services/user.service';
import { SilentAuctionModel } from './silent-auction.models';
import { SilentAuctionService } from './silent-auction.service';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import { MaterialModule } from 'src/app/core/material.module';
import { NgxSpinnerModule } from 'ngx-spinner';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { CountdownModule } from 'ngx-countdown';

@Component({
  selector: 'silent-auction',
  templateUrl: './silent-auction.component.html',
  styleUrls: ['./silent-auction.component.scss'],
  standalone: true,
  imports: [
    MaterialModule,
    NgxSpinnerModule,
    FwCoreModule,
    CountdownModule
  ],
  providers: [SilentAuctionService]
})
export class SilentAuctionComponent implements OnInit {
  eventData: EventModel;
  currentUser: UserModel;
  resourceBaseUrl: string;

  private _unsubscribeAll: Subject<any> = new Subject();

  dataLoading = false;
  filteredSilentAuctions: SilentAuctionModel[] = [];
  silentAuctions: SilentAuctionModel[] = [];
  constructor(
    private _settingService: AppSettingService,
    private _userService: UserService,
    private _auctionService: SilentAuctionService,
    private _messageService: MessageService) {
    this.resourceBaseUrl = this._settingService.settings.resourceBaseUrl;
    this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe(user => {
      this.currentUser = user;
    });
  }

  async ngOnInit(): Promise<void> {
    const auctions = await this._auctionService.getSilentAuctions();
    this.dataLoading = false;
    this.silentAuctions = this.filteredSilentAuctions = auctions;
    this.filteredSilentAuctions.forEach(sa => {
      this.setCountdownFormat(sa);
    });
  }

  searchSilentAuctions(ev: any): void {
    this.silentAuctions = this.filteredSilentAuctions.filter(sa => sa.title.toLowerCase().includes(ev.target.value));
  }

  setCountdownFormat(sa: SilentAuctionModel): void {
    if (sa.timeRemaining > 0 && !sa.countdownFormat) {
      sa.totalHoursLeft = (sa.timeRemaining / 60 / 60);
      if (sa.timeRemaining > (24 * 60 * 60)) { // Greater than a day
        sa.countdownFormat = 'd\'d\':h\'h\':m\'m\':s\'s\'';
      } else if (sa.timeRemaining > (60 * 60)) { // Greater than an hour
        sa.countdownFormat = 'h\'h\':m\'m\':s\'s\'';
      } else if (sa.timeRemaining > 60) { // Greater than a minute
        sa.countdownFormat = 'm\'m\':s\'s\'';
      }
    }
  }

  onCountdownFinish(sa: SilentAuctionModel) {

  }
}
