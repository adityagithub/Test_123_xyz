import { ImageViewModel } from 'src/app/shared/models/event.model';

export interface CurrencyViewModel {
    currencyId: number;
    fullName: string;
    shortName: string;
    symbol: string;
}

export class SilentAuctionModel {
  auctionId: number;
  title: string;
  auctionImage: ImageViewModel;
  description: string;
  startDate: Date;
  endDate: Date;
  extensionDate: Date;
  totalBids: number;
  highestBids: number;
  timeRemaining: number;
  totalHoursLeft: number;
  status: string;
  currency: CurrencyViewModel;
  deleted: boolean;
  active: boolean;
  timeZone: string;
  timezoneAbrivation: string;
  urlLeftPart: string;
  auctionCustomUrl: string;
  fullAuctionUrl: string;
  countdownFormat: string = 'h\'h\':m\'m\':s\'s\'';
}
