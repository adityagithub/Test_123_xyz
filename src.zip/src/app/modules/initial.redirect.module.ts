
import { Component, NgModule } from '@angular/core';
import { ActivatedRoute, Router, RouterModule, Routes } from '@angular/router';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { RoomService } from './rooms/room/room.service';

@Component({
  template: ''
})
export class InitialRedirectComponent {
  constructor(
    private _route: ActivatedRoute,
    private _router: Router,
    private _roomService: RoomService) {
    this._roomService.getLobbyRoomDetails().subscribe(res => {
      if (res) {
        this._goToRoom(res.roomId);
      }
    });
  }

  private async _goToRoom(roomId: number): Promise<void> {
    const id = this._route.snapshot.paramMap.get('id');
    const t = this._route.snapshot.paramMap.get('t');
    const fullUrl = `/fireworks/${id}/${t}/r/${roomId}/lobby`;
    this._router.navigate([fullUrl]);
  }
}

export const routes: Routes = [
  {
    path: '**',
    component: InitialRedirectComponent
  }
];

@NgModule({
  declarations: [
    InitialRedirectComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    FwCoreModule
  ]
})
export class InitialRedirectModule { }
