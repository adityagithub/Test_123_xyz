import { Route } from '@angular/router';
import { ModernComponent } from 'app/modules/admin/pages/invoice/printable/modern/modern.component';

export const modernRoutes: Route[] = [
    {
        path     : '',
        component: ModernComponent
    }
];
