
export class AuthenticationRequest {
  eventId: number;
  browserToken: string;
  eventToken: string;
}

export class AuthenticationResponse extends AuthenticationRequest {
  accessToken: string;
}

export interface IUser {
  firstName: string;
  lastName: string;
  email: string;
}



export class UserAuthenticationRequest {
  eventId: number;
  firstName: string;
  lastName: string;
  email: string;
}

export class UserAuthenticationResponse extends UserAuthenticationRequest {
  status: boolean;
  message: string;
  virtualEventId: number;
  eventAccessToken: string;
}