import { NgModule } from '@angular/core';
import { AuthComponent } from './auth.component';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { AuthService } from './auth.service';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { AuthInterceptor } from './auth.interceptor';
import { NgxSpinnerModule } from 'ngx-spinner';
import { MaterialModule } from 'src/app/core/material.module';

@NgModule({
  declarations: [
    AuthComponent
  ],
  imports: [
    FwCoreModule,
    NgxSpinnerModule,
    MaterialModule
  ],
  providers: [
    AuthService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    }
  ]
})
export class AuthModule { }
