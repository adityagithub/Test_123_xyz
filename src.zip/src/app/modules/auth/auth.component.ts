import { Component, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { Subject, takeUntil } from 'rxjs';
import { FwSplashScreenService } from 'src/app/core/services/splash-screen.service';
import { MessageService } from 'src/app/shared/services/message.service';
import { IUser, UserAuthenticationRequest } from './auth.models';
import { AuthService } from './auth.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'fw-auth',
  templateUrl: './auth.component.html',
  styleUrls: ['./auth.component.scss']
})
export class AuthComponent implements OnInit, OnDestroy {

  private _unsubscribeAll: Subject<any> = new Subject();
  formGroup!: FormGroup;
  user: IUser;
  eventId: string;

  constructor(
    private _route: ActivatedRoute,
    private _splashScreenService: FwSplashScreenService,
    private _authService: AuthService,
    private _messageService: MessageService,
    private _spinnerService: NgxSpinnerService) {
    this.user = {} as IUser;
    this.eventId = this._route.snapshot.paramMap.get('id');
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  ngOnInit(): void {
    this.formGroup = new FormGroup({
      firstName: new FormControl(this.user.firstName, [
        Validators.required,
        Validators.maxLength(50),
      ]),
      lastName: new FormControl(this.user.lastName, [
        Validators.required,
        Validators.maxLength(50),
      ]),
      email: new FormControl(this.user.email, [
        Validators.required,
        Validators.email,
        Validators.maxLength(100),
      ])
    });
  }

  get f(): { [key: string]: AbstractControl } {
    return this.formGroup.controls;
  }

  public validate(): void {
    if (this.formGroup.invalid) {
      for (const control of Object.keys(this.formGroup.controls)) {
        this.formGroup.controls[control].markAsTouched();
      }
      return;
    }

    this.user = this.formGroup.value;
    let req = this.user as UserAuthenticationRequest;
    req.eventId = Number(this.eventId);
    this._spinnerService.show();
    this._authService.emailLogin(req).pipe(takeUntil(this._unsubscribeAll))
      .subscribe((response) => {        
        if (response?.status) {
          this._authService.redirectToLobby(response.eventId, response.eventAccessToken);
        } else if(response.message) {
          this._messageService.showErrorMessage(response.message);  
          this._spinnerService.hide();        
        } else {
          this._messageService.showErrorMessage('Sorry! An error occurred while loggin in');
          this._spinnerService.hide();
        }
      });
  }
}
