import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { catchError, switchMap } from 'rxjs/operators';
import { FwUtils } from 'src/app/core/utils';
import { MessageService } from 'src/app/shared/services/message.service';
import { ApiResponse } from '../../shared/models/shared.model';
import {
  AuthenticationRequest,
  AuthenticationResponse,
  UserAuthenticationRequest,
  UserAuthenticationResponse
} from './auth.models';
import { Router } from '@angular/router';

@Injectable()
export class AuthService {
  private _accessToken: string;
  private _eventToken: string;

  private _authenticated: boolean = false;

  constructor(
    private _router: Router,
    private _httpClient: HttpClient,
    private _messageService: MessageService
  ) {
  }

  set accessToken(token: string) {
    this._accessToken = token;
  }

  get accessToken(): string {
    return this._accessToken || '';
  }

  set browserToken(token: string) {
    sessionStorage.setItem('sessionId', token);
  }

  get browserToken(): string {
    return sessionStorage.getItem('sessionId');
  }

  set eventToken(token: string) {
    this._eventToken = token;
  }

  get eventToken(): string {
    return this._eventToken || '';
  }

  check(): Observable<boolean> {
    if (this._authenticated) {
      return of(true);
    }

    if (this.accessToken) {
      return of(true);
    }

    return of(false);
  }

  get isAuthenticated(): boolean {
    return this._authenticated;
  }

  signIn(request: AuthenticationRequest): Observable<AuthenticationResponse> {
    if (this._authenticated) {
      return throwError(() => new Error('User is already logged in.'));
    }

    request.browserToken = this.browserToken || FwUtils.generateGUID();

    return this._httpClient.post('api/account/login', request)
      .pipe(switchMap((response: ApiResponse<AuthenticationResponse>) => {
        this.accessToken = response.data.accessToken;
        this.browserToken = request.browserToken;
        this.eventToken = request.eventToken;
        this._authenticated = true;
        return of(response.data);
      }), catchError((res: ApiResponse<AuthenticationResponse>) => {
        this._authenticated = false;
        sessionStorage.removeItem('sessionId');
        this._messageService.showErrorMessage(res.messages?.join())
        return of(res.data);
      }));
  }

  emailLogin(request: UserAuthenticationRequest): Observable<UserAuthenticationResponse> {    
    return this._httpClient.post('api/account/email-login', request)
      .pipe(switchMap((response: ApiResponse<UserAuthenticationResponse>) => {
        return of(response.data);
      }), catchError((res: ApiResponse<UserAuthenticationResponse>) => {
        this._messageService.showErrorMessage(res.messages?.join())
        return of(res.data);
      }));
  }

  signOut(): Observable<boolean> {
    sessionStorage.removeItem('sessionId');
    this._authenticated = false;
    return of(true);
  }

  redirectToSignInPage(): void {
    this._router.navigate(['/account/login']);
  }

  redirectToLobby(eventId: number, eventToken: string): void {
    const fullUrl = `/fireworks/${eventId}/${eventToken}/lobby`;
    this._router.navigateByUrl(fullUrl);
  }
}
