import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanActivateChild, RouterStateSnapshot } from '@angular/router';
import { Observable, of } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { AuthService } from 'src/app/modules/auth/auth.service';
import { AuthenticationRequest, AuthenticationResponse } from '../auth.models';
import { SharedService } from 'src/app/shared/services/shared.service';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate, CanActivateChild {
  constructor(
    private _authService: AuthService
  ) {
  }

  private _check(route: ActivatedRouteSnapshot): Observable<boolean> {
    const eventId = parseInt(route.paramMap.get('id'), 10);
    let token = route.paramMap.get('t');

    if (!eventId || !token) { return of(true); }

    //Make event access token a little big So that it can not easily read from browser addressbar
    let cloneToken = Object.assign({}, { token });
    if (cloneToken.token.length == 36) {
      [0, 1, 2, 3, 4, 5].forEach(k => cloneToken.token = btoa(cloneToken.token));
    }

    const param = new AuthenticationRequest();
    param.eventId = eventId;
    param.eventToken = cloneToken.token;
    SharedService.originalToken = token;
    SharedService.encriptedToken = cloneToken.token;

    return this._authService.check()
      .pipe(switchMap((authenticated) => {
        if (authenticated) { return of(true); }

        return this._authService.signIn(param)
          .pipe(switchMap((response: AuthenticationResponse) => {
            if (response && response.accessToken) {
              return of(true);
            }
            this._authService.redirectToSignInPage();
            //return of(false);
          }))
      }));
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    return this._check(route);
  }

  canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    return this._check(childRoute);
  }
}
