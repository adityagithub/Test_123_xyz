import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import { Subject, takeUntil } from 'rxjs';
import { EnumScheduleStatus, EventModel, EventScheduleModel } from 'src/app/shared/models/event.model';
import { PagerService } from 'src/app/shared/services/pager.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { EnumRoomType, RoomModel } from '../../room/room.models';
import { RoomService } from '../../room/room.service';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import { CustomizationService } from 'src/app/modules/warroom/customization/customization.service';

@Component({
  selector: 'lobby-room-box',
  templateUrl: './room-box.component.html',
  styleUrls: ['./room-box.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class RoomBoxComponent implements OnInit, OnDestroy {
  private _unsubscribeAll: Subject<any> = new Subject();
  private _roomData: RoomModel;
  private _schedules: EventScheduleModel[];
  private _eventData: EventModel;

  constructor(
    private _appConfig: AppSettingService,
    private _router: Router,
    private _activatedRoute: ActivatedRoute,
    private _roomService: RoomService,
    private _pagerService: PagerService,
    private _sharedService: SharedService,
    private _customizationService: CustomizationService,
    private _changeDetectorRef: ChangeDetectorRef) {
  }

  pager: any = {};
  pagedItems: RoomModel[];
  isSimpleRoom = false;
  booths: RoomModel[];
  isRoomLive = false;
  joinRoomUrl: string;
  defaultRoomBackgroundUrl: string;

  ngOnInit(): void {
    this._customizationService.customization$.pipe(takeUntil(this._unsubscribeAll))
    .subscribe(res => {
      if (res) {
        this.defaultRoomBackgroundUrl = res.roomBackgroundImageUrl;
        this._changeDetectorRef.detectChanges();
      }
    });
  }

  @Input() set roomData(value: RoomModel) {
    this._roomData = value;
    if (this.roomData) {
      if (this.roomData.roomType === EnumRoomType.stage ||
        this.roomData.roomType === EnumRoomType.keynote ||
        this.roomData.roomType === EnumRoomType.greenRoom) {
        this.isSimpleRoom = true;
      } else {
        this.isSimpleRoom = false;
        this.booths = this.roomData.booths;
        this.setPage(1);
      }
    }
  }

  get roomData(): RoomModel {
    return this._roomData;
  }

  @Input() set schedules(value: EventScheduleModel[]) {
    this._schedules = value;
  }

  @Input() set eventData(value: EventModel) {
    this._eventData = value;
  }

  get eventData(): EventModel {
    return this._eventData;
  }

  get schedules(): EventScheduleModel[] {
    return this._schedules;
  }

  async goToRoom(roomId: number): Promise<void> {
    const id = this._activatedRoute.snapshot.paramMap.get('id');
    const t = this._activatedRoute.snapshot.paramMap.get('t');
    const url = await this._roomService.getJoinRoomUrl(roomId);
    this._sharedService.enableAutoJoinRoom(true);
    const fullUrl = `/fireworks/${id}/${t}/${url}`;
    this._router.navigate([fullUrl]);
  }

  setPage(page: number): void {
    this.pager = this._pagerService.getPager(this.booths.length, page, 1);
    this.pagedItems = this.booths.slice(this.pager.startIndex, this.pager.endIndex + 1);
  }

  isExpoBooth(roomData: RoomModel): boolean {
    return roomData.roomType === EnumRoomType.expo || roomData.roomType === EnumRoomType.expoBooth;
  }

  getScheduleStatus(room: RoomModel): string {
    let scheduleStatus = EnumScheduleStatus.closed;
    if (room && this.schedules) {
      const currentDateTimestamp = Date.parse(moment.utc().format());
      this.isRoomLive = this.schedules
        .some(s => s.roomId === room.roomId &&
          Date.parse(moment.utc(s.startDateUtc).format()) <= currentDateTimestamp &&
          Date.parse(moment.utc(s.endDateUtc).format()) > currentDateTimestamp);
      this._changeDetectorRef.markForCheck();

      if (this.isRoomLive) {
        scheduleStatus = EnumScheduleStatus.inProgress;
      } else if (this.schedules
        .some(s => s.roomId === room.roomId &&
          Date.parse(moment.utc(s.startDateUtc).format()) > currentDateTimestamp)) {
        scheduleStatus = EnumScheduleStatus.upcoming;
      } else {
        scheduleStatus = EnumScheduleStatus.closed;
      }
    }
    return scheduleStatus;
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  getBackgroundImageUrl(room: RoomModel): string {
    let roomBackgroundUrl = '';
    if (room) {
      if (room.settings.backgroundImageEnabled && room.backgroundImage) {
        roomBackgroundUrl = this._appConfig.settings.resourceBaseUrl + room.backgroundImage.imagePath;
      } else if (room.thumbImage) {
        roomBackgroundUrl = this._appConfig.settings.resourceBaseUrl + room.thumbImage.imagePath;
      } else if (room.mediaType && room.mediaType.toLowerCase() === 'image' && room.roomImage) {
        roomBackgroundUrl = this._appConfig.settings.resourceBaseUrl + room.roomImage.imagePath;
      } else if (this._eventData &&
        this._eventData.settings.backgroundImageEnabled &&
        this._eventData.backgroundImagePath) {
        roomBackgroundUrl = this._appConfig.settings.resourceBaseUrl + this._eventData.backgroundImagePath;
      } else {
        roomBackgroundUrl = this.defaultRoomBackgroundUrl;
      }
    }
    return roomBackgroundUrl;
  }
}
