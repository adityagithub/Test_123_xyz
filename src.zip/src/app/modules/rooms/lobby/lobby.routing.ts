import { Routes } from '@angular/router';
import { RoomDetailsResolver } from '../room/room.resolvers';
import { LobbyComponent } from './lobby.component';

export const routes: Routes = [
  {
    path: '**',
    component: LobbyComponent,
    resolve: {
      roomData: RoomDetailsResolver
    }
  }
];
