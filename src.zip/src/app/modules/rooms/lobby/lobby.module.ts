import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MaterialModule } from 'src/app/core/material.module';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { PagerService } from 'src/app/shared/services/pager.service';
import { LobbyComponent } from './lobby.component';
import { routes } from './lobby.routing';
import { RoomBoxComponent } from './room-box/room-box.component';
import { HandoutsBoxComponent } from './handouts-box/handouts-box.component';

@NgModule({
  declarations: [
    LobbyComponent,
    RoomBoxComponent,
    HandoutsBoxComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    FwCoreModule,
    MaterialModule
  ],
  providers: [
    PagerService
  ]
})
export class LobbyModule { }
