import { ChangeDetectorRef, Component, ElementRef, HostBinding, Inject, OnDestroy, OnInit, QueryList, ViewChildren } from '@angular/core';
import { Subject, takeUntil } from 'rxjs';
import {
  EventSponsorModel, EventSpeakerModel,
  EventHandoutsModel, EventModel, EventScheduleModel
} from 'src/app/shared/models/event.model';
import { EventService } from 'src/app/shared/services/event.service';
import { UserService } from '../../../shared/services/user.service';
import { EnumRoomType, RoomModel, RoomType } from 'src/app/modules/rooms/room/room.models';
import { UserModel } from '../../../shared/models/user.model';
import { PagerService } from 'src/app/shared/services/pager.service';
import { RoomService } from '../room/room.service';
import { MessageService } from 'src/app/shared/services/message.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CommandType, SignalDataModel } from 'src/app/shared/models/signalr.models';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { MatDialog } from '@angular/material/dialog';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';

@Component({
  selector: 'fw-lobby',
  templateUrl: './lobby.component.html',
  styleUrls: ['./lobby.component.scss']
})
export class LobbyComponent implements OnInit, OnDestroy {
  private _unsubscribeAll: Subject<any> = new Subject();

  currentUser: UserModel;
  eventData: EventModel;
  roomData: RoomModel;
  resourcesLoading = false;
  currentDownloadUrl: string;

  rooms: RoomModel[];
  simpleRooms: RoomModel[];
  multiBoothRooms: RoomModel[];

  speakerPager: any = {};
  speakerPagedItems: any[];

  sponsorPager: any = {};
  sponsorPagedItems: any[];

  handoutsPager: any = {};
  handoutsPagedItems: any[];

  showColumn3 = false;

  sponsors: EventSponsorModel[];
  speakers: EventSpeakerModel[];
  schedules: EventScheduleModel[];
  handouts: EventHandoutsModel[];
  handout: any;

  @ViewChildren('downloadButton') downloadButtons: QueryList<ElementRef<any>>;
  @HostBinding('class.dark') dark: boolean = true;

  constructor(
    private _appConfig: AppSettingService,
    private _dialog: MatDialog,
    private _router: Router,
    private _route: ActivatedRoute,
    private _changeDetectorRef: ChangeDetectorRef,
    private _pagerService: PagerService,
    private _eventService: EventService,
    private _userService: UserService,
    private _roomService: RoomService,
    private _sharedService: SharedService,
    private _messageService: MessageService,
    private _signalrService: SignalrService) {

  }

  async ngOnInit(): Promise<void> {
    this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe(user => {
      this.currentUser = user;
    });
    this._eventService.event$.pipe(takeUntil(this._unsubscribeAll)).subscribe(evnt => {
      this.eventData = evnt;
    });
    this._roomService.roomDetails$.pipe(takeUntil(this._unsubscribeAll)).subscribe({
      next: (room) => {
        this.roomData = room;
        this._changeDetectorRef.markForCheck();
      },
      error: (err) => {
        this._messageService.showErrorMessage(err);
      }
    });
    this._eventService.rooms$.pipe(takeUntil(this._unsubscribeAll)).subscribe(rooms => {
      const roomId = parseInt(this._route.snapshot.params.roomId);
      let boothId = 0;
      if (this._route.snapshot.params.boothId) {
        boothId = parseInt(this._route.snapshot.params.boothId);
      }
      this._roomService.getRoomDetails(boothId > 0 ? boothId : roomId).pipe(takeUntil(this._unsubscribeAll)).subscribe();
      this.rooms = rooms;
      this.updateLocalRoomsAndBooth();
    });
    this._eventService.schedules$.pipe(takeUntil(this._unsubscribeAll)).subscribe(schedules => {
      this.schedules = schedules;
      this.updateLocalRoomsAndBooth();
    });
    this._eventService.speakers$.pipe(takeUntil(this._unsubscribeAll)).subscribe(speakers => {
      this.speakers = speakers;
      this.setSpeakerPage(1);
    });
    this._eventService.sponsors$.pipe(takeUntil(this._unsubscribeAll)).subscribe(sponsors => {
      this.sponsors = sponsors;
      this.setSponsorPage(1);
    });
    this._eventService.handouts$.pipe(takeUntil(this._unsubscribeAll)).subscribe(handouts => {
      this.handouts = handouts;
      this.setHandoutsPage(1);
    });
    await this._registerSignalrEvents();
    await this._checkForAutoJoinBreakoutRoom();
  }

  private updateLocalRoomsAndBooth() {
    if (this.rooms) {
      const simpleRoomTypes: RoomType[] = [EnumRoomType.stage, EnumRoomType.keynote, EnumRoomType.greenRoom];
      this.simpleRooms = this.rooms.filter(r => r.settings.isEnabled &&
        r.settings.isRoomAccessible && simpleRoomTypes.includes(r.roomType));
      if (!this.currentUser.isHostOrCoHost()) {
        this.simpleRooms = this.simpleRooms.filter(r => r.roomType !== EnumRoomType.greenRoom);
      }

      const multiBoothRoomTypes: RoomType[] = [EnumRoomType.session, EnumRoomType.expo, EnumRoomType.networking];
      this.multiBoothRooms = this.rooms.filter(r => simpleRoomTypes.indexOf(r.roomType) === -1 &&
        r.settings.isEnabled && r.settings.isRoomAccessible && multiBoothRoomTypes.includes(r.roomType));
      if (!this.currentUser.isHostOrCoHost()) {
        this.multiBoothRooms.forEach(r => {
          const showBooth = r.settings.showBoothWhenTicketNotMatched;
          if (r.booths && r.booths.length) {
            r.booths = r.booths.filter(b => b.settings.isRoomAccessible || showBooth);
          }
        });
      }

      const cuustomRooms = this.rooms.filter(r => r.settings.isEnabled &&
        r.settings.isRoomAccessible && r.roomType === EnumRoomType.customRoom);
      if (cuustomRooms && cuustomRooms.length) {
        const customRoom = {
          roomName: 'Custom Rooms',
          roomType: EnumRoomType.customRoom,
          booths: cuustomRooms
        } as unknown as RoomModel;
        this.multiBoothRooms = [...this.multiBoothRooms, customRoom];
      }

      this._changeDetectorRef.markForCheck();
    }
  }

  async ngOnDestroy(): Promise<void> {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  setSpeakerPage(page: number): void {
    if (!this.speakers) return;
    this.speakerPager = this._pagerService.getPager(this.speakers.length, page, 4);
    this.speakerPagedItems = this.speakers.slice(this.speakerPager.startIndex, this.speakerPager.endIndex + 1);
    this._changeDetectorRef.markForCheck();
  }

  setSponsorPage(page: number): void {
    if (!this.sponsors) return;
    this.sponsorPager = this._pagerService.getPager(this.sponsors.length, page, 2);
    this.sponsorPagedItems = this.sponsors.slice(this.sponsorPager.startIndex, this.sponsorPager.endIndex + 1);
    this._changeDetectorRef.markForCheck();
  }

  setHandoutsPage(page: number): void {
    if (!this.handouts) return;
    this.handoutsPager = this._pagerService.getPager(this.handouts.length, page, 4);
    this.handoutsPagedItems = this.handouts.slice(this.handoutsPager.startIndex, this.handoutsPager.endIndex + 1);
    this._changeDetectorRef.markForCheck();
  }

  private async _checkForAutoJoinBreakoutRoom(): Promise<void> {
    if (!this.currentUser.isHostOrCoHost()) {
      const breakoutRoom = await this._roomService.checkAndGetUserBreakoutRoom();
      const result = this._roomService.breakoutRoomActiveAndOpen(breakoutRoom);
      if (result && result.roomActiveAndOpen) {
        this._moveToBreakoutRoom(breakoutRoom.roomId, breakoutRoom.roomName);
      }
    }
  }

  private async _registerSignalrEvents(): Promise<void> {
    this._signalrService.onNewSignal$.pipe(takeUntil(this._unsubscribeAll)).subscribe(async (res: SignalDataModel) => {
      if (res && (res.receiverId === this.currentUser.userId || res.receiverIds?.includes(this.currentUser.userId))) {
        if (res.command === CommandType.moveToAnotherRoom) {
          await this._goToRoom(res.data.roomId);
        } else if (res.command === CommandType.openBreakoutRooms) {
          if (!this.currentUser.isHostOrCoHost()) {
            this._moveToBreakoutRoom(res.data.roomId, res.data.roomName);
          }
        }
      }
    });
  }

  private async _goToRoom(roomId: number): Promise<void> {
    const id = this._route.snapshot.paramMap.get('id');
    const t = this._route.snapshot.paramMap.get('t');
    const url = await this._roomService.getJoinRoomUrl(roomId);
    const fullUrl = `/fireworks/${id}/${t}/${url}`;
    this._router.navigate([fullUrl]);
  }

  private _moveToBreakoutRoom(roomId: number, roomName: string): void {
    const eId = this._route.snapshot.paramMap.get('id');
    const token = this._route.snapshot.paramMap.get('t');
    roomName = roomName.replace(/ /g, '-').toLowerCase();
    const url = `fireworks/${eId}/${token}/b/breakout/${roomId}/${roomName}`;
    this._sharedService.enableAutoJoinRoom(true);
    this._router.navigate([url]);
    this._dialog.closeAll();
  }
}
