import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { map, takeUntil, startWith } from 'rxjs/operators';

import { appAnimations } from 'src/app/core/animations';
import { EventService } from 'src/app/shared/services/event.service';
import { RoomModel } from '../room/room.models';
import { RoomService } from '../room/room.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { CommandType, SignalDataModel } from 'src/app/shared/models/signalr.models';
import { UserModel } from '../../../shared/models/user.model';
import { UserService } from '../../../shared/services/user.service';
import { MessageService } from 'src/app/shared/services/message.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'room-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: appAnimations
})
export class RoomListComponent implements OnInit, OnDestroy {
  roomData: RoomModel;
  booths: RoomModel[];
  filteredBooths: RoomModel[];
  searchTerm: string = '';
  currentUser: UserModel

  searchControl = new FormControl('');

  private _unsubscribeAll: Subject<any> = new Subject();

  constructor(
    private _route: ActivatedRoute,
    private _changeDetectorRef: ChangeDetectorRef,
    private _userService: UserService,
    private _eventService: EventService,
    private _roomService: RoomService,
    private _signalrService: SignalrService,
    private _messageService: MessageService,
    private _sharedService: SharedService,
    private _router: Router,
    private _matDialog: MatDialog
  ) {
  }

  async ngOnInit(): Promise<void> {

    this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe(user => {
      this.currentUser = user;
    });

    this._eventService.rooms$.pipe(takeUntil(this._unsubscribeAll)).subscribe(rooms => {
      if (rooms) {
        const roomId = parseInt(this._route.snapshot.params.roomId);
        let boothId = 0;
        if (this._route.snapshot.params.boothId) {
          boothId = parseInt(this._route.snapshot.params.boothId);
        }
        this._roomService.getRoomDetails(boothId > 0 ? boothId : roomId).pipe(takeUntil(this._unsubscribeAll)).subscribe();
      }
    });

    this._roomService.roomDetails$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe(room => {
        this.roomData = room;
        if (this.roomData && this.roomData.booths) {
          const showBooth = this.roomData.settings.showBoothWhenTicketNotMatched;
          this.filteredBooths = this.booths = this.roomData.booths.filter(b => b.settings.isRoomAccessible || showBooth);
        }
        this._changeDetectorRef.markForCheck();
      });

    this.searchControl.valueChanges
      .pipe(startWith(''), map(value => this._filterRoomsByTerm(value)))
      .pipe(takeUntil(this._unsubscribeAll)).subscribe();

    await this._registerSignalrEvents();
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  private _filterRoomsByTerm(search: string): void {
    const searchTerm = search?.toLowerCase();
    if (searchTerm === '') {
      this.filteredBooths = this.booths;
    } else {
      this.filteredBooths = this.booths.filter((booth) => {
        return booth.roomName.toLowerCase().includes(searchTerm) ||
          booth.vendorName?.toLowerCase().includes(searchTerm) ||
          booth.vendorHeadline?.toLowerCase().includes(searchTerm);
      });
    }
    this._changeDetectorRef.markForCheck();
  }

  private async _registerSignalrEvents(): Promise<void> {
    this._signalrService.onNewSignal$.pipe(takeUntil(this._unsubscribeAll)).subscribe(async (res: SignalDataModel) => {
      if (res && (res.receiverId === this.currentUser.userId || res.receiverIds?.includes(this.currentUser.userId))) {
        if (res.command === CommandType.moveToAnotherRoom) {
          if (this.roomData.roomId !== res.data.roomId) {
            await this._onMoveToAnotherRoomByHost(res.data.roomId);
          }
        } else if (res.command === CommandType.openBreakoutRooms) {
          if (!this.currentUser.isHostOrCoHost()) {
            this._moveToBreakoutRoom(res.data.roomId, res.data.roomName);
          }
        }
      }
    });
  }

  private _moveToBreakoutRoom(targetRoomId: number, roomName: string): void {
    if (this.roomData.roomId !== targetRoomId) {
      this._sharedService.enableMoveToAnotherRoomWithoutConfirmation(true);
      this._changeDetectorRef.detectChanges();
      roomName = roomName.replace(/ /g, '-').toLowerCase();
      const eId = this._route.snapshot.paramMap.get('id');
      const token = this._route.snapshot.paramMap.get('t');
      const url = `fireworks/${eId}/${token}/b/breakout/${targetRoomId}/${roomName}`;
      this._router.navigate([url], { replaceUrl: false });
      this._matDialog.closeAll();
    }
  }

  private async _onMoveToAnotherRoomByHost(targetRoomId: number): Promise<void> {
    this._sharedService.enableMoveToAnotherRoomWithoutConfirmation(true);
    this._changeDetectorRef.detectChanges();
    await this._goToRoom(targetRoomId);
  }

  private async _goToRoom(roomId: number): Promise<void> {
    const id = this._route.snapshot.paramMap.get('id');
    const t = this._route.snapshot.paramMap.get('t');
    const url = await this._roomService.getJoinRoomUrl(roomId);
    const fullUrl = `/fireworks/${id}/${t}/${url}`;
    this._router.navigate([fullUrl]);
  }
}
