import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MaterialModule } from 'src/app/core/material.module';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { LeaveRoomGuard } from '../room/room.guards';
import { RoomListItemComponent } from './list-item/list-item.component';
import { RoomListComponent } from './list.component';
import { routes } from './list.routing';

@NgModule({
  declarations: [
    RoomListComponent,
    RoomListItemComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    MaterialModule,
    FwCoreModule
  ],
  providers: [
    LeaveRoomGuard
  ]
})
export class RoomListModule {
}
