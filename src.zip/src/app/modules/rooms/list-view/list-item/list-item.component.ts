import {
  ChangeDetectorRef, Component,
  Input, OnDestroy, OnInit, ViewEncapsulation
} from '@angular/core';
import { Subject } from 'rxjs';
import { appAnimations } from 'src/app/core/animations';
import { RoomModel } from '../../room/room.models';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';

@Component({
  selector: 'room-list-item',
  templateUrl: './list-item.component.html',
  styleUrls: ['./list-item.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: appAnimations
})
export class RoomListItemComponent implements OnInit, OnDestroy {
  private _unsubscribeAll: Subject<any> = new Subject();
  private _boothData: RoomModel;
  boothBackgroundUrl: string;
  resourceBaseUrl:string;

  constructor(
    private _appConfig: AppSettingService,
    private _changeDetectorRef: ChangeDetectorRef
  ) {
    this.resourceBaseUrl = this._appConfig.settings.resourceBaseUrl;
  }

  async ngOnInit(): Promise<void> {

  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  @Input() set boothData(value: RoomModel) {
    this._boothData = value;
  }

  get boothData(): RoomModel {
    return this._boothData;
  }

  get boothLogoImageUrl(): string {
    let boothLogoImageUrl = 'assets/images/logos/ec-event.jpg';
    if(this.boothData.logoImage?.imagePath) {
      boothLogoImageUrl = this.resourceBaseUrl + this.boothData.logoImage.imagePath
    }
    return boothLogoImageUrl;
  }

  get boothThumbImageUrl(): string {
    let boothThumbImageUrl = 'assets/images/default_room.png';
    if(this.boothData.thumbImage?.imagePath) {
      boothThumbImageUrl = this.resourceBaseUrl + this.boothData.thumbImage.imagePath
    }
    return boothThumbImageUrl;
  }
}
