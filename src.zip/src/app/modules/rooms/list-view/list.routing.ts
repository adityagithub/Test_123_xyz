import { Routes } from '@angular/router';
import { RoomListComponent } from './list.component';
import { RoomComponent } from '../room/room.component';
import { RoomDetailsResolver } from '../room/room.resolvers';
import { LeaveRoomGuard } from '../room/room.guards';

export const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: RoomListComponent,
    resolve: {
      data: RoomDetailsResolver
    }
  },
  {
    path: ':boothId',
    component: RoomComponent,
    canDeactivate: [LeaveRoomGuard],
    resolve: {
      data: RoomDetailsResolver
    }
  }
];
