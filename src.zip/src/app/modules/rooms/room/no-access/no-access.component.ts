import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'no-access',
  templateUrl: './no-access.component.html',
  styleUrls: ['./no-access.component.scss']
})
export class RoomNoAccessComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }
}
