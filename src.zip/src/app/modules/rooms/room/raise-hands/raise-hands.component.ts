import {
  AfterViewInit,
  ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef,
  OnDestroy, OnInit, TemplateRef, ViewChild, ViewContainerRef, ViewEncapsulation
} from '@angular/core';
import { Overlay, OverlayRef } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { appAnimations } from 'src/app/core/animations';
import { UserService } from 'src/app/shared/services/user.service';
import { EventService } from 'src/app/shared/services/event.service';
import { UserModel, UserStatusEnum } from 'src/app/shared/models/user.model';
import { RoomService } from '../room.service';
import { ConferenceService } from '../conference/conference.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { CommandType, SignalDataContent, SignalDataModel, SignalLevel } from 'src/app/shared/models/signalr.models';
import { MessageService } from 'src/app/shared/services/message.service';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import { NgxSpinnerModule } from 'ngx-spinner';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { MaterialModule } from 'src/app/core/material.module';

@Component({
  selector: 'raise-hands',
  templateUrl: './raise-hands.component.html',
  styleUrls: ['./raise-hands.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: appAnimations,
  standalone: true,
  imports: [
    MaterialModule,
    FwCoreModule,
    NgxSpinnerModule
  ]
})
export class RaisedHandsComponent implements OnInit, OnDestroy, AfterViewInit {
  raisedHands: UserModel[];
  @ViewChild('raisedHandsOrigin') private _raisedHandsOrigin: ElementRef<any>;
  @ViewChild('raisedHandsPanel') private _raisedHandsPanel: TemplateRef<any>;
  raisedHandCount = 0;
  panelOpened: boolean;
  statusEnum = UserStatusEnum;
  resourceBaseUrl: string;
  private _overlayRef: OverlayRef;
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _overlay: Overlay,
    private _viewContainerRef: ViewContainerRef,
    private _messageService: MessageService,
    private _signalrService: SignalrService,
    private _userService: UserService,
    private _eventService: EventService,
    private _roomService: RoomService,
    private _settingService: AppSettingService,
    private _confereceService: ConferenceService
  ) {
    this.resourceBaseUrl = this._settingService.settings.resourceBaseUrl;
  }

  ngAfterViewInit(): void {
    this._signalrService.onNewSignal$.pipe(takeUntil(this._unsubscribeAll)).subscribe(async res => {
      if (res) {
        if (res.command === CommandType.raiseHand) {
          const userId = res.data.userId;
          const user = this._eventService.findAttendee(userId);
          if (user) {
            // const message = user.fullName + ' is raising their hand, please approve (their mic will turn on) or put into queue for approval later.';
            // this._messageService.showInfoMessage(message);
            user.roomId = res.data.roomId;
            user.roomName = this._eventService.findRoom(res.data.roomId)?.roomName;
            this._confereceService.addRaisedHandMember(user);
          }
        }
        if (res.command === CommandType.lowerHand) {
          const userId = res.data.userId;
          if (userId) {
            this._confereceService.removeRaisedHandMember(userId);
          }
        }
      }
    });
  }

  ngOnInit(): void {
    this._confereceService.raisedHands$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((hands: UserModel[]) => {
        this.raisedHands = hands;
        this.raisedHandCount = this.raisedHands?.length;
        this._changeDetectorRef.markForCheck();
      });

    this._signalrService.getRaisedHandAttendees(this._eventService.getEventId()).then(res => {
      if (res) {
        res.forEach(u => {
          const att = this._eventService.findAttendee(u.userId);
          if (att) {
            att.roomId = u.roomId;
            att.roomName = this._eventService.findRoom(u.roomId)?.roomName;
            att.raisedHand = true;
            this._confereceService.addRaisedHandMember(att);
          }
        });
        this._changeDetectorRef.markForCheck();
      }
    });
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
    if (this._overlayRef) {
      this.panelOpened = false;
      this._overlayRef.dispose();
    }
  }

  openPanel(): void {
    if (!this._raisedHandsPanel || !this._raisedHandsOrigin) {
      return;
    }

    if (this.panelOpened) {
      return;
    }

    if (!this._overlayRef) {
      this._createOverlay();
    }

    this._overlayRef.attach(new TemplatePortal(this._raisedHandsPanel, this._viewContainerRef));
    this.panelOpened = true;
  }

  closePanel(): void {
    this.panelOpened = false;
    this._overlayRef.detach();
    this._changeDetectorRef.markForCheck();
  }

  async approveRequest(attendee: UserModel): Promise<void> {
    const signalDataModel = {
      receiverId: attendee.userId,
      command: CommandType.raiseHandApproved,
      signalLevel: SignalLevel.person,
      data: {} as SignalDataContent
    } as SignalDataModel;
    await this._signalrService.sendSignal(signalDataModel);
    this._confereceService.removeRaisedHandMember(attendee.userId);
    this._messageService.showSuccessMessage('Raise hand request approved successfully.');
  }

  async rejectRequest(attendee: UserModel): Promise<void> {
    const signalDataModel = {
      receiverId: attendee.userId,
      command: CommandType.raiseHandRejected,
      signalLevel: SignalLevel.person,
      data: {} as SignalDataContent
    } as SignalDataModel;
    await this._signalrService.sendSignal(signalDataModel);
    this._confereceService.removeRaisedHandMember(attendee.userId);
    this._messageService.showSuccessMessage('Raise hand request approved successfully.');
  }

  async approveAllRequest(): Promise<void> {
    const memberIds = this.raisedHands.map(m => m.userId);
    const signalDataModel = {
      receiverIds: memberIds,
      command: CommandType.allRaisedHandApproved,
      signalLevel: SignalLevel.persons,
      data: {} as SignalDataContent
    } as SignalDataModel;
    await this._signalrService.sendSignalToUsers(signalDataModel);
    memberIds.forEach(m => this._confereceService.removeRaisedHandMember(m));
    this._messageService.showSuccessMessage('Raise hand request approved successfully.');
  }

  async rejectAllRequest(): Promise<void> {
    const memberIds = this.raisedHands.map(m => m.userId);
    const signalDataModel = {
      receiverIds: memberIds,
      command: CommandType.allRaisedHandRejected,
      signalLevel: SignalLevel.persons,
      data: {} as SignalDataContent
    } as SignalDataModel;
    await this._signalrService.sendSignalToUsers(signalDataModel);
    memberIds.forEach(m => this._confereceService.removeRaisedHandMember(m));
    this._messageService.showSuccessMessage('Raise hand request rejected successfully.');
  }

  private _createOverlay(): void {
    this._overlayRef = this._overlay.create({
      hasBackdrop: true,
      backdropClass: 'fw-backdrop',
      scrollStrategy: this._overlay.scrollStrategies.block(),
      positionStrategy: this._overlay.position()
        .flexibleConnectedTo(this._raisedHandsOrigin.nativeElement)
        .withLockedPosition()
        .withDefaultOffsetX(54)
        .withPush(true)
        .withPositions([
          {
            originX: 'start',
            originY: 'bottom',
            overlayX: 'start',
            overlayY: 'bottom'
          },
          {
            originX: 'start',
            originY: 'top',
            overlayX: 'start',
            overlayY: 'bottom'
          },
          {
            originX: 'end',
            originY: 'bottom',
            overlayX: 'end',
            overlayY: 'top'
          },
          {
            originX: 'end',
            originY: 'top',
            overlayX: 'end',
            overlayY: 'bottom'
          }
        ])
    });

    this._overlayRef.backdropClick().subscribe(() => {
      this.panelOpened = false;
      this._overlayRef.detach();
      this._changeDetectorRef.markForCheck();
    });
  }
}
