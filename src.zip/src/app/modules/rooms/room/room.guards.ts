import { Injectable } from '@angular/core'
import { MatDialog } from '@angular/material/dialog'
import { ActivatedRouteSnapshot, CanDeactivate, RouterStateSnapshot } from '@angular/router'
import { Observable, Subject } from 'rxjs'
import { ConfirmDialogComponent } from 'src/app/core/components/confirm-dialog/confirm-dialog.component'
import { ConfirmDialogComponentData } from 'src/app/core/components/confirm-dialog/confirm.dialog.models'
import { UserService } from 'src/app/shared/services/user.service'
import { SharedService } from 'src/app/shared/services/shared.service'
import { RoomComponent } from './room.component'
import { SignalrService } from 'src/app/shared/services/signalr.service'
import { RoomService } from './room.service'

@Injectable()
export class LeaveRoomGuard implements CanDeactivate<RoomComponent> {
  constructor(
    private _sharedService: SharedService,
    private _userService: UserService,
    private _signalService: SignalrService,
    private _roomService: RoomService,
    private _dialog: MatDialog) {

  }

  canDeactivate(component: RoomComponent, currentRoute: ActivatedRouteSnapshot, currentState: RouterStateSnapshot, nextState: any): Observable<boolean> | boolean {
    if (component.roomClientConnected) {
      const subject = new Subject<boolean>()

      if (this._sharedService.isMoveToAnotherRoomWithoutConfirmationEnabled()) {
        return true;
      }

      if (component.roomData.roomType === 'breakout' && !this._userService.getCurrentUser().isHostOrCoHost()) {
        const dialogRef = this._dialog.open(ConfirmDialogComponent, {
          data: {
            Title: 'Alert',
            Message: '<b class="text-warn">You cannot leave breakout room. </b>',
            CancelText: '',
            OkText: 'OK',
            CustomAction : 'Force Leave'
          } as ConfirmDialogComponentData
        });
        dialogRef.afterClosed().subscribe(async (result: any) => {
          let forceLeave = result == 'Force Leave';
          if (forceLeave) {
            await this._roomService.forceLeaveBreakoutRoom(component.roomData.roomId);
          }
          subject.next(forceLeave);
          subject.complete();
        });
        return subject.asObservable();
      }

      const dialogRef = this._dialog.open(ConfirmDialogComponent, {
        data: {
          Title: 'Please confirm',
          Message: 'Do you want to leave this room and join another room?',
          CancelText: 'No, stay',
          OkText: 'Yes, leave'
        } as ConfirmDialogComponentData
      })
      dialogRef.afterClosed().subscribe(async (result: boolean) => {
        subject.next(result)
        subject.complete();
        try {
          if (result) {
            this._dialog.closeAll();
            await this._signalService.leaveRoom({ roomId: component.roomData.roomId, roomType: component.roomData.roomType });
          }
        } catch (e) {
        }
      })
      return subject.asObservable();
    }

    return true;
  }
}
