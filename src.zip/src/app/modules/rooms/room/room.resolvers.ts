import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { Observable } from 'rxjs';
import { RoomModel } from 'src/app/modules/rooms/room/room.models';
import { RoomService } from './room.service';

@Injectable({
  providedIn: 'root'
})
export class RoomDetailsResolver implements Resolve<RoomModel> {
  constructor(
    private _roomService: RoomService
  ) {
  }

  resolve(route: ActivatedRouteSnapshot, _state: RouterStateSnapshot): Observable<RoomModel> {
    const roomId = parseInt(route.params.roomId);
    let boothId = 0;
    if (route.params.boothId) {
      boothId = parseInt(route.params.boothId);
    }
    const _private = route.params.roomtype === 'private';
    const _breakout = route.params.roomtype === 'breakout';
    return this._roomService.getRoomDetails(boothId > 0 ? boothId : roomId, _private, _breakout);
  }
}
