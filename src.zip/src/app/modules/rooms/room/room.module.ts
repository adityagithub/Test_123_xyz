import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CountdownModule } from 'ngx-countdown';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { MomentModule } from 'ngx-moment';
import { NgxSpinnerModule } from 'ngx-spinner';
import { MaterialModule } from 'src/app/core/material.module';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { ConferenceModule } from './conference/conference.module';
import { RoomCountdownComponent } from './countdown/countdown.component';
import { RoomNoAccessComponent } from './no-access/no-access.component';
import { RoomNoScheduleComponent } from './no-schedule/no-schedule.component';
import { RoomComponent } from './room.component';
import { LeaveRoomGuard } from './room.guards';
import { routes } from './room.routing';
import { MediaSettingsDialogComponent } from './media-settings/media-settings.component';
import { BreakoutRoomModule } from '../../warroom/breakout/breakout.module';
import { PollDialogComponent } from './polls/polls.component';
import { ManageAttendeeModule } from '../../warroom/manage-attendees/manage-attendee.module';
import { BroadcastMessageModule } from '../../warroom/broadcast-message/broadcast-message.module';

@NgModule({
  declarations: [
    RoomComponent,
    RoomNoAccessComponent,
    RoomNoScheduleComponent,
    RoomCountdownComponent,
    MediaSettingsDialogComponent,
    PollDialogComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    MaterialModule,
    FwCoreModule,
    ConferenceModule,
    NgxSpinnerModule,
    NgxDropzoneModule,
    CountdownModule,
    BreakoutRoomModule,
    ManageAttendeeModule,
    BroadcastMessageModule
  ],
  providers: [
    LeaveRoomGuard
  ]
})
export class RoomModule { }
