import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'no-room',
  templateUrl: './no-room.component.html',
  styleUrls: ['./no-room.component.scss']
})
export class NoRoomAvaialbleComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }
}
