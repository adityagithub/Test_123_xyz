import { Routes } from '@angular/router';
import { RoomComponent } from './room.component';
import { LeaveRoomGuard } from './room.guards';
import { RoomDetailsResolver } from './room.resolvers';

export const routes: Routes = [
  {
    path: '',
    component: RoomComponent,
    canDeactivate: [LeaveRoomGuard],
    resolve: {
      roomData: RoomDetailsResolver
    }
  }
];
