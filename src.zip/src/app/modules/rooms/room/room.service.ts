import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, firstValueFrom, Observable, of } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';
import { BreakoutRoomModel, BreakoutRoomValidationResult, EnumRoomType, PrivateRoomModel, RoomModel } from './room.models';
import { ApiResponse } from '../../../shared/models/shared.model';
import { EventService } from 'src/app/shared/services/event.service';
import { UserService } from '../../../shared/services/user.service';
import { EventPollModel, PollAnswerReport, PollUserAnswer } from 'src/app/shared/models/event.model';
import * as moment from 'moment';
import { addMinutes, differenceInSeconds } from 'date-fns';

@Injectable({
  providedIn: 'root'
})
export class RoomService {
  roomCountdown = 0;
  roomCountdownFormat = 'h\'h\':m\'m\':s\'s\'';
  private _roomDetails: BehaviorSubject<RoomModel> = new BehaviorSubject(null);
  private _roomDetailsOnDemand: BehaviorSubject<RoomModel> = new BehaviorSubject(null);
  private _breakoutRooms: BehaviorSubject<BreakoutRoomModel> = new BehaviorSubject(null);
  private _polls: BehaviorSubject<EventPollModel[]> = new BehaviorSubject(null);

  constructor(
    private _httpClient: HttpClient,
    private _userService: UserService,
    private _eventService: EventService) {
  }

  get roomDetails$(): Observable<RoomModel> {
    return this._roomDetails.asObservable()
  }

  get roomDetailsOnDemand$(): Observable<RoomModel> {
    return this._roomDetailsOnDemand.asObservable()
  }

  get breakoutRooms$(): Observable<BreakoutRoomModel> {
    return this._breakoutRooms.asObservable()
  }

  get polls$(): Observable<EventPollModel[]> {
    return this._polls.asObservable()
  }

  get currentRoom(): RoomModel {
    return this._roomDetails.value;
  }

  get currentRoomId(): number {
    return this._roomDetails.value.roomId;
  }

  getRoomDetails(roomId: number, _private: boolean = false, _breakout: boolean = false): Observable<RoomModel> {

    return this._httpClient.get<ApiResponse<RoomModel>>('api/room/details', {
      params: { roomId, _private, _breakout }
    }).pipe(map((res: ApiResponse<RoomModel>) => {
      if (res.data) {
        const user = this._userService.getCurrentUser();
        const isHostOrCoHost = this._userService.isHostOrCoHost(user);
        if (isHostOrCoHost || user.isSystemUser()) {
          res.data.settings.isRoomAccessible = true;
          if (res.data.booths && res.data.booths.length) {
            res.data.booths.forEach(b => { b.settings.isRoomAccessible = true });
          }
        }

        if (!isHostOrCoHost && !user.isSystemUser() && res.data && res.data.roomType === 'greenroom') {
          res.data.settings.isRoomAccessible = false;
        }
      }
      this._roomDetails.next(res.data);
      return res.data;
    }), switchMap((room) => {
      return of(room);
    }));
  }

  getRoomUrl(roomId: number, roomType: string, roomName: string, parentRoomId?: number) {
    if (!roomId || !roomType) { return ''; }

    switch (roomType) {
      case 'reception':
      case 'lobby': {
        return 'r/' + roomId + '/' + roomName.replace(/ /g, '-').toLowerCase();
      }
      case 'stage':
      case 'greenroom':
      case 'keynoteroom':
      case 'customroom': {
        return 's/' + roomId + '/' + roomName.replace(/ /g, '-').toLowerCase();
      }
      case 'expo':
      case 'session':
      case 'networking': {
        return 'm/' + roomId + '/' + roomName.replace(/ /g, '-').toLowerCase();
      }
      case 'expo_booth':
      case 'session_booth':
      case 'networking_booth': {
        return 'm/' + parentRoomId + '/' + roomName.replace(/ /g, '-').toLowerCase() + '/' + roomId;
      }
      default: {
        return undefined;
      }
    }
  }

  async getJoinRoomUrl(roomId: number): Promise<string> {
    const rooms = await firstValueFrom(this._eventService.rooms$);
    if (!rooms) { return ''; }
    const roomData = rooms.find(r => r.roomId === roomId);
    if (roomData) {
      return this.getRoomUrl(roomId, roomData.roomType, roomData.roomName);
    }
    const booths = rooms.flatMap(r => { return r.booths });
    const boothData = booths.find(r => r.roomId === roomId);
    const url = this.getRoomUrl(roomId, boothData?.roomType, boothData?.roomName, boothData?.parentRoomId);
    return url;
  }

  createPrivateRoom(room: PrivateRoomModel): Observable<PrivateRoomModel> {
    return this._httpClient
      .post<ApiResponse<PrivateRoomModel>>('api/room/createPrivateRoom', room)
      .pipe(map((res: ApiResponse<PrivateRoomModel>) => {
        return res.data;
      }), switchMap((room) => {
        return of(room);
      }));
  }

  createBreakoutRooms(roomData: BreakoutRoomModel) {
    return this._httpClient
      .post<ApiResponse<BreakoutRoomModel>>('api/room/createBreakoutRooms', roomData)
      .pipe(map((res: ApiResponse<BreakoutRoomModel>) => {
        return res.data;
      }), switchMap((room) => {
        return of(room);
      }));
  }

  getBreakoutRooms() {
    return this._httpClient
      .get<ApiResponse<BreakoutRoomModel>>('api/room/breakout-rooms')
      .pipe(map((res: ApiResponse<BreakoutRoomModel>) => {
        this._breakoutRooms.next(res.data);
        return res.data;
      }), switchMap((room) => {
        return of(room);
      }));
  }

  deleteBreakoutRooms(roomIds: number[]) {
    return this._httpClient
      .post<ApiResponse<boolean>>('api/room/deleteBreakoutRooms', { roomIds })
      .pipe(map((res: ApiResponse<boolean>) => {
        return res.data;
      }), switchMap((room) => {
        return of(room);
      }));
  }

  getPollDetail(pollId: number) {
    const promise = new Promise<EventPollModel>((resolve, reject) => {
      this._httpClient.get<ApiResponse<EventPollModel>>(`api/event/polls/${pollId}/details`)
        .subscribe({
          next: (res) => resolve(res.data),
          error: (err) => reject(err)
        })
    });
    return promise;
  }

  getPolls(roomId: number) {
    return this._httpClient
      .get<ApiResponse<EventPollModel[]>>('api/event/polls', { params: { roomId } })
      .pipe(map((res: ApiResponse<EventPollModel[]>) => {
        this._polls.next(res.data);
        return res.data;
      }), switchMap((room) => {
        return of(room);
      }));
  }

  getUserCompletedPollIds(roomId: number): Promise<number[]> {
    const myPromise = new Promise<number[]>((resolve, reject) => {
      this._httpClient.get<ApiResponse<number[]>>('api/event/polls/completed', { params: { roomId } })
        .subscribe({
          next: (res) => resolve(res.data),
          // eslint-disable-next-line prefer-promise-reject-errors
          error: (_err) => reject([])
        })
    });
    return myPromise;
  }

  getPollSummary(pollId: number): Promise<PollAnswerReport[]> {
    const myPromise = new Promise<PollAnswerReport[]>((resolve, reject) => {
      this._httpClient.get<ApiResponse<PollAnswerReport[]>>(`api/event/polls/${pollId}/summary`)
        .subscribe({
          next: (res) => resolve(res.data),
          // eslint-disable-next-line prefer-promise-reject-errors
          error: (_err) => reject([])
        })
    });
    return myPromise;
  }

  savePollResponse(poll: PollUserAnswer) {
    return this._httpClient
      .post<ApiResponse<PollAnswerReport[]>>('api/event/polls/save-answer', poll)
      .pipe(map((res: ApiResponse<PollAnswerReport[]>) => {
        return res.data;
      }), switchMap((pollReport) => {
        return of(pollReport);
      }));
  }

  getLobbyRoomDetails(): Observable<RoomModel> {
    return this._httpClient.get<ApiResponse<RoomModel>>('api/room/lobby')
      .pipe(map((res: ApiResponse<RoomModel>) => {
        if (res.data) {
          const user = this._userService.getCurrentUser();
          const isHostOrCoHost = this._userService.isHostOrCoHost(user);
          if (isHostOrCoHost) { res.data.settings.isRoomAccessible = true; }

          if (!isHostOrCoHost && res.data && res.data.roomType === 'greenroom') {
            res.data.settings.isRoomAccessible = false;
          }
        }
        this._roomDetails.next(res.data);
        return res.data;
      }), switchMap((room) => {
        return of(room);
      }));
  }

  addUserToPrivateRoom(room: any): Observable<boolean> {
    return this._httpClient
      .post<ApiResponse<boolean>>('api/room/AddUserToPrivateRoom', room)
      .pipe(map((res: ApiResponse<boolean>) => {
        return res.data;
      }));
  }

  async getLobbyRoomId(): Promise<number> {
    const rooms = await firstValueFrom(this._eventService.rooms$);
    if (!rooms) { return undefined; }
    const roomData = rooms.find(r => r.roomType === EnumRoomType.reception);
    return roomData?.roomId;
  }

  checkAndGetUserBreakoutRoom(): Promise<RoomModel> {
    const promise = new Promise<RoomModel>((resolve, reject) => {
      this._httpClient.get<ApiResponse<RoomModel>>('api/room/CheckAndGetUserBreakoutRoom')
        .subscribe({
          next: (res) => resolve(res.data),
          error: (err) => reject(err)
        })
    });
    return promise;
  }

  forceLeaveBreakoutRoom(breakoutRoomId: number): Promise<boolean> {
    const promise = new Promise<boolean>((resolve, reject) => {
      let body = { BreakoutRoomId: breakoutRoomId };
      this._httpClient.post<ApiResponse<boolean>>('api/room/ForceLeaveBreakoutRoom', body)
        .subscribe({
          next: (res) => resolve(res.data),
          error: (err) => reject(err)
        })
    });
    return promise;
  }

  

  breakoutRoomActiveAndOpen(roomData: RoomModel): BreakoutRoomValidationResult {
    const res = new BreakoutRoomValidationResult();
    if (!roomData) { return res; }
    if (roomData.roomType !== EnumRoomType.breakout) {
      return res;
    }
    if (!roomData.roomOpenDateUtc) { return res; }
    if (!roomData.isRoomOpen) { return res; }
    const roomOpenDateTimeUtc = Date.parse(moment.utc(roomData.roomOpenDateUtc).format());
    const endDateTime = Date.parse(moment.utc(addMinutes(roomOpenDateTimeUtc, roomData.roomEndTime)).format());
    const currentDateTimestamp = Date.parse(moment.utc().format());
    const difference = (endDateTime - currentDateTimestamp);
    if (!difference || difference <= 0) { return res; }

    res.remainingCountDown = differenceInSeconds(endDateTime, currentDateTimestamp);
    res.roomActiveAndOpen = true;
    return res;
  }

  getRemainingCounddownOfBreakoutRoom(roomData: RoomModel): number {
    const roomOpenDateTimeUtc = Date.parse(moment.utc(roomData.roomOpenDateUtc).format());
    const endDateTime = Date.parse(moment.utc(addMinutes(roomOpenDateTimeUtc, roomData.roomEndTime)).format());
    const currentDateTimestamp = Date.parse(moment.utc().format());
    const difference = (endDateTime - currentDateTimestamp);
    if (!difference || difference <= 0) { return 0; }
    const diffInSeconds = differenceInSeconds(endDateTime, currentDateTimestamp);
    return diffInSeconds;
  }

  updateRoomData(model: RoomModel): Observable<boolean> {
    return this._httpClient
      .post<ApiResponse<boolean>>('api/room/update', model)
      .pipe(map((res: ApiResponse<boolean>) => {
        return res.data;
      }), switchMap((status) => {
        return of(status);
      }));
  }
}
