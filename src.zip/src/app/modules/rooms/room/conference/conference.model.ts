export interface RecordingInfoPayload {

  state: "inactive" | "paused" | "recording";
  sid: string;
  timestamp: number;
  uid: string;
}
