import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { UserModel } from 'src/app/shared/models/user.model';
import { UserService } from 'src/app/shared/services/user.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { IMediaSettingsSerializable, MediaSettingsData } from '../media-settings/media-settings.models';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import { RecordingInfoPayload } from './conference.model';

@Injectable({
  providedIn: 'root'
})
export class ConferenceService {
  private _onRecordingStateChange: BehaviorSubject<RecordingInfoPayload> = new BehaviorSubject(null);
  private _onRoomJoined: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private _onRoomLeft: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private _onMediaSettingsUpdated: BehaviorSubject<IMediaSettingsSerializable> = new BehaviorSubject(null);
  private _members: BehaviorSubject<UserModel[]> = new BehaviorSubject(null);
  private _onMemberUpdated: BehaviorSubject<UserModel> = new BehaviorSubject(null);
  private _onRaisedHandsUpdated: BehaviorSubject<UserModel[]> = new BehaviorSubject(null);
  private _onAllowAttendeeToUnmute: BehaviorSubject<boolean> = new BehaviorSubject(false);
  private _conferenceMembers: UserModel[] = [];
  private _raisedHandList: UserModel[] = [];
  private _screenPresenterAppendId: number = 99999;
  private _whiteboardPresenterAppendId: number = 9999999;

  private _layoutWidth = 0;
  private _layoutHeight = 0;
  private _layoutMargin = 2
  private _layoutRatio: number = 3 / 4;

  constructor(
    private _httpClient: HttpClient,
    private _sharedService: SharedService,
    private _userService: UserService,
    private _settingService: AppSettingService
  ) {

  }

  get onRecordingStateChange$(): Observable<RecordingInfoPayload> {
    return this._onRecordingStateChange.asObservable()
  }

  get members$(): Observable<UserModel[]> {
    return this._members.asObservable()
  }

  get onMemberUpdated$(): Observable<UserModel> {
    return this._onMemberUpdated.asObservable();
  }

  get onRoomJoined$(): Observable<boolean> {
    return this._onRoomJoined.asObservable()
  }

  get onRoomLeft$(): Observable<boolean> {
    return this._onRoomLeft.asObservable()
  }

  get onMediaSettingsUpdated$(): Observable<IMediaSettingsSerializable> {
    return this._onMediaSettingsUpdated.asObservable()
  }

  get raisedHands$(): Observable<UserModel[]> {
    return this._onRaisedHandsUpdated.asObservable();
  }

  get allowAttendeeToUnmute$(): Observable<boolean> {
    return this._onAllowAttendeeToUnmute.asObservable();
  }

  async getMembers(): Promise<UserModel[]> {
    return this._conferenceMembers;
  }

  async getMembersCount(): Promise<number> {
    return this._conferenceMembers?.length;
  }

  async getMember(memberId: number): Promise<UserModel> {
    if (!memberId) {
      console.warn('conference.service -> getMember() param memberId got undefined!');
      return undefined;
    }

    return this._conferenceMembers?.find(x => x.userId === memberId);
  }

  addConfereceMember(att: UserModel): void {
    if (!att) {
      console.warn('conference.service -> addMember() param att got undefined!');
      return;
    }
    if (!this._conferenceMembers) {
      //console.warn('conference.service -> addMember() _conferenceMembers att got undefined!');
      return;
    }
    const index = this._conferenceMembers.findIndex(a => a.userId === att.userId);
    if (index > -1) {
      //console.warn('conference.service -> addMember() att already exists in _conferenceMembers!');
      return;
    }
    this._conferenceMembers = [...this._conferenceMembers, att];
    this._members.next(this._conferenceMembers);
  }

  updateConfereceMember(member: UserModel): void {
    const index = this._conferenceMembers?.findIndex(x => x.userId === member.userId);
    if (index === -1) {
      //console.warn('conference.service -> updateMember() member not found in _conferenceMembers!');
      return;
    }

    this._conferenceMembers[index] = member;
    this._onMemberUpdated.next(member);
    this._members.next(this._conferenceMembers);
  }

  updateConfereceMembers(atts: UserModel[]): void {
    if (!atts) {
      console.warn('conference.service -> updateMembers() param atts got undefined!');
      return;
    }
    this._conferenceMembers = atts;
    this._members.next(atts);
  }

  removeConfereceMember(userId: number): void {
    if (userId > 0) {
      this._conferenceMembers = this._conferenceMembers?.filter(r => r.userId !== userId);
      if (this._conferenceMembers.length === 1) {
        this._conferenceMembers.forEach(m => { m.pinned = false });
      }
      this._members.next(this._conferenceMembers);
    }
  }

  removeConfereceMembers(): void {
    this._conferenceMembers = [];
    this._members.next(this._conferenceMembers);
  }

  notifyRoomJoined() {
    this._onRoomJoined.next(true);
  }

  notifyRoomLeft() {
    this._onRoomLeft.next(true);
  }

  updateMediaSettings(settings: IMediaSettingsSerializable): void {
    this._sharedService.setDataInLocalStorage(MediaSettingsData.localStorageSettingKey, settings);
    this._onMediaSettingsUpdated.next(new MediaSettingsData(settings));
  }

  getMediaSetting(): MediaSettingsData {
    const obj = this._sharedService.getDataFromLocalStorage(MediaSettingsData.localStorageSettingKey);
    return new MediaSettingsData(obj)
  }

  getScreePresenterAppendId() {
    return this._screenPresenterAppendId;
  }

  getWhiteboardPresenterAppendId() {
    return this._whiteboardPresenterAppendId;
  }

  addRaisedHandMember(att: UserModel): void {
    if (!att) {
      console.warn('conference.service -> addMemberToRaiseHandList() param att got undefined!');
      return;
    }
    if (!this._raisedHandList) {
      console.warn('conference.service -> addMemberToRaiseHandList() _raisedHandList got undefined!');
      return;
    }
    const index = this._raisedHandList.findIndex(a => a.userId === att.userId);
    if (index > -1) {
      console.warn('conference.service -> addMemberToRaiseHandList() att already exists in _raisedHandList!');
      return;
    }

    const confereceMember = this._conferenceMembers.find(m => m.userId === att.userId);
    if (confereceMember) {
      confereceMember.raisedHand = true;
      this.updateConfereceMember(confereceMember);
    }

    this._raisedHandList = [...this._raisedHandList, att];
    this._onRaisedHandsUpdated.next(this._raisedHandList);
  }

  removeRaisedHandMember(userId: number): void {
    if (userId > 0) {
      const confereceMember = this._conferenceMembers.find(m => m.userId === userId);
      if (confereceMember) {
        confereceMember.raisedHand = false;
        this.updateConfereceMember(confereceMember);
      }
      this._raisedHandList = this._raisedHandList?.filter(r => r.userId !== userId);
      this._onRaisedHandsUpdated.next(this._raisedHandList);
    }
  }

  allowAttendeeToUnmute(allow: boolean): void {
    this._onAllowAttendeeToUnmute.next(allow);
  }

  async resizeLayout(rect: HTMLDivElement): Promise<void> {
    // get dimensions of dish
    await this._layoutDimensions(rect)

    // loop (i recommend you optimize this)
    let max = 0
    let i = 1
    while (i < 5000) {
      const area = await this._layoutArea(rect, i);
      if (area === false) {
        max = i - 1;
        break;
      }
      i += 2;
    }

    // remove margins
    max = max - (this._layoutMargin * 2);

    // set dimensions to all cameras
    await this._layoutResizer(rect, max);
  }

  notifyRecordingState(state: RecordingInfoPayload) {
    this._onRecordingStateChange.next(state);
  }

  private async _layoutDimensions(rect: HTMLDivElement): Promise<void> {
    this._layoutWidth = rect.offsetWidth - (this._layoutMargin * 2);
    this._layoutHeight = rect.offsetHeight - (this._layoutMargin * 2);
  }

  private async _layoutResizer(rect: HTMLDivElement, width: number): Promise<void> {
    for (let s = 0; s < rect.children.length; s++) {
      // camera fron dish (div without class)
      const element = rect.children[s] as HTMLDivElement;

      // custom margin
      element.style.margin = this._layoutMargin + 'px'

      // calculate dimensions
      element.style.width = width + 'px'
      element.style.height = (width * this._layoutRatio) + 'px'

      // to show the aspect ratio in demo (optional)
      element.setAttribute('data-aspect', this._layoutRatio.toString());
    }
  }

  private async _layoutArea(rect: HTMLDivElement, increment: number): Promise<any> {
    let i = 0;
    let w = 0;
    let h = increment * this._layoutRatio + (this._layoutMargin * 2);
    while (i < (rect.children.length)) {
      if ((w + increment) > this._layoutWidth) {
        w = 0;
        h = h + (increment * this._layoutRatio) + (this._layoutMargin * 2);
      }
      w = w + increment + (this._layoutMargin * 2);
      i++;
    }
    if (h > this._layoutHeight || increment > this._layoutWidth) return false;
    else return increment;
  }

  createRoomForWhiteboard(roomUUID: string): Promise<any> {
    let promise = new Promise<any>((resolve, reject) => {
      try {
        let headers = new HttpHeaders();
        headers = headers.set('token', this._settingService.settings.whiteboard.token);
        headers = headers.set('region', 'in-mum');
        headers = headers.set('Content-Type', 'application/json; charset=utf-8');
        let body = { isRecord: false };
        this._httpClient.post<any>(`${this._settingService.settings.whiteboard.baseUrl}/v5/rooms`, body, { headers: headers })
          .subscribe({
            next: (res) => {
              resolve(res);
            },
            error: (err) => {
              reject(err);
            }
          })
      } catch (err) {
        reject(err);
      }
    });
    return promise;
  }

  generateRoomTokenForWhiteboard(roomUUID: string): Promise<any> {
    let promise = new Promise<any>((resolve, reject) => {
      try {
        let headers = new HttpHeaders();
        headers = headers.set('token', this._settingService.settings.whiteboard.token);
        headers = headers.set('region', 'in-mum');
        headers = headers.set('Content-Type', 'application/json; charset=utf-8');
        let body = { "lifespan": 3600000, "role": "admin" };
        this._httpClient.post<any>(`${this._settingService.settings.whiteboard.baseUrl}/v5/tokens/rooms/${roomUUID}`, body, { headers: headers })
          .subscribe({
            next: (res) => {
              resolve(res);
            },
            error: (err) => {
              reject(err);
            }
          })
      } catch (err) {
        reject(err);
      }
    });
    return promise;
  }
}
