import {
  AfterViewInit, ChangeDetectorRef, Component, ElementRef, EventEmitter,
  Input, OnChanges, OnDestroy, OnInit, Output, Renderer2, SimpleChanges, ViewChild, ViewEncapsulation
} from '@angular/core';
import { NgxResizeResult } from 'ngx-resize';
import { Subject, interval, takeUntil } from 'rxjs';
import { UserModel } from 'src/app/shared/models/user.model';
import { UserService } from 'src/app/shared/services/user.service';
import { ConferenceService } from '../conference.service';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';

@Component({
  selector: 'video-box',
  templateUrl: './videobox.component.html',
  styleUrls: ['./videobox.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class VideoBoxComponent implements OnInit, AfterViewInit, OnChanges, OnDestroy {
  @Input() currentUser: UserModel;
  @Input() presenter: UserModel;
  @Input() showOptionMenu: boolean;
  @Output() pinStateChange = new EventEmitter();
  @Output() muted = new EventEmitter<boolean>();
  @Output() kickout = new EventEmitter<boolean>();
  @ViewChild('player') player: ElementRef;
  @ViewChild('avatar') avatar: ElementRef;
  isScreenClient: boolean;
  resourceBaseUrl: string;
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  displayName: string;
  volumeLevel: number;

  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _conferenceService: ConferenceService,
    private _renderer: Renderer2,
    private _userService: UserService,
    private _settingService: AppSettingService
  ) {
    this.resourceBaseUrl = this._settingService.settings.resourceBaseUrl;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if ('presenter' in changes) {
      this.displayName = this.presenter.fullName;
      this._changeDetectorRef.detectChanges();
      this._checkAndPlayMedia();
    }
  }

  ngOnInit(): void {
    this.isScreenClient = this.presenter.userId > this._conferenceService.getScreePresenterAppendId();
    this._changeDetectorRef.markForCheck();

    // When Current user Profile changes, this will update the required infomation
    this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe(user => {
      if (user && this.presenter.userId === user.userId) {
        this.presenter.firstName = user.firstName;
        this.presenter.lastName = user.lastName;
        this.presenter.fullName = user.getFullName();
        this.displayName = user.getFullName();
        this._changeDetectorRef.detectChanges();
      }
    });
  }

  ngAfterViewInit(): void {
    this._conferenceService.onMemberUpdated$.pipe(takeUntil(this._unsubscribeAll)).subscribe(member => {
      if (member && member.userId === this.presenter.userId) {
        this.presenter = member;
        this._changeDetectorRef.detectChanges();
        this._checkAndPlayMedia();
      }
    });

    interval(500)
      .pipe(takeUntil(this._unsubscribeAll)).subscribe(data => {
        if (this.presenter?.hasAudio) {
          this.presenter.volumeLevel = this.presenter.audioTrack?.getVolumeLevel();
          this._changeDetectorRef.markForCheck();
        }
      })
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  async onResized(event: NgxResizeResult): Promise<void> {
    if (event.width <= 180) {
      this.displayName = this.presenter.alt?.toUpperCase();
    } else {
      this.displayName = this.presenter.fullName
    }

    if (this.isScreenClient && event.width <= 280) {
      this.displayName = this.presenter.alt?.toUpperCase();
    }
    this._changeDetectorRef.markForCheck();
  }

  async togglePinScreen() {
    this.presenter.pinned = !this.presenter.pinned;
    this.pinStateChange.emit();
  }

  setAdioMuted(mute: boolean) {
    this.muted.emit(mute);
  }

  removeFromRoom() {
    this.kickout.emit();
  }

  private async _checkAndPlayMedia(): Promise<void> {
    this._renderer.removeClass(this.avatar.nativeElement, 'hide');

    if (this.presenter.localScreenTrack) {
      if (this.presenter.localScreenTrack.enabled) {
        this._renderer.addClass(this.avatar.nativeElement, 'hide');
        this.presenter.localScreenTrack.play(this.player.nativeElement, { fit: 'contain' });
      } else {
        this.presenter.localScreenTrack.stop();
      }
    }

    if (this.presenter.localVideoTrack) {
      if (this.presenter.localVideoTrack.enabled) {
        this.presenter.localVideoTrack.play(this.player.nativeElement, { fit: 'contain' });
        this._renderer.addClass(this.avatar.nativeElement, 'hide');
      } else {
        this.presenter.localVideoTrack.stop();
      }
    }

    // Remote User
    if (this.presenter.audioTrack) {
      if (!this.presenter.audioTrack.isPlaying) {
        this.presenter.audioTrack.play();
      }
    }
    if (this.presenter.videoTrack) {
      this._renderer.addClass(this.avatar.nativeElement, 'hide');
      this.presenter.videoTrack.play(this.player.nativeElement, { fit: 'contain' });
    }

    this._changeDetectorRef.detectChanges();
  }
}
