import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EventService } from 'src/app/shared/services/event.service';

@Injectable()
export class ReactionService {

  userId: string;
  emojiList = ['like', 'love', 'wow', 'haha', 'sad', 'angry']

  constructor(private db: EventService) {
   
  }

  getReactions(itemId): Observable<any> {
    //return this.db.object(`reactions/${itemId}`)
    return {} as Observable<any>;
  }

  updateReaction(itemId, reaction=0) {
    const data = { [this.userId]: reaction }
    //this.db.object(`reactions/${itemId}`).update(data);
    return {} as Observable<any>;
  }

  removeReaction(itemId) {
    //this.db.object(`reactions/${itemId}/${this.userId}`).remove()
    return {} as Observable<any>;
  }
}