import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Subject, takeUntil } from 'rxjs';
import { CustomizationService } from 'src/app/modules/warroom/customization/customization.service';
import { SharedService } from 'src/app/shared/services/shared.service';

@Component({
  selector: 'room-standby',
  templateUrl: './standby.component.html',
  styleUrls: ['./standby.component.scss']
})
export class RoomStandbyComponent implements OnInit {

  private _unsubscribeAll: Subject<any> = new Subject();
  standbyImageUrl: string;

  constructor(
    private _cdr: ChangeDetectorRef,
    private _sharedService: SharedService,
    private _customizationService: CustomizationService) {

  }

  async ngOnInit(): Promise<void> {
    this._customizationService.customization$.pipe(takeUntil(this._unsubscribeAll))
      .subscribe(res => {
        if (res) {
          this.standbyImageUrl = res.standbyBackgroundImageUrl;
          this._cdr.detectChanges();
        }
      });
  }
}
