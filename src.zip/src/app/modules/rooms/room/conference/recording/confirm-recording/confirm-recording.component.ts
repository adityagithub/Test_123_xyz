import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { NgxSpinnerService } from 'ngx-spinner';
import { MessageService } from 'src/app/shared/services/message.service';

@Component({
  templateUrl: './confirm-recording.component.html',
  styles: [' #confirm-recording-dialog .mat-mdc-form-field-subscript-wrapper { height:0 !important; } ']
})
export class ConfirmRecordingComponent {
  fileName: string;

  constructor(
    private _spinnerService: NgxSpinnerService,
    private _messageService: MessageService,
    public dialogRef: MatDialogRef<ConfirmRecordingComponent>
  ) {
  }

  cancel(e: any) {
    e.preventDefault();
    this.dialogRef.close({ status: false, fileName: '' })
  }

  submit(e: any) {
    e.preventDefault();
    if (!this.fileName) {
      this._messageService.showErrorMessage("FileName is required");
      return;
    }
    this._spinnerService.show();
    this._spinnerService.hide();
    this.dialogRef.close({ status: true, fileName: this.fileName });
  }
}
