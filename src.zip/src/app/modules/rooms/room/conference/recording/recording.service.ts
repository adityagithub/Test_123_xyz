import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, map } from 'rxjs';
import { ApiResponse } from 'src/app/shared/models/shared.model';

@Injectable({
  providedIn: 'root'
})
export class RecordingService {

  constructor(
    private _httpClient: HttpClient
  ) {
  }

  startRecording(roomId: number, webPageUrl: string, onHold: boolean): Observable<StartRecordingResult> {
    return this._httpClient.post<ApiResponse<StartRecordingResult>>(`api/room/recording/start`, { roomId, webPageUrl, onHold })
      .pipe(map((res) => {
        return res.data;
      }))
  }

  updateRecording(roomId: number, sid: string, webPageUrl: string, onHold: boolean, fileTitle: string): Observable<any> {
    return this._httpClient.post(`api/room/recording/update`, { roomId, sid, webPageUrl, onHold, fileTitle })
      .pipe(map((res) => {
        return res;
      }))
  }

  queryRecording(roomId: number, sid: string): Observable<any> {
    return this._httpClient.post(`api/room/recording/status`, { roomId, sid })
      .pipe(map((res) => {
        return res;
      }))
  }

  stopRecording(roomId: number, sid: string): Observable<any> {
    return this._httpClient.post(`api/room/recording/stop`, { roomId, sid })
      .pipe(map((res) => {
        return res;
      }))
  }
}

export interface StartRecordingResult {
  cname: string;
  uid: string;
  sid: string;
  code: string;
  reason: string;
  status: number;
}

export enum AgoraRecordingStatus {
  'initiated' = 0,
  'started' = 1
}; 