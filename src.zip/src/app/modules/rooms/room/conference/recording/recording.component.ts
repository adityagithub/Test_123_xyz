import {
  AfterViewInit, ChangeDetectorRef, Component, EventEmitter,
  HostListener, Input, OnDestroy, OnInit, Output
} from '@angular/core';
import { Subject, takeUntil } from 'rxjs';
import { UserModel } from 'src/app/shared/models/user.model';
import { RoomModel } from '../../room.models';
import { RecordingService, AgoraRecordingStatus } from './recording.service';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmRecordingComponent } from './confirm-recording/confirm-recording.component';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { CommandType, SignalDataContent, SignalDataModel, SignalLevel } from 'src/app/shared/models/signalr.models';
import { RecordingInfoPayload } from '../conference.model';
import { MessageService } from 'src/app/shared/services/message.service';
import { MaterialModule } from 'src/app/core/material.module';
import { FwCoreModule } from 'src/app/core/fw.core.module';

@Component({
  selector: 'fw-recording',
  templateUrl: './recording.component.html',
  styleUrls: ['./recording.component.scss'],
  standalone: true,
  imports:[
    MaterialModule,
    FwCoreModule
  ]
})
export class FwRecordingComponent implements OnInit, OnDestroy, AfterViewInit {

  recordingState: RecordingState;
  timeElapsedCounter = 0;
  intervalId: any;
  timeElapsedCounterDisplay: string;
  _unsubscribeAll: Subject<any> = new Subject<any>();
  showRecordingOptions: boolean;
  uid: string;
  sid: string;
  fileTitle: string;
  @Input() roomData: RoomModel;
  @Input() user: UserModel;
  showLoader: boolean = false;
  isBeingRecorded: boolean;
  waitingForFilenameInputPopup: boolean;
  showInnerLoader: boolean = false;

  @Output() recordingStageChange: EventEmitter<RecordingInfoPayload> = new EventEmitter();

  constructor(
    private _matDialog: MatDialog,
    private _changeDetectorRef: ChangeDetectorRef,
    private _recordingService: RecordingService,
    private _signalrService: SignalrService,
    private _messageService: MessageService) {
  }


  ngOnInit(): void {
    this._signalrService.onNewSignal$.pipe(takeUntil(this._unsubscribeAll)).subscribe(async (res: SignalDataModel) => {
      if (!res) {
        return;
      }
      if (res.command == CommandType.recordingStateChange && this.roomData.roomId === res.data.roomId) {
        if (res.data.extra) {

          let ex = res.data.extra as RecordingInfoPayload;
          this.sid = this.sid ?? ex.sid;
          this.recordingState = ex.state;

          if (ex.state == 'recording') {
            this.isBeingRecorded = true;
            this.showLoader = false;
          }
          else if (ex.state == 'paused') {
            this.isBeingRecorded = false;
          } else {
            this.isBeingRecorded = false;
          }
         
          this._changeDetectorRef.markForCheck();
        }
      }
      if (res.command == CommandType.recordingTimerChange && this.roomData.roomId === res.data.roomId) {
        if (res.data.extra) {
          let info = res.data.extra as RecordingInfoPayload;
          this.timeElapsedCounter = info.timestamp;
          this.sid = info.sid;
          this.uid = info.uid;
          this.recordingState = info.state;
          this.isBeingRecorded = info.state == 'recording';
          this.showLoader = false;
          this._changeDetectorRef.detectChanges();
        }
      }
    });
  }

  ngAfterViewInit(): void {

  }

  async ngOnDestroy(): Promise<void> {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  @HostListener('window:beforeunload', ['$event'])
  confirmCloseIfRecording($event: any) {
    if (this.isRecordingActive()) {
      $event.preventDefault();
      $event.returnValue = 'Your recording will be lost!'; return 'Are you sure?';
    }
  }

  async startRecording(): Promise<void> {
    if (!this.user.isHostOrCoHost()) {
      return;
    }
    this.showLoader = true;
    this.waitingForFilenameInputPopup = true;
    this._changeDetectorRef.detectChanges();
    this._recordingService.startRecording(this.roomData.roomId, window.location.href, true)
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe({
        next: async (res) => {

          if (!res) {
            this._messageService.showErrorMessage('Unknown error, Please try again');
            this.waitingForFilenameInputPopup = false;
            this.showLoader = false;
            return;
          }

          // if (res.status == AgoraRecordingStatus.started) {
          //   this._messageService.showErrorMessage(res.reason);
          //   this.waitingForFilenameInputPopup = false;
          //   this.showLoader = false;
          //   return;
          // }

          if (!res.sid) {
            this.showLoader = false;
            this.recordingState = 'inactive';
            this._changeDetectorRef.detectChanges();
            this._messageService.showErrorMessage(res.reason);
            return;
          }

          const dialogRef = this._matDialog.open(ConfirmRecordingComponent);
          this.sid = res.sid;
          this.uid = res.uid;
          this.recordingState = 'paused';
          this.waitingForFilenameInputPopup = false;
          this._changeDetectorRef.detectChanges();
          dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(async result => {
            if (!result?.status) {
              this.showLoader = false;
              this.sid = undefined;
              this.recordingState = 'inactive';
              this._changeDetectorRef.detectChanges();
              return;
            }
            this.fileTitle = result.fileName;
            await this.playPauseRecording();
          });
        },
        error: (err) => {
          this.waitingForFilenameInputPopup = false;
          this.sid = undefined;
          this.showLoader = false;
          this.recordingState = 'inactive';
          this._changeDetectorRef.detectChanges();
          console.log(err);
          this._messageService.showErrorMessage('Sorry Recording could not be started, Please try again');
        }
      })
  }


  async playPauseRecording(): Promise<void> {
    this.showInnerLoader = true;
    const paused = this.recordingState === 'paused';
    let onHold = !paused;
    this._recordingService.updateRecording(this.roomData.roomId, this.sid, window.location.href, onHold, this.fileTitle)
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe({
        next: async (res) => {
          
          if (paused) {
            this.recordingState = 'recording';
            await this.emitRecordingStateChange();
          } else {
            this.recordingState = 'paused';
            await this.emitRecordingStateChange();
          }

          //Try at least two time until bot user loaded the screen for recording
          setTimeout(async () => {
            if (this.timeElapsedCounter == 0) {
              await this.emitRecordingStateChange();
              setTimeout(async () => {
                if (this.timeElapsedCounter == 0) {
                  await this.emitRecordingStateChange();
                }
              }, 4000)
            }
          }, 2000);

          this.showInnerLoader = false;
          this._changeDetectorRef.detectChanges();
        },
        error: (err) => {
          this.showInnerLoader = false;
          this.recordingState = 'inactive';
          this._changeDetectorRef.detectChanges();
          this._messageService.showErrorMessage(err.messages[0]);
          console.log(err);
        }
      })
  }


  async stopRecording(): Promise<void> {
    if (this.recordingState == 'paused' || this.recordingState == 'recording') {
      this.showInnerLoader = true;
      this._recordingService.stopRecording(this.roomData.roomId, this.sid)
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe({
          next: async () => {
            this.showInnerLoader = false;
            this.recordingState = 'inactive';
            await this.emitRecordingStateChange();
          },
          error: async (err) => {
            this.showInnerLoader = false;
            this.recordingState = 'inactive';
            await this.emitRecordingStateChange();
            this._messageService.showErrorMessage(err.messages[0]);
            this._changeDetectorRef.detectChanges();
          }
        })
    }
  }


  getElapsedTime(totalSeconds: number): string {
    if (totalSeconds <= 0) {
      return '00:00';
    }
    const hours = Math.floor(totalSeconds / 3600);
    totalSeconds = totalSeconds % 3600;
    const minutes = Math.floor(totalSeconds / 60);
    totalSeconds = totalSeconds % 60;
    const seconds = Math.floor(totalSeconds);
    let currentTimeString = this.timeDisplayString(minutes) + ':' + this.timeDisplayString(seconds);
    if (hours > 0) {
      currentTimeString = this.timeDisplayString(hours) + ':' + currentTimeString;
    }
    return currentTimeString;
  }

  isRecordingActive(): boolean {
    if (this.recordingState === 'recording' || this.recordingState === 'paused') {
      return true;
    }
    return false;
  }

  private timeDisplayString(num: number): string {
    return (num < 10 ? '0' : '') + num;
  }

  private async emitRecordingStateChange(): Promise<void> {
    if (this.user.isHostOrCoHost()) {
      let payload = {
        state: this.recordingState ?? 'inactive',
        sid: this.sid,
        uid: this.uid
      } as RecordingInfoPayload;

      const data = {
        receiverIds: [],
        receiverId: this.roomData.roomId,
        command: CommandType.recordingStateChange,
        signalLevel: SignalLevel.room,
        receiverType: this.roomData.roomType,
        data: {
          roomId: this.roomData.roomId,
          extra: payload
        } as SignalDataContent,
      } as SignalDataModel;
      await this._signalrService.sendSignal(data);

      this.recordingStageChange.emit(payload);
    }
  }
}
