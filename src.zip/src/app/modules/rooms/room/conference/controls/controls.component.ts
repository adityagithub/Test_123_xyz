import { ChangeDetectionStrategy, ChangeDetectorRef, Component, EventEmitter, OnDestroy, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Subject, takeUntil } from 'rxjs';
import { ConfirmDialogComponent } from 'src/app/core/components/confirm-dialog/confirm-dialog.component';
import { ConfirmDialogComponentData } from 'src/app/core/components/confirm-dialog/confirm.dialog.models';
import { UserModel } from 'src/app/shared/models/user.model';
import { UserService } from 'src/app/shared/services/user.service';
import { RegistryService } from 'src/app/shared/services/registry.service';
import { RoomModel } from '../../room.models';
import { RoomService } from '../../room.service';
import { ConferenceComponent } from '../conference.component';
import { ConferenceService } from '../conference.service';
import { InvitePeopleComponent } from '../../invite-people/invite-people.component';
import { RaisedHandsComponent } from '../../raise-hands/raise-hands.component';
import { FwRecordingComponent } from '../recording/recording.component';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { MaterialModule } from 'src/app/core/material.module';

@Component({
  selector: 'conference-controls',
  templateUrl: './controls.component.html',
  styleUrls: ['./controls.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [
    FwCoreModule,
    MaterialModule,
    FwRecordingComponent,
    RaisedHandsComponent,
    InvitePeopleComponent,
  ]
})
export class ConferenceControlsComponent implements OnInit, OnDestroy {
  roomJoined: boolean = false;
  currentUser: UserModel;
  roomData: RoomModel;
  allowAttendeeToUnmute: boolean;
  isPrivateOrBreakoutRoom: boolean;
  tooltipPosition: 'below customized' | 'above customized' | 'left customized' | 'right customized' = 'below customized';

  @Output() onRoomJoined: EventEmitter<any> = new EventEmitter();
    
  private _unsubscribeAll: Subject<any> = new Subject<any>();

  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _registryService: RegistryService,
    private _matDialog: MatDialog,
    private _userService: UserService,
    private _roomService: RoomService,
    private _conferenceService: ConferenceService) {
  }

  ngOnInit(): void {
    this.tooltipPosition = 'below customized';

    this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe(user => {
      this.currentUser = user;
      this._changeDetectorRef.detectChanges();
    });

    this._roomService.roomDetails$.pipe(takeUntil(this._unsubscribeAll)).subscribe(roomData => {
      this.roomData = roomData;
      if (this.roomData) {
        this.isPrivateOrBreakoutRoom = this.roomData.roomType === 'private' || this.roomData.roomType === 'breakout';
      }
      this._changeDetectorRef.markForCheck();
    });

    this._conferenceService.onRoomJoined$.pipe(takeUntil(this._unsubscribeAll)).subscribe(data => {
      if (data) {
        this.roomJoined = true;
        this.onRoomJoined.next(true);
        this._changeDetectorRef.markForCheck();
      }
    });

    this._conferenceService.onRoomLeft$.pipe(takeUntil(this._unsubscribeAll)).subscribe(data => {
      if (data) {
        this.roomJoined = false;
        this.onRoomJoined.next(false);
        this._changeDetectorRef.markForCheck();
      }
    });

    this._conferenceService.allowAttendeeToUnmute$.pipe(takeUntil(this._unsubscribeAll)).subscribe(allow => {
      this.allowAttendeeToUnmute = allow;
      this._changeDetectorRef.markForCheck();
    });
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  async muteVideo(): Promise<void> {
    this.currentUser.hasVideo = false;
    const conference = this.getConfereceComponentRef();
    await conference.muteVideo();
    this._changeDetectorRef.markForCheck();
  }

  async unmuteVideo(): Promise<void> {
    this.currentUser.hasVideo = true;
    const conference = this.getConfereceComponentRef();
    await conference.unmuteVideo();
    this._changeDetectorRef.markForCheck();
  }

  async muteMic(): Promise<void> {
    this.currentUser.hasAudio = false;
    const conference = this.getConfereceComponentRef();
    await conference.muteAudio();
    this._changeDetectorRef.markForCheck();
  }

  async unmuteMic(): Promise<void> {
    this.currentUser.hasAudio = true;
    const conference = this.getConfereceComponentRef();
    await conference.unmuteAudio();
    this._changeDetectorRef.markForCheck();
  }

  async startScreenShare(): Promise<void> {
    const conference = this.getConfereceComponentRef();
    await conference.startScreenShare();
    this._changeDetectorRef.markForCheck();
  }

  async stopScreenShare(): Promise<void> {
    const conference = this.getConfereceComponentRef();
    await conference.stopScreenShare();
    this._changeDetectorRef.markForCheck();
  }

  async startWhiteboard(): Promise<void> {
    const conference = this.getConfereceComponentRef();
    await conference.startWhiteboard();
    this._changeDetectorRef.markForCheck();
  }

  async stopWhiteboard(): Promise<void> {
    const conference = this.getConfereceComponentRef();
    await conference.stopWhiteboard();
    this._changeDetectorRef.markForCheck();
  }

  leaveRoom(): void {
    const dialogRef = this._matDialog.open(ConfirmDialogComponent, {
      data: {
        Title: 'Please confirm',
        Message: 'Do you want to leave this room?',
        CancelText: 'No, stay',
        OkText: 'Yes, leave'
      } as ConfirmDialogComponentData
    })
    dialogRef.afterClosed().subscribe(async (result: boolean) => {
      if (result) {
        const conference = this.getConfereceComponentRef();
        await conference.leaveRoom();
      }
    })
  }

  async raiseHand(): Promise<void> {
    const conference = this.getConfereceComponentRef();
    await conference.raiseHand();
    this._changeDetectorRef.markForCheck();
  }

  async lowerHand(): Promise<void> {
    const conference = this.getConfereceComponentRef();
    await conference.lowerHand();
    this._changeDetectorRef.markForCheck();
  }

  getConfereceComponentRef(): ConferenceComponent {
    return this._registryService.getComponent('conference') as ConferenceComponent;
  }

  onRecordingStateChange($event: any): void {
    this._conferenceService.notifyRecordingState($event)
  }
}
