import { NgModule } from '@angular/core';
import { NgxResize } from 'ngx-resize';
import { NgxSpinnerModule } from 'ngx-spinner';
import { MaterialModule } from 'src/app/core/material.module';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { ConferenceComponent } from 'src/app/modules/rooms/room/conference/conference.component';
import { RoomStandbyComponent } from './standby/standby.component';
import { VideoBoxComponent } from './videobox/videobox.component';
import { HttpClientModule } from '@angular/common/http';
import { ConfirmRecordingComponent } from './recording/confirm-recording/confirm-recording.component';
import { ReactionComponent } from './reactions/reaction.component';

@NgModule({
  declarations: [
    ConferenceComponent,
    VideoBoxComponent,
    RoomStandbyComponent,
    ConfirmRecordingComponent,
    ReactionComponent
  ],
  imports: [
    MaterialModule,
    FwCoreModule,
    NgxSpinnerModule,
    NgxResize,
    HttpClientModule
  ],
  exports: [
    ConferenceComponent
  ],
  providers: [
  ]
})
export class ConferenceModule {
}
