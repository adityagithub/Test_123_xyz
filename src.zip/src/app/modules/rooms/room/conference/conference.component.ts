import {
  AfterViewInit, ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef,
  Input, OnChanges, OnDestroy, OnInit, SimpleChanges, ViewChild, ViewEncapsulation
} from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import VirtualBackgroundExtension, { IVirtualBackgroundProcessor } from 'agora-extension-virtual-background';
import AgoraRTC, { ClientRole, IAgoraRTCClient, IAgoraRTCRemoteUser } from 'agora-rtc-sdk-ng';
import { NgxResizeResult } from 'ngx-resize';
import { NgxSpinnerService } from 'ngx-spinner';
import { BehaviorSubject, interval, Observable, Subject } from 'rxjs';
import { mergeMap, takeUntil } from 'rxjs/operators';
import { ConfirmDialogComponent } from 'src/app/core/components/confirm-dialog/confirm-dialog.component';
import { FwConfigService } from 'src/app/core/services/config.service';
import { EnumRightPanelMenu } from 'src/app/layout/components/right-panel/right-panel.models';
import { RightPanelService } from 'src/app/layout/components/right-panel/right-panel.service';
import { ConferenceService } from 'src/app/modules/rooms/room/conference/conference.service';
import { RoomModel } from 'src/app/modules/rooms/room/room.models';
import { UserModel, UserRoleModel } from 'src/app/shared/models/user.model';
import { UserService } from 'src/app/shared/services/user.service';
import { EventModel } from 'src/app/shared/models/event.model';
import { CommandType, SignalDataContent, SignalDataModel, SignalLevel } from 'src/app/shared/models/signalr.models';
import { EventService } from 'src/app/shared/services/event.service';
import { MessageService } from 'src/app/shared/services/message.service';
import { RegistryService } from 'src/app/shared/services/registry.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { LocalTracks, MediaSettingsData } from '../media-settings/media-settings.models';
import { RoomService } from '../room.service';
import { LayoutConfig } from 'src/app/core/layoutConfig';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import { RecordingInfoPayload } from './conference.model';
import { RecordingService } from './recording/recording.service';

@Component({
  selector: 'conference',
  templateUrl: './conference.component.html',
  styleUrls: ['./conference.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ConferenceComponent implements OnInit, AfterViewInit, OnChanges, OnDestroy {
  layoutConfig: LayoutConfig;
  @Input() eventData: EventModel;
  @Input() roomData: RoomModel;
  @Input() mediaSettingData: MediaSettingsData;
  isStandby: boolean = false;
  currentLayout: 'gd' | 'vb' | 'vt' | 'hl' | 'hr' = 'vt';
  expandNotificationInfo: boolean = true;
  currentUser: UserModel;
  eventMembers: UserModel[];
  pinnedMember: UserModel;
  roomMembers: UserModel[];
  localTracks: LocalTracks = { audioTrack: null, videoTrack: null, screenTrack: null, whiteboard: null };

  private _virtualBackgroundeExtension: VirtualBackgroundExtension = new VirtualBackgroundExtension();
  private _unsubscribeAll: Subject<any> = new Subject<any>();
  @ViewChild('members_container', { static: false }) private _membersContainer: ElementRef<HTMLDivElement>;

  rtcClient: IAgoraRTCClient;
  screenClient: IAgoraRTCClient;
  whiteboardClient: any; // Room;
  localScreenClientConnected: boolean;
  remoteScreenClientConnected: boolean;

  localWhiteboardConnected: boolean;
  remoteWhiteboardConnected: boolean;

  audioPublished: boolean;
  videoPublished: boolean;

  clientRole: ClientRole = 'audience';
  processor: IVirtualBackgroundProcessor;
  virtualBackgroundUrl: string;
  presenterJoined: BehaviorSubject<boolean> = new BehaviorSubject(false);
  isPrivateOrBreakoutRoom: boolean;
  isBeingRecorded: boolean;
  recording_elapsed_timerValueForSystemUser: number = 0;
  recording_timerIntervalId: any;
  recording_state: RecordingState;
  recoridng_resourceId: string;
  recording_sid: string;
  recording_uid: string;

  constructor(
    private _appConfig: AppSettingService,
    private _router: Router,
    private _route: ActivatedRoute,
    private _fwConfigService: FwConfigService,
    private _changeDetectorRef: ChangeDetectorRef,
    private _userService: UserService,
    private _eventService: EventService,
    private _registryService: RegistryService,
    private _conferenceService: ConferenceService,
    private _messageService: MessageService,
    private _signalrService: SignalrService,
    private _spinner: NgxSpinnerService,
    private _rightPanelService: RightPanelService,
    private _sharedService: SharedService,
    private _roomService: RoomService,
    private _matDialog: MatDialog,
    private _recordingService: RecordingService
  ) {
    AgoraRTC.setLogLevel(4);
    this._registryService.register('conference', this);
  }

  async ngOnInit(): Promise<void> {
    this._spinner.show();

    this.isPrivateOrBreakoutRoom = this.roomData.roomType === 'private' || this.roomData.roomType === 'breakout';
    this._changeDetectorRef.markForCheck();

    this._fwConfigService.config.pipe(takeUntil(this._unsubscribeAll)).subscribe((config: LayoutConfig) => {
      this.layoutConfig = config;
    });

    this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe(user => {
      this.currentUser = user;
      this._changeDetectorRef.markForCheck();
    });

    this._eventService.attendees$.pipe(takeUntil(this._unsubscribeAll)).subscribe(async att => {
      this.eventMembers = att;
      await this._updateRoomMembersRole();
      this._changeDetectorRef.markForCheck();
    });

    this._conferenceService.members$.pipe(takeUntil(this._unsubscribeAll)).subscribe(async members => {
      this.roomMembers = members;
      if (members) {
        this.pinnedMember = this.roomMembers.find(rm => rm.pinned);
        this._changeDetectorRef.detectChanges();
        await this._updateLayout();
        await this.checkIfPresenterJoinined();

        let currentMember = this.roomMembers.find(m => m.userId == this.currentUser.userId);
        if (currentMember) {
          if (currentMember.hideFromScreen) {
            await this.muteVideo(false);
            await this.stopScreenShare(false);
          }
        }
      }
    });

    this._registerSignalrEvents();

  }

  async ngOnChanges(changes: SimpleChanges): Promise<void> {
    if ('roomData' in changes || 'eventData' in changes) {
      this.virtualBackgroundUrl = await this._getBackgroundImagePath();
    }
    this._changeDetectorRef.markForCheck();
  }

  async ngAfterViewInit(): Promise<void> {
    try {
      this._registerRecordingEvents();
      AgoraRTC.registerExtensions([this._virtualBackgroundeExtension]);
      if (this.currentUser.isHostOrCoHost() || this.currentUser.isPresenter() || this.isPrivateOrBreakoutRoom) {
        this.clientRole = 'host';
      }
      this.rtcClient = AgoraRTC.createClient({ mode: 'live', codec: 'vp8', role: this.clientRole });
      await this.rtcClient.setClientRole(this.clientRole);
      //try { this.rtcClient.enableAudioVolumeIndicator(); } catch { }
      await this._registerVideoClientHanders();
      await this.joinRoom();
      this._spinner.hide();
    } catch (e) {
      console.error(e);
      this._spinner.hide();
    }
  }

  async ngOnDestroy(): Promise<void> {
    this._registryService.unregister('conference');
    try { await this.leaveRoom() } catch { }
    await this._stopPlayingLocalMedia(this.localTracks);
    setTimeout(async () => {
      await this._stopPlayingLocalMedia(this.localTracks);
    }, 1500);
    try {
      this.recording_state = 'inactive';
      this.stopTimer();
    } catch {

    }
    this._conferenceService.removeConfereceMembers();
    this.rtcClient.removeAllListeners();
    this.localTracks?.audioTrack?.removeAllListeners();
    this.localTracks?.videoTrack?.removeAllListeners();
    this.localTracks?.screenTrack?.removeAllListeners();
    const currentUser = this._userService.getCurrentUser();
    currentUser.hasAudio = false;
    currentUser.hasVideo = false;
    currentUser.raisedHand = false;
    currentUser.pinned = false;
    this._userService.setCurrentUser(currentUser);
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  async changeLayout(layout: 'gd' | 'vb' | 'vt' | 'hl' | 'hr'): Promise<void> {
    this.currentLayout = layout;
    if (layout === 'gd') {
      this.roomMembers.forEach(p => { p.pinned = false });
      this.pinnedMember = null;
      this._changeDetectorRef.markForCheck();
    }
  }

  async muteAudio(): Promise<boolean> {
    if (!this.localTracks.audioTrack) return false;
    await this.localTracks.audioTrack.setEnabled(false);
    const currentUser = this._userService.getCurrentUser();
    currentUser.hasAudio = false;
    this._conferenceService.updateConfereceMember(currentUser);
    this.mediaSettingData.setAdudioMuted(true);
    this._userService.setCurrentUser(currentUser);
    return true;
  }

  async unmuteAudio(): Promise<boolean> {
    if (!this.localTracks.audioTrack) {
      this.localTracks.audioTrack = await AgoraRTC.createMicrophoneAudioTrack();
    };

    this.localTracks.audioTrack.setEnabled(true).then(async () => {
      if (!this.audioPublished) {
        await this.rtcClient.publish(this.localTracks.audioTrack);
        this.audioPublished = true;
      }
      const currentUser = this._userService.getCurrentUser();
      currentUser.hasAudio = true;
      currentUser.localAudioTrack = this.localTracks.audioTrack;
      this._conferenceService.updateConfereceMember(currentUser);
      this.mediaSettingData.setAdudioMuted(false);
      this._userService.setCurrentUser(currentUser);
    }).catch(_ex => {
      this.localTracks.audioTrack = null;
      this._messageService.showErrorMessage('It appears your mic is being used by another application or not accessible, please provide permissions under settings.');
    })
    return true;
  }

  async muteVideo(updateConfereceMember: boolean = true): Promise<boolean> {
    if (!this.localTracks.videoTrack) return false;
    await this.localTracks.videoTrack.setEnabled(false);
    this.videoPublished = false;
    const currentUser = this._userService.getCurrentUser();
    currentUser.hasVideo = false;
    if (updateConfereceMember) {
      this._conferenceService.updateConfereceMember(currentUser);
    }
    this.mediaSettingData.setVideoMuted(true);
    this._userService.setCurrentUser(currentUser);
    this.processor?.disable();
    return true;
  }

  async unmuteVideo(): Promise<boolean> {
    if (!this.localTracks.videoTrack) {
      this.localTracks.videoTrack = await AgoraRTC.createCameraVideoTrack({ optimizationMode: 'detail' });
    };
    await this.localTracks.videoTrack.setEnabled(true).then(async () => {
      if (!this.videoPublished) {
        await this.rtcClient.publish(this.localTracks.videoTrack);
        this.videoPublished = true;
      }
      const currentUser = this._userService.getCurrentUser();
      currentUser.hasVideo = true;
      currentUser.localVideoTrack = this.localTracks.videoTrack;
      this._conferenceService.updateConfereceMember(currentUser);
      this.mediaSettingData.setVideoMuted(false);
      this._userService.setCurrentUser(currentUser);
      this.checkAndSetVirtualBackground();
    }).catch(ex => {
      this._messageService.showErrorMessage('It appears your camera is being used by another application or not accessible, please provide permissions under settings.');
      console.error(ex);
    });
    return true;
  }

  async startScreenShare(): Promise<boolean> {
    try {
      if (this.localScreenClientConnected) {
        return;
      }
      const roomMember = this.roomMembers.find(x => x.userId === this.currentUser.userId);
      if (!roomMember) { return; }
      this.localTracks.screenTrack = await AgoraRTC.createScreenVideoTrack({ encoderConfig: '720p', screenSourceType: 'screen' }, 'disable');
      this.screenClient = AgoraRTC.createClient({ mode: 'live', codec: 'vp8', role: 'host' });
      const screenPresenterId = this.currentUser.userId + this._conferenceService.getScreePresenterAppendId();
      await this.screenClient.join(this._appConfig.settings.appId, this.roomData.streamId, null, screenPresenterId);
      this.localScreenClientConnected = true;
      this.localTracks.screenTrack.on('track-ended', async () => {
        await this.stopScreenShare();
      });
      await this.screenClient.publish(this.localTracks.screenTrack);
      return true;
    } catch (e) {
      console.log('startScreenShare', e);
    }
  }

  async stopScreenShare(updateConfereceMember: boolean = true): Promise<boolean> {
    try {
      if (this.localTracks.screenTrack) {
        await this.screenClient.unpublish(this.localTracks.screenTrack);
        await this.screenClient.leave();
        this.localTracks.screenTrack?.stop();
        this.localTracks.screenTrack?.close();
        this.localTracks.screenTrack = undefined;
      }
      this.localScreenClientConnected = false;
      const screnPresenterId = this.currentUser.userId + this._conferenceService.getScreePresenterAppendId();
      const currentUser = this._userService.getCurrentUser();
      currentUser.hasScreen = false;
      if (updateConfereceMember) {
        this._conferenceService.removeConfereceMember(screnPresenterId);
        this._conferenceService.updateConfereceMember(currentUser);
      }
      this._userService.setCurrentUser(this.currentUser);
      return true;
    } catch (e) {
      console.log('stopScreenShare', e);
    }
  }

  async checkAndSetVirtualBackground() {
    const mediaSettings = this._conferenceService.getMediaSetting();
    if (mediaSettings && mediaSettings.virtualBackground && mediaSettings.virtualBackground.isEnabled) {
      if (mediaSettings.virtualBackground.type === 'img' && mediaSettings.virtualBackground.backgoundImage) {
        this._setBackgroundImage(mediaSettings.virtualBackground.backgoundImage.src);
      }

      if (this.mediaSettingData.virtualBackground.type === 'blur') {
        // TODO
      }

      if (this.mediaSettingData.virtualBackground.type === 'color') {
        // TODO
      }
    }
  }

  async onMemberContainerResized(event?: NgxResizeResult): Promise<void> {
    if (this._membersContainer?.nativeElement) {
      this._conferenceService.resizeLayout(this._membersContainer.nativeElement);
    }
  }

  async onPinStateChange(participant: UserModel) {
    this.roomMembers.forEach(p => { if (p.userId !== participant.userId) { p.pinned = false } });
    this.pinnedMember = participant.pinned ? participant : null;
    this._changeDetectorRef.detectChanges();
    // Need to call resized event manually because
    // Sometime It's' not adjusting view automatically (eg: in case of two presenters)
    this.onMemberContainerResized();
  }

  async joinRoom(): Promise<void> {
    try {
      const currentUser = this._userService.getCurrentUser();
      const member = this.eventMembers.find(a => a.userId === this.currentUser.userId);
      if (!member && !this.currentUser.isSystemUser()) { return; }
      const uid = await this.rtcClient.join(this._appConfig.settings.appId, this.roomData.streamId, null, this.currentUser.userId);
      if (this.currentUser.isSystemUser()) {
        this.currentUser.uid = uid;
        return;
      }
      member.uid = uid;
      if (this.currentUser.isAttendee()) {
        if (!this.isPrivateOrBreakoutRoom) {
          const signalDataModel = {
            receiverId: this.roomData.roomId,
            receiverType: this.roomData.roomType,
            command: CommandType.attendeeJoined,
            signalLevel: SignalLevel.room,
            data: { userId: this.currentUser.userId, roomId: this.roomData.roomId }
          } as SignalDataModel;
          await this._signalrService.sendSignal(signalDataModel);
        }
      }
      else {

        if (!this.currentUser.hideFromScreen) {

          if (!this.mediaSettingData.audioTrackMuted) {
            await this.unmuteAudio();
          }

          if (!this.mediaSettingData.videoTrackMuted) {
            await this.unmuteVideo();// Virtual background will also set in this method
          }
        }

        this._conferenceService.addConfereceMember(member);
        this._conferenceService.updateConfereceMember(currentUser);
      }

      this._rightPanelService.setActiveMenu(EnumRightPanelMenu.attendees);
      this._conferenceService.notifyRoomJoined();
      this._changeDetectorRef.markForCheck();
      this._registerMediaSettingsUpdateEvents();

      const atts = await this._signalrService.getRoomAttendees(this.roomData.roomId);
      if (atts) {
        atts.forEach(u => {
          const att = this.eventMembers.find(a => a.userId === u.userId);
          if (att) {
            this._conferenceService.addConfereceMember(att);
          }
        });
        this._changeDetectorRef.markForCheck();
      }
    } catch (e) {
    }
  }

  async leaveRoom(): Promise<void> {
    await this.rtcClient.leave();
    await this.stopScreenShare();
    await this.lowerHand();
    this._conferenceService.removeConfereceMembers();
    this._conferenceService.notifyRoomLeft();
    this.isBeingRecorded = false;
    if (this.currentUser.isAttendee() && !this.isPrivateOrBreakoutRoom) {
      const signalDataModel = {
        receiverId: this.roomData.roomId,
        receiverType: this.roomData.roomType,
        command: CommandType.attendeeLeft,
        signalLevel: SignalLevel.room,
        data: { userId: this.currentUser.userId, roomId: this.roomData.roomId }
      } as SignalDataModel;
      await this._signalrService.sendSignal(signalDataModel);
    }
  }

  async setRemoteUserMuted(mute: boolean, attendee: UserModel): Promise<void> {
    if (this.currentUser.userId === attendee.userId) {
      return;
    }
    this._signalrService.sendMuteUnmuteSignal(mute, attendee)
      .then(res => {

      })
      .catch(rejected => {
        console.log(rejected);
        this._messageService.showErrorMessage(rejected);
      });
  }

  async kickoutAttendee(attendee: UserModel): Promise<void> {
    if (this.currentUser.userId === attendee.userId) {
      return;
    }
    const dialogRef = this._matDialog.open(ConfirmDialogComponent, {
      data: {
        Title: 'Please confirm',
        Message: 'Are you sure you want to remove <b>' + attendee.getFullName() + '</b>?',
        CancelText: 'No',
        OkText: 'Yes'
      }
    });
    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(async result => {
      if (result) {
        const res = await this._signalrService.sendKickoutSignal(attendee);
        if (res) {
          // TODO
        }
      }
    });
  }

  async raiseHand(): Promise<boolean> {
    const currentUser = this._userService.getCurrentUser();
    const signalDataModel = {
      receiverId: this.eventData.eventId,
      command: CommandType.raiseHand,
      signalLevel: SignalLevel.event,
      data: { userId: currentUser.userId, roomId: this.roomData.roomId }
    } as SignalDataModel;
    await this._signalrService.sendSignal(signalDataModel);
    currentUser.raisedHand = true;
    this._conferenceService.updateConfereceMember(currentUser);
    this._changeDetectorRef.detectChanges();
    return true;
  }

  async lowerHand(): Promise<boolean> {
    const currentUser = this._userService.getCurrentUser();
    const signalDataModel = {
      receiverId: this.eventData.eventId,
      command: CommandType.lowerHand,
      signalLevel: SignalLevel.event,
      data: { userId: currentUser.userId, roomId: this.roomData.roomId }
    } as SignalDataModel;
    await this._signalrService.sendSignal(signalDataModel);
    currentUser.raisedHand = false;
    this._conferenceService.updateConfereceMember(currentUser);
    this._changeDetectorRef.detectChanges();
    return true;
  }

  async checkIfPresenterJoinined(): Promise<void> {
    const joined = this.roomMembers.some(r => r.isHostOrCoHost() || r.isPresenter());
    this.presenterJoined.next(joined);
  }

  async startWhiteboard(): Promise<boolean> {

    try {
      if (this.localWhiteboardConnected) {
        return;
      }
      const roomMember = this.roomMembers.find(x => x.userId === this.currentUser.userId);
      if (!roomMember) { return; }
      const whiteboardPresenterId = this.currentUser.userId + this._conferenceService.getWhiteboardPresenterAppendId();

      const roomRes = await this._conferenceService.createRoomForWhiteboard('');
      if (roomRes) {
        const roomToken = await this._conferenceService.generateRoomTokenForWhiteboard(roomRes.uuid);

        // if (roomToken) {

        //   this.localTracks.whiteboard = new WhiteWebSdk({
        //     appIdentifier: this._appConfig.settings.whiteboard.appId,
        //     region: "in-mum",
        //     screenType: ScreenType.Desktop,
        //   });

        //   var joinRoomParams = {
        //     uuid: roomRes.uuid,
        //     // The unique identifier of a user. If you use versions earlier than v2.15.0, do not add this line.
        //     uid: roomMember.userId.toString() as UID,
        //     roomToken: roomToken,
        //   } as JoinRoomParams;

        //   // Join the whiteboard room and display the whiteboard on the web page.
        //   let room = await this.localTracks.whiteboard.joinRoom(joinRoomParams);
        //   room.bindHtmlElement(document.getElementById("whiteboard") as HTMLDivElement);
        //   this.localWhiteboardConnected = true;
        //   setTimeout(() => {
        //     room?.disconnect();
        //     this.localWhiteboardConnected = false;
        //     alert('disconnected');
        //   }, 10000);

        //   var toolbar = document.getElementById("whiteboard-toolbar");
        //   var toolNames = ["clicker", "selector", "rectangle", "eraser", "text", "arrow", "ellipse", "hand", "laserPointer", "shape", "straight"];

        //   for (var idx in toolNames) {
        //     var toolName = toolNames[idx];
        //     var btn = document.createElement("BUTTON");
        //     btn.setAttribute("id", "btn" + toolName);
        //     var t = document.createTextNode(toolName);
        //     btn.appendChild(t);

        //     // Listen for the event of clicking a button.
        //     btn.addEventListener("click", function (obj) {
        //       var ele = obj.target;
        //       // Call the setMemberState method to set the whiteboard tool.
        //       room.setMemberState(
        //         {
        //           //@ts-ignore
        //           currentApplianceName: ele.getAttribute("id").substring(3),
        //           shapeType: ShapeType.Pentagram,
        //           strokeColor: [255, 182, 200],
        //           strokeWidth: 12,
        //           textSize: 40,
        //         });
        //     });
        //     toolbar.appendChild(btn);
        //     console.log(btn.getAttribute("id"));
        //   }
        // }
      }

      return true;
    } catch (e) {
      console.log('joinWhiteboard', e);
    }
  }

  async stopWhiteboard(): Promise<boolean> {
    if (!this.whiteboardClient)
      return false;

    this.whiteboardClient.disconnect();
    this.localWhiteboardConnected = false;
    return true;
  }

  private async _getBackgroundImagePath(): Promise<string> {
    let url = null;
    if (this.roomData?.settings?.backgroundImageEnabled && this.roomData?.backgroundImage) {
      url = this._appConfig.settings.resourceBaseUrl + this.roomData.backgroundImage.imagePath;
    } else if (this.eventData.settings.backgroundImageEnabled && this.eventData.backgroundImagePath) {
      url = this._appConfig.settings.resourceBaseUrl + this.eventData.backgroundImagePath;
    }
    return url;
  }

  private async _setClientRoleAttendee(): Promise<void> {
    if (this.clientRole === 'audience') {
      return;
    }
    this.clientRole = 'audience';
    await this.rtcClient.setClientRole(this.clientRole);
  }

  private async _setClientRoleHost(): Promise<void> {
    if (this.clientRole === 'host') {
      return;
    }
    this.clientRole = 'host';
    await this.rtcClient.setClientRole(this.clientRole);
  }

  private async _updateLayout(): Promise<void> {
    await this.onMemberContainerResized();
    this._changeDetectorRef.markForCheck();
  }

  private async _stopPlayingLocalMedia(media: LocalTracks): Promise<void> {
    if (media) {
      for (const trackName in this.localTracks) {
        const track = this.localTracks[trackName];
        if (track) {
          track.stop();
          track.close();
          this.localTracks[trackName] = undefined;
        }
      }
    }
  }

  private async _getProcessorInstance(extension: VirtualBackgroundExtension): Promise<IVirtualBackgroundProcessor> {
    if (!this.processor && this.localTracks.videoTrack) {
      this.processor = extension.createProcessor();
      await this.processor.init('./assets/agora/wasms');
      // Inject the extension into the video processing pipeline in the SDK
      this.localTracks.videoTrack.pipe(this.processor).pipe(this.localTracks.videoTrack.processorDestination);
    }
    return this.processor;
  }

  private async _setBackgroundImage(src: string) {
    const imgElement = document.createElement('img');
    imgElement.onload = async () => {
      if (!this.processor) {
        this.processor = await this._getProcessorInstance(this._virtualBackgroundeExtension);
      }
      this.processor?.setOptions({ type: 'img', source: imgElement });
      await this.processor?.enable();
    }
    imgElement.src = src;
  }

  private async _updateRoomMembersRole(): Promise<void> {
    if (this.roomMembers) {
      this.roomMembers.forEach(r => {
        const m = this.eventMembers.find(e => e.userId === r.userId);
        if (m) { r.userRoles = m.userRoles; }
      });
      this._conferenceService.updateConfereceMembers(this.roomMembers);
      this._changeDetectorRef.markForCheck();
    }
  }

  private async _registerVideoClientHanders(): Promise<void> {
    // Attendee joined logic is implemented in signalrService.onNewSignal handler
    this.rtcClient.on('user-joined', async (user: IAgoraRTCRemoteUser) => {
      const userId = user.uid.valueOf() as number;
      const presenter = this.eventMembers.find(x => x.userId === userId);
      if (presenter) {
        this._conferenceService.addConfereceMember(presenter);
        return;
      }

      const screenPresenterAppendId = this._conferenceService.getScreePresenterAppendId();
      const currentUserIds = [this.currentUser.userId, this.currentUser.userId + screenPresenterAppendId];
      const presenterId = userId - screenPresenterAppendId;
      const screenUser = this.eventMembers.find(x => x.userId === presenterId);
      if (screenUser) {
        this.roomMembers.forEach(x => { x.pinned = false });
        const screenPresenter = new UserModel(Object.assign({}, screenUser));
        screenPresenter.userId = userId;
        screenPresenter.hasScreen = true;
        screenPresenter.pinned = true;
        screenPresenter.videoTrack = undefined;
        screenPresenter.fullName = screenPresenter.getFullName() + ' is presenting';
        this._conferenceService.addConfereceMember(screenPresenter);
        if (currentUserIds.includes(userId)) {
          this.currentUser.hasScreen = true;
          this._userService.setCurrentUser(this.currentUser);
        } else {
          await this.stopScreenShare();
        }
      }
    });

    this.rtcClient.on('user-published', async (user: IAgoraRTCRemoteUser, mediaType: 'video' | 'audio') => {
      const userId = user.uid.valueOf() as number;
      const presenter = await this._conferenceService.getMember(userId);
      if (!presenter) { return; }

      const screenPresenterAppendId = this._conferenceService.getScreePresenterAppendId();
      const currentUserIds = [this.currentUser.userId, this.currentUser.userId + screenPresenterAppendId];
      if (currentUserIds.includes(userId)) {
        presenter.localScreenTrack = this.localTracks.screenTrack;
      } else {
        await this.rtcClient.subscribe(user, mediaType);
        presenter.hasAudio = user.hasAudio;
        presenter.hasVideo = user.hasVideo;
        presenter.audioTrack = user.audioTrack;
        presenter.videoTrack = user.videoTrack;

        if (presenter.audioTrack) {
          if (!presenter.audioTrack.isPlaying) {
            presenter.audioTrack.play();
          }
        }
      }
      this._conferenceService.updateConfereceMember(presenter);
    });

    this.rtcClient.on('user-info-updated', async (uid, msg) => {
      const userId = uid.valueOf() as number;
      if (userId !== this.currentUser.userId) {
        const roomMember = await this._conferenceService.getMember(userId);
        if (!roomMember) {
          // Its a screen client
          return;
        }
        switch (msg) {
          case 'mute-audio': {
            roomMember.hasAudio = false;
            roomMember.volumeLevel = 0;
            break;
          }
          case 'unmute-audio': {
            roomMember.hasAudio = true;
            break;
          }
          case 'mute-video': {
            roomMember.hasVideo = false;
            break;
          }
          case 'unmute-video': {
            roomMember.hasVideo = true;
            break;
          }
          case 'disable-local-video': {
            break;
          }
          case 'enable-local-video': {
            break;
          }
        }
        this._conferenceService.updateConfereceMember(roomMember);
      }
    });

    this.rtcClient.on('user-unpublished', async (user: IAgoraRTCRemoteUser, mediaType) => {
      await this.rtcClient.unsubscribe(user, mediaType);
      if (mediaType === 'audio') {
        const audioTrack = user.audioTrack;
        audioTrack?.stop();
      } else {
        const videoTrack = user.videoTrack;
        videoTrack?.stop();
      }

      const id = user.uid.valueOf() as number;
      const att = await this._conferenceService.getMember(id);
      if (att) {
        att.hasAudio = user.hasAudio;
        att.hasVideo = user.hasVideo;
        att.audioTrack = user.audioTrack;
        att.videoTrack = user.videoTrack;
        this._conferenceService.updateConfereceMember(att);
      }
    });

    this.rtcClient.on('user-left', async (user, mediaType) => {
      const userId = user.uid.valueOf() as number;
      const member = await this._conferenceService.getMember(userId);
      if (member && member.isAttendee() && !this.isPrivateOrBreakoutRoom) {
        /*
        1.When Attendee promoted (then he join as host and user-join event fired)
        2.When Attendee demoted (Then user-left event will be fired but we need to show it in the right section)
        */
        return;
      }
      this._conferenceService.removeConfereceMember(userId);

      const memberCount = await this._conferenceService.getMembersCount();
      if (memberCount == 0 && this.currentUser.isSystemUser()) {
        try {
          this._recordingService.stopRecording(this.roomData.roomId, this.recording_sid)
            .pipe(takeUntil(this._unsubscribeAll)).subscribe({
              next: async (res) => {
                try { await this.sendStopRecordingNotificationByBot(); } catch { }
                await this.leaveRoom();
              },
              error: async (err) => {
                try { await this.sendStopRecordingNotificationByBot(); } catch { }
                await this.leaveRoom();
              }
            });
        } catch (e) {
          await this.leaveRoom();
        }
      }
    });

    this.rtcClient.on('volume-indicator', (data: [{ level: number, uid: number }]) => {
      // data?.forEach(async d => {
      //   const member = await this._conferenceService.getMember(d.uid);
      //   if (member) {
      //     member.volumeLevel = Math.round(d.level);
      //   }
      // });
      // this._changeDetectorRef.detectChanges();
    });

    this.rtcClient.on('exception', async (ex) => {
    })
  }

  private async _registerSignalrEvents(): Promise<void> {
    this._signalrService.onNewSignal$.pipe(takeUntil(this._unsubscribeAll)).subscribe(async (res: SignalDataModel) => {
      if (!res) {
        return;
      }

      if (res.receiverId === this.currentUser.userId || res.receiverIds?.includes(this.currentUser.userId)) {
        if (res.command === CommandType.muteAttendee) {
          if (this.currentUser.isPresenter()) {
            await this._onMutePresenterByHost();
          } else if (this.currentUser.isAttendee()) {
            await this._onMuteAttendeeByHost();
          }
        } else if (res.command === CommandType.unmuteAttendee) {
          if (this.currentUser.isPresenter()) {
            await this._onUnmutePresenterByHost();
          } else if (this.currentUser.isAttendee()) {
            await this._onUnmuteAttendeeByHost();
          }
        } else if (res.command === CommandType.kickoutAttendee) {
          await this._onKickoutAttendeeByHost();
        } else if (res.command === CommandType.memberRoleChange) {
          await this._onMemberRoleChangeByHost(res.data.userRoles);
        } else if (res.command === CommandType.raiseHandApproved || res.command === CommandType.allRaisedHandApproved) {
          await this._onRaiseHandApprovedByHost();
        } else if (res.command === CommandType.raiseHandRejected || res.command === CommandType.allRaisedHandRejected) {
          await this._onRaiseHandRejectedByHost();
        }
      }

      if (res.command === CommandType.attendeeJoined) {
        await this._onAttendeeJoinRoom(res.data);
      } else if (res.command === CommandType.attendeeLeft) {
        await this._onAttendeeLeftRoom(res.data);
      } else if (res.command === CommandType.userStatusChanged) {
        if (res.data.userId === this.currentUser.userId) {
          const currentUser = this._userService.getCurrentUser();
          currentUser.status = res.data.status;
          this._conferenceService.updateConfereceMember(currentUser);
        }
      } else if (res.command === CommandType.raiseHand && this.roomData.roomId === res.data.roomId) {
        await this._onRaiseHandByAttendee(res.data.userId);
      } else if (res.command === CommandType.lowerHand && this.roomData.roomId === res.data.roomId) {
        await this._onLowerHandByAttendee(res.data.userId);
      } else if (res.command == CommandType.recordingStateChange && this.roomData.roomId === res.data.roomId) {
        if (res.data.extra) {
          let ex = res.data.extra as RecordingInfoPayload;
          this.recording_state = ex.state;
          this.recording_sid = ex.sid;
          this.recording_uid = ex.uid;
          this.isBeingRecorded = ex.state == 'recording';
          if (this.currentUser.isSystemUser()) {
            if (ex.state == 'recording') {
              this.startTimer();
            }
            if (ex.state == 'paused') {
              this.pauseTimer();
            }
            if (ex.state == 'inactive') {
              this.stopTimer();
            }
          }
          this._changeDetectorRef.markForCheck();
        }
      } else if (res.command === CommandType.hideFromScreen && res.receiverIds) {
        const hide = res.data.extra.hide;

        let confereceMembers = await this._conferenceService.getMembers();
        confereceMembers.forEach(m => {
          if (res.receiverIds.includes(m.userId)) {
            m.hideFromScreen = hide;
            this._conferenceService.updateConfereceMember(m);
          }
        });

        this._conferenceService.updateConfereceMember(this.currentUser);
        if (this.currentUser.hideFromScreen) {
          if (this.videoPublished) {
            this.muteVideo();
          }
          if (this.audioPublished) {
            this.muteAudio();
          }
        }
      }
    });
  }

  private async _registerMediaSettingsUpdateEvents(): Promise<void> {
    this._conferenceService.onMediaSettingsUpdated$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe(async setting => {
        if (setting) {
          if (setting.audioTrackMuted) {
            await this.muteAudio();
          } else {
            await this.unmuteAudio();
          }

          if (setting.videoTrackMuted) {
            await this.muteVideo();
          } else {
            await this.unmuteVideo();
          }

          if (setting.virtualBackground && setting.virtualBackground.isEnabled) {
            // TODO Virtual background logic is already covered in await this.unmuteVideo(); above code
          } else {
            await this.processor?.disable();
          }

          // Need to set updated mute/unmute audio video properties of current user
          this._userService.setCurrentUser(this.currentUser);
        }
      });
  }

  private async _onAttendeeJoinRoom(resData: SignalDataContent): Promise<void> {
    if (resData && resData.roomId === this.roomData.roomId) {
      const joinedAttendee = this.eventMembers.find(a => a.userId === resData.userId);
      if (joinedAttendee) {
        this._conferenceService.addConfereceMember(joinedAttendee);
      }
    }
  }

  private async _onAttendeeLeftRoom(resData: SignalDataContent): Promise<void> {
    if (resData && resData.roomId === this.roomData.roomId) {
      const leftAttendee = this.roomMembers.find(a => a.userId === resData.userId);
      if (leftAttendee) {
        this._conferenceService.removeConfereceMember(leftAttendee.userId);
      }
    }
  }

  private async _onUnmuteAttendeeByHost(): Promise<void> {
    await this._setClientRoleHost();
    await this.lowerHand();
    await this.unmuteAudio();
    this._conferenceService.allowAttendeeToUnmute(true);
  }

  private async _onMuteAttendeeByHost(): Promise<void> {
    this.audioPublished = false;
    this.videoPublished = false;
    await this.rtcClient.unpublish();
    await this.muteAudio();
    await this.lowerHand();
    this._conferenceService.allowAttendeeToUnmute(false);
    await this._setClientRoleAttendee();
  }

  private async _onUnmutePresenterByHost(): Promise<void> {
    await this.unmuteAudio();
  }

  private async _onMutePresenterByHost(): Promise<void> {
    this.audioPublished = false;
    await this.muteAudio();
  }

  private async _onRaiseHandApprovedByHost(): Promise<void> {
    await this._setClientRoleHost();
    await this.lowerHand();
    this._conferenceService.allowAttendeeToUnmute(true);
  }

  private async _onRaiseHandRejectedByHost(): Promise<void> {
    await this.lowerHand();
    this._conferenceService.allowAttendeeToUnmute(false);
  }

  private async _onKickoutAttendeeByHost(): Promise<void> {
    let isBreakout = this.roomData.roomType === 'breakout';
    if(isBreakout) {
      await this._roomService.forceLeaveBreakoutRoom(this.roomData.roomId);
    }
    await this.leaveRoom();
  }

  private async _onMemberRoleChangeByHost(newRoles: UserRoleModel[]): Promise<void> {
    this.currentUser.userRoles = newRoles;
    if (this.currentUser.isAttendee()) {
      this.audioPublished = false;
      this.videoPublished = false;
      await this.rtcClient.unpublish();
      await this.muteAudio();
      await this.muteVideo();
      await this.stopScreenShare();
      await this._setClientRoleAttendee();
      this._conferenceService.allowAttendeeToUnmute(false);
    } else {
      await this._setClientRoleHost();
      if (this.currentUser.raisedHand) {
        this.lowerHand();
      }
    }
  }

  private async _onRaiseHandByAttendee(attendeeId: number): Promise<void> {
    // Has a seperate raise hand component for host/cohost to handle this
    if (this.currentUser.isHostOrCoHost()) { return; }
    const user = this._eventService.findAttendee(attendeeId);
    if (user) {
      this._conferenceService.addRaisedHandMember(user);
    }
  }

  private async _onLowerHandByAttendee(attendeeId: number): Promise<void> {
    // Has a seperate raise hand component for host/cohost to handle this
    if (this.currentUser.isHostOrCoHost()) { return; }
    if (attendeeId) {
      this._conferenceService.removeRaisedHandMember(attendeeId);
    }
  }

  observableRef: any;
  private async _registerRecordingEvents(): Promise<void> {

    this._conferenceService.onRecordingStateChange$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe(async res => {
        this.isBeingRecorded = res?.state == 'recording';
        this._changeDetectorRef.detectChanges();
      });

    this.observableRef = interval(.5 * 60 * 1000)
      .pipe(
        takeUntil(this._unsubscribeAll),
        mergeMap(async () => {
          const memberCount = await this._conferenceService.getMembersCount();
          if (memberCount == 0 && this.currentUser.isSystemUser()) {
            try {
              this._recordingService.stopRecording(this.roomData.roomId, this.recording_sid)
                .pipe(takeUntil(this._unsubscribeAll)).subscribe({
                  next: async (res) => {
                    try { await this.sendStopRecordingNotificationByBot(); } catch { }
                    await this.leaveRoom();
                    if (this.observableRef) {
                      this.observableRef.unsubscribe();
                    }
                  },
                  error: async (err) => {
                    try { await this.sendStopRecordingNotificationByBot(); } catch { }
                    await this.leaveRoom();
                    if (this.observableRef) {
                      this.observableRef.unsubscribe();
                    }
                  }
                });
            } catch (e) {
              await this.leaveRoom();
              if (this.observableRef) {
                this.observableRef.unsubscribe();
              }
            }
          }
        })
      ).subscribe(data => { })
  }


  private async sendRecordingTimerChangeSignal(): Promise<void> {
    if (this.currentUser.isSystemUser()) {
      let payload = {
        sid: this.recording_sid,
        state: this.recording_state,
        uid: this.recording_uid,
        timestamp: this.recording_elapsed_timerValueForSystemUser
      } as RecordingInfoPayload;
      const data = {
        receiverIds: [],
        receiverId: this.roomData.roomId,
        command: CommandType.recordingTimerChange,
        signalLevel: SignalLevel.room,
        receiverType: this.roomData.roomType,
        data: {
          roomId: this.roomData.roomId,
          extra: payload
        } as SignalDataContent,
      } as SignalDataModel;
      await this._signalrService.sendSignal(data);
    }
  }

  private startTimer(): void {
    this.recording_timerIntervalId = setInterval(() => {
      this.recording_elapsed_timerValueForSystemUser = this.recording_elapsed_timerValueForSystemUser + 1;
      this.sendRecordingTimerChangeSignal();
    }, 1000);
  }

  private pauseTimer(): void {
    if (this.recording_timerIntervalId) {
      try { clearInterval(this.recording_timerIntervalId); } catch { }
      this.sendRecordingTimerChangeSignal();
    }
  }

  private stopTimer(): void {
    try { clearInterval(this.recording_timerIntervalId); } catch { }
    this.recording_elapsed_timerValueForSystemUser = 0;
    this.sendRecordingTimerChangeSignal();
  }

  private async sendStopRecordingNotificationByBot(): Promise<void> {
    let payload = {
      state: 'inactive',
      sid: this.recording_sid,
      uid: this.recording_uid
    } as RecordingInfoPayload;
    const data = {
      receiverIds: [],
      receiverId: this.roomData.roomId,
      command: CommandType.recordingStateChange,
      signalLevel: SignalLevel.room,
      receiverType: this.roomData.roomType,
      data: {
        roomId: this.roomData.roomId,
        extra: payload
      } as SignalDataContent,
    } as SignalDataModel;
    await this._signalrService.sendSignal(data);
  }
}
