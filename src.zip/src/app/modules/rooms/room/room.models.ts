/* eslint-disable no-unused-vars */
import { ImageViewModel } from 'src/app/shared/models/event.model';
import { UserModel } from '../../../shared/models/user.model';

export type VideoSource = 'youtube' | 'vimeo' | 'wistia' | 'sproutvideo' | 'bigmarker' | 'eventcombo';
export enum EnumVideoSource {
  image = 'youtube',
  video = 'vimeo',
  wistia = 'wistia',
  sproutvideo = 'sproutvideo',
  bigmarker = 'bigmarker',
  eventcombo = 'eventcombo'
}

export type MediaType = 'image' | 'video';
export enum EnumMediaType {
  image = 'image',
  video = 'video'
}

export type RoomType = 'warroom' | 'reception' | 'stage' | 'networking' | 'session' | 'expo' | 'customroom' | 'keynoteroom'
  | 'handouts' | 'private' | 'breakout' | 'greenroom' | 'session_booth' | 'expo_booth' | 'networking_booth';

export enum EnumRoomType {
  reception = 'reception',
  stage = 'stage',
  networking = 'networking',
  session = 'session',
  expo = 'expo',
  customRoom = 'customroom',
  keynote = 'keynoteroom',
  handouts = 'handouts',
  private = 'private',
  breakout = 'breakout',
  greenRoom = 'greenroom',
  sessionBooth = 'session_booth',
  expoBooth = 'expo_booth',
  networkingBooth = 'networking_booth'
}
export type AttendeeAllocationType = 'automatic' | 'mannual' | 'none';

export class RoomStorageModel {
  storageKey: string;
  fileName: string;
  title: string;
  description: string;
  videoUrl: string;
}

export class RoomSettingsModel {
  maxParticipants: number;
  isEnabled: boolean;
  isRoomAccessible: boolean;
  isRoomOpen: boolean;
  isAllowedToJoinRoom: boolean;
  groupChatEnabled: boolean;
  privateChatEnabled: boolean;
  oneToOneNetworkingEnabled: boolean;
  handoutsEnabled: boolean;
  pollsAndSurveyEnabled: boolean;
  guestInviteEnabled: boolean;
  recordingEnabled: boolean;
  speakersEnabled: boolean;
  sponsorsEnabled: boolean;
  schedulesEnabled: boolean;
  attendeesEnabled: boolean;
  backgroundImageEnabled: boolean;
  attendeesCountEnabled: boolean;
  attendeeViewEnabled: boolean;
  peopleSectionEnabled: boolean;
  ticketRestrictionEnabled: boolean;
  showBoothWhenTicketNotMatched: boolean;
  autoPlayEnabled: boolean;
  canAttendeePlayVideo: boolean;
  boardBackgroundColor: string;
  boardTextColor: string;
}

export class RoomModel {

  constructor() {
    this.settings = new RoomSettingsModel();
    this.logoImage = new ImageViewModel();
    this.roomImage = new ImageViewModel();
    this.thumbImage = new ImageViewModel();
    this.backgroundImage = new ImageViewModel();
  }

  roomId: number;
  roomName: string;
  roomType: RoomType;
  description: string;
  mediaType: MediaType;
  eventId: number;
  streamId: string;
  category: string;

  videoSource: VideoSource;
  videoUrl: string;
  roomStorage: RoomStorageModel;
  createdDateUtc: Date;
  updatedDateUtc?: Date;
  scheduleId?: any;
  selectedSchedule?: any;

  grandSponsorId: number;
  grandSponsorUrl: string;
  grandSponsorName: string;

  // eslint-disable-next-line no-use-before-define
  booths: RoomModel[];
  roomChannelName: string;

  roomCloseCountDownTime: number;
  roomEndTime: number;
  createDateUtc: Date;
  roomOpenDateUtc: Date;
  isRoomOpen: boolean;

  waitRoomRemoveBy: number;
  warroomCardMsg: string;

  whoCanPlay: boolean;
  whoCanJoin: string;
  whoCanWatch: string;

  

  settings: RoomSettingsModel;

  boothPriority: string;
  boothSize: string;
  vendorName: string;
  vendorEmail: string;
  vendorHeadline: string;
  vendorDescription: string;
  parentRoomId: number;
  websiteLink: string;
  googleLink: string;
  facebookLink: string;
  instagramLink: string;
  twitterLink: string;
  linkedinLink: string;
  logoImage: ImageViewModel;
  thumbImage: ImageViewModel;  
  roomImage: ImageViewModel;
  backgroundImage: ImageViewModel;
}

export interface PrivateRoomModel {
  privateRoomId: number;
  roomName: string;
  userId: number;
  streamId: string;
  allowHandouts: boolean;
  allowPollsAndSurvey: boolean;
  allowGuestInvite: boolean;
  allowRecording: boolean;
  participantIds: string;
  eventId: number;
  isRoomOpen: boolean;
  roomEndTime: number;
  roomCloseCountDownTime: number;
  roomParticipants: UserModel[];
  checked: boolean;
  eventChannelName: string;
  roomChannelName: string;
  accessToken: string;
  isAllowedToJoinRoom: boolean;
  waitRoomRemoveBy: number;
  roomOpenDateTimeUtc: Date;
  enableEdit: boolean;
}

export interface BreakoutRoomModel {
  vEventId: number;
  attendeePerBreakout: number;
  attendeeAllocationType: AttendeeAllocationType;
  rooms: PrivateRoomModel[];
}

export class BreakoutRoomValidationResult {
  roomActiveAndOpen: boolean = false;
  remainingCountDown: number = 0;
}

export type RoomImageType = 'logoImage' | 'backgroundImage' | 'roomImage' | 'thumbImage';

