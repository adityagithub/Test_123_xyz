import { Overlay, OverlayRef } from '@angular/cdk/overlay';
import { TemplatePortal } from '@angular/cdk/portal';
import {
  AfterViewInit,
  ChangeDetectionStrategy, ChangeDetectorRef, Component, ElementRef,
  OnDestroy, OnInit, TemplateRef, ViewChild, ViewContainerRef, ViewEncapsulation
} from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { NotificationModel } from 'src/app/shared/models/notifications.models';
import { NotificationsService } from 'src/app/shared/services/notifications.service';
import { EventModel } from 'src/app/shared/models/event.model';
import { CommandType, SignalLevel, SignalDataContent, SignalDataModel, ChatSectionType, ChatDataModel } from 'src/app/shared/models/signalr.models';
import { EventService } from 'src/app/shared/services/event.service';
import { MessageService } from 'src/app/shared/services/message.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { UserModel, UserStatusEnum } from '../../../../shared/models/user.model';
import { UserService } from '../../../../shared/services/user.service';
import { RoomService } from '../room.service';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import { NgxSpinnerModule } from 'ngx-spinner';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { MaterialModule } from 'src/app/core/material.module';

@Component({
  selector: 'invite-people',
  templateUrl: './invite-people.component.html',
  styleUrls: ['./invite-people.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  standalone: true,
  imports: [
    MaterialModule,
    FwCoreModule,
    NgxSpinnerModule
  ]
})
export class InvitePeopleComponent implements OnInit, OnDestroy, AfterViewInit {
  private _overlayRef: OverlayRef;
  private _unsubscribeAll: Subject<any> = new Subject<any>();
  private _peoples: UserModel[];

  currentUser: UserModel;
  eventData: EventModel;
  panelOpened: boolean;
  statusEnum = UserStatusEnum;
  searchTerm: string;
  filteredPeoples: UserModel[];
  resourceBaseUrl: string

  @ViewChild('invitePeopleOrigin') private _invitePeopleOrigin: ElementRef<any>;
  @ViewChild('invitePeoplePanel') private _invitePeoplePanel: TemplateRef<any>;

  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _overlay: Overlay,
    private _viewContainerRef: ViewContainerRef,
    private _settingService: AppSettingService,
    private _messageService: MessageService,
    private _signalrService: SignalrService,
    private _userService: UserService,
    private _eventService: EventService,
    private _roomService: RoomService,
    private _notificationService: NotificationsService
  ) {
    this.resourceBaseUrl = this._settingService.settings.resourceBaseUrl;
  }

  ngAfterViewInit(): void {

  }

  ngOnInit(): void {
    this._userService.user$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((user) => {
        this.currentUser = user;
        this._changeDetectorRef.markForCheck();
      });

    this._eventService.event$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((data: EventModel) => {
        if (data) {
          this.eventData = data;
          this._changeDetectorRef.markForCheck();
        }
      });

    this._eventService.attendees$.pipe(takeUntil(this._unsubscribeAll))
      .subscribe((members: UserModel[]) => {
        // const room = this._roomService.currentRoom as unknown as PrivateRoomModel;
        // const connectedUserIds = room.participantIds.split(',').map(m => Number.parseInt(m));
        this._peoples =  members.filter(m => m.userId !== this.currentUser.userId);
        this.filteredPeoples = this._peoples.filter(p => p.isOnline());
        this._changeDetectorRef.markForCheck();
      });

    this._signalrService.onNewSignal$.pipe(takeUntil(this._unsubscribeAll)).subscribe(res => {
      if (res && res.command === CommandType.userStatusChanged) {
        const targetAtt = this._peoples.find(a => a.userId === res.data.userId);
        if (targetAtt) {
          targetAtt.status = res.data.status;
        }
        this.filteredPeoples = this._peoples.filter((a) => a.isOnline());
        this.filterByQuery(this.searchTerm);
        this._changeDetectorRef.markForCheck();
      }
    });
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
    if (this._overlayRef) {
      this.panelOpened = false;
      this._overlayRef.dispose();
    }
  }

  openPanel(): void {
    if (!this._invitePeoplePanel || !this._invitePeopleOrigin) {
      return;
    }

    if (this.panelOpened) {
      return;
    }

    if (!this._overlayRef) {
      this._createOverlay();
    }

    this._overlayRef.attach(new TemplatePortal(this._invitePeoplePanel, this._viewContainerRef));
    this.panelOpened = true;
  }

  closePanel(): void {
    this.panelOpened = false;
    this._overlayRef.detach();
    this._changeDetectorRef.markForCheck();
  }

  async filterByQuery(search: string): Promise<void> {
    if(!search) return;
    this.filteredPeoples = this._peoples.filter((att) => {
      return att.getFullName().toLowerCase().includes(search.toLowerCase());
    });
  }

  private _createOverlay(): void {
    this._overlayRef = this._overlay.create({
      hasBackdrop: true,
      backdropClass: 'fw-backdrop',
      scrollStrategy: this._overlay.scrollStrategies.block(),
      positionStrategy: this._overlay.position()
        .flexibleConnectedTo(this._invitePeopleOrigin.nativeElement)
        .withLockedPosition()
        .withDefaultOffsetX(54)
        .withPush(true)
        .withPositions([
          {
            originX: 'start',
            originY: 'bottom',
            overlayX: 'start',
            overlayY: 'bottom'
          },
          {
            originX: 'start',
            originY: 'top',
            overlayX: 'start',
            overlayY: 'bottom'
          },
          {
            originX: 'end',
            originY: 'bottom',
            overlayX: 'end',
            overlayY: 'top'
          },
          {
            originX: 'end',
            originY: 'top',
            overlayX: 'end',
            overlayY: 'bottom'
          }
        ])
    });

    this._overlayRef.backdropClick().subscribe(() => {
      this.panelOpened = false;
      this._overlayRef.detach();
      this._changeDetectorRef.markForCheck();
    });
  }

  clearSearch(): void {
    this.searchTerm = '';
    this.filterByQuery('')
  }

  async addUserToPrivateRoomAndSendInvite(event: any, member: UserModel): Promise<void> {
    const privateRoomInfo = {
      privateRoomId: this._roomService.currentRoomId,
      participantId: member.userId
    };

    this._roomService.addUserToPrivateRoom(privateRoomInfo).pipe(takeUntil(this._unsubscribeAll)).subscribe(room => {
      if (room) {
        const invitationMessage = `I would like to invite you to a private room. Please join using this <a class="private_room_invite_link" data-roomid="${privateRoomInfo.privateRoomId}">link</a>`;
        const notification = {
          notificationMessage: invitationMessage,
          notificationSentBy: this.currentUser.userId,
          notificationSentFor: member.userId.toString(),
          notificationType: 'invitation',
          eventId : this.eventData.eventId,
          virtualEventId: this.eventData.virtualEventId
        } as NotificationModel;

        this._notificationService.addUserNotification(notification)
          .pipe(takeUntil(this._unsubscribeAll)).subscribe(async notification => {
            if (!notification) {
              this._messageService.showErrorMessage('Failed to send invitation to ' + member.fullName);
              return;
            }

            const message = {
              messageId: '',
              message: invitationMessage,
              messageType: 'text',
              createdDateUtc: new Date(),
              receiverId: member.userId,
              receiverName: member.getFullName(true),
              senderName: this.currentUser.getFullName(true),
              senderId: this.currentUser.userId,
              chatSection: ChatSectionType.private
            } as ChatDataModel;

            this._signalrService.sendMessage(message).then(r => {
              const userMessage = `Invite successfully sent to ${member.getFullName(true)}.`;
              this._messageService.showInfoMessage(userMessage);
            });

            const signalData = {
              receiverId: member.userId,
              command: CommandType.newNotification,
              signalLevel: SignalLevel.person,
              data: {} as SignalDataContent
            } as SignalDataModel;
            await this._signalrService.sendSignal(signalData)
          });
      }
    });
  }
}
