import {
  AfterViewInit,
  ChangeDetectorRef, Component, ElementRef, Inject,
  OnDestroy, OnInit, ViewChild, ViewEncapsulation
} from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import AgoraRTC from 'agora-rtc-sdk-ng';
import { NgxSpinnerService } from 'ngx-spinner';
import { interval, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import VirtualBackgroundExtension, { IVirtualBackgroundProcessor } from 'agora-extension-virtual-background';
import { BackgroundImage, IMediaSettingsSerializable, LocalTracks, MediaSettingsData } from './media-settings.models';
import { NgxDropzoneChangeEvent } from 'ngx-dropzone';
import { MessageService } from 'src/app/shared/services/message.service';
import { UserService } from 'src/app/shared/services/user.service';
import { UserModel } from 'src/app/shared/models/user.model';
import { RoomModel } from '../room.models';
import { RoomService } from '../room.service';

@Component({
  selector: 'media-settings-dialog',
  templateUrl: './media-settings.component.html',
  styleUrls: ['./media-settings.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class MediaSettingsDialogComponent implements OnInit, AfterViewInit, OnDestroy {
  preLocalPlayerId = 'pre-local-player';
  localTracks: LocalTracks = { audioTrack: null, videoTrack: null, screenTrack: null, whiteboard: null };
  dialogData: MediaSettingsData;
  mediaSettingForm: FormGroup;
  currentUser: UserModel;
  currentRoom: RoomModel;
  isSoundPlaying = false;
  customBackgrounImage: File;
  processor: IVirtualBackgroundProcessor;
  micPermissionError: boolean = false;
  cameraPermissionError: boolean = false;
  speakerPermissionError: boolean = false;

  backgrounds: BackgroundImage[] = [
    { id: 1, title: '', active: true, selected: false, src: './assets/images/backgrounds/1.jpg', preDefined: true },
    { id: 2, title: '', active: true, selected: false, src: './assets/images/backgrounds/2.jpg', preDefined: true },
    { id: 3, title: '', active: true, selected: false, src: './assets/images/backgrounds/3.jpg', preDefined: true },
    { id: 4, title: '', active: true, selected: false, src: './assets/images/backgrounds/4.jpg', preDefined: true },
    { id: 5, title: '', active: true, selected: false, src: './assets/images/backgrounds/5.jpg', preDefined: true },
    { id: 6, title: '', active: true, selected: false, src: './assets/images/backgrounds/6.jpg', preDefined: true },
    { id: 7, title: '', active: true, selected: false, src: './assets/images/backgrounds/7.jpg', preDefined: true },
    { id: 8, title: '', active: true, selected: false, src: './assets/images/backgrounds/8.jpg', preDefined: true },
    { id: 9, title: '', active: true, selected: false, src: './assets/images/backgrounds/9.jpg', preDefined: true },
    { id: 10, title: '', active: true, selected: false, src: './assets/images/backgrounds/10.jpg', preDefined: true },
    { id: 11, title: '', active: true, selected: false, src: './assets/images/backgrounds/11.jpg', preDefined: true },
    { id: 12, title: '', active: true, selected: false, src: './assets/images/backgrounds/12.jpg', preDefined: true },
    { id: 13, title: '', active: true, selected: false, src: './assets/images/backgrounds/13.jpg', preDefined: true },
    { id: 14, title: '', active: true, selected: false, src: '', preDefined: false },
    { id: 15, title: '', active: true, selected: false, src: './assets/images/backgrounds/15.jpg', preDefined: true },
    { id: 16, title: '', active: true, selected: false, src: './assets/images/backgrounds/16.jpg', preDefined: true },
    { id: 17, title: '', active: true, selected: false, src: './assets/images/backgrounds/14.jpg', preDefined: true }
  ];

  supportedVideoQuality: any[] = [
    { key: '240', value: '240p' },
    { key: '360', value: '360p' },
    { key: '480', value: '480p' },
    { key: '720', value: '720p' },
    { key: '720', value: '1080p' }
  ];

  private _audioPlayer: HTMLAudioElement;
  private _virtualBackgroundeExtension: VirtualBackgroundExtension;
  private _unsubscribeAll: Subject<any> = new Subject();

  @ViewChild('player_control') player_control: ElementRef;
  @ViewChild('videoSection') set videoSection(elmnt: ElementRef) {
    if (elmnt) {
      setTimeout(() => {
        elmnt.nativeElement.classList.remove('control-opacity-1');
      }, 5000);
    }
  };

  constructor(
    private _matDialogRef: MatDialogRef<MediaSettingsDialogComponent>,
    private _formBuilder: FormBuilder,
    private _changeDetectorRef: ChangeDetectorRef,
    private spinner: NgxSpinnerService,
    @Inject(MAT_DIALOG_DATA)
    private _data: MediaSettingsData,
    private _messageService: MessageService,
    private _userService: UserService,
    private _roomService: RoomService
  ) {
    this._matDialogRef.disableClose = true;
    this.dialogData = _data;
    this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe(async user => {
      this.currentUser = user;
    });
    this._roomService.roomDetails$.pipe(takeUntil(this._unsubscribeAll)).subscribe(async room => {
      this.currentRoom = room;
    });
  }

  async ngOnInit(): Promise<void> {
    try {
      this.spinner.show();

      if (!this.dialogData.selectedVideoQuality) {
        this.dialogData.selectedVideoQuality = '480';
      }

      await this._initMediaDevices(this.dialogData);

      this.mediaSettingForm = this._formBuilder.group({
        camera: new FormControl(this.dialogData.selectedCamId),
        mic: new FormControl(this.dialogData.selectedMicId),
        speaker: new FormControl(this.dialogData.selectedSpeakerId),
        videoQuality: new FormControl(this.dialogData.selectedVideoQuality)
      });

      this._changeDetectorRef.detectChanges();

      if (this.localTracks.videoTrack && document.getElementById(this.preLocalPlayerId)) {
        this.localTracks.videoTrack.play(this.preLocalPlayerId);
      }

      interval(150).pipe(takeUntil(this._unsubscribeAll)).subscribe(async () => {
        await this._colorVolumeBox(this.localTracks?.audioTrack?.getVolumeLevel() * 100);
      });

      this._virtualBackgroundeExtension = new VirtualBackgroundExtension();

      AgoraRTC.registerExtensions([this._virtualBackgroundeExtension]);

      await this._registerMediaSettingFormEvents();
    } finally {
      this.spinner.hide();
    }
  }


  async ngAfterViewInit(): Promise<void> {

  }

  async ngOnDestroy(): Promise<void> {
    await this._stopPlayingMedia(this.localTracks);
    await this.stopPlayingSampleSound();
    setTimeout(async () => {
      await this._stopPlayingMedia(this.localTracks);
    }, 2000);

    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  private async _registerMediaSettingFormEvents(): Promise<void> {
    this.mediaSettingForm.controls.mic.valueChanges.subscribe(async (value) => {
      await this.localTracks.audioTrack.setDevice(value);
      // after changing microphone device, by default it will be enabled
      if (this.dialogData.audioTrackMuted) {
        await this.muteAudio();
      }
    });

    this.mediaSettingForm.controls.camera.valueChanges.subscribe(async (value) => {
      await this.localTracks.videoTrack.setDevice(value);
      // after changing camera device, by default it will be enabled
      if (this.dialogData.videoTrackMuted) {
        setTimeout(async () => {
          await this.muteVideo();
        }, 500);
      }
    });

    this.mediaSettingForm.controls.speaker.valueChanges.subscribe(async (value) => {
      this.localTracks.audioTrack.setPlaybackDevice(value);
    });

    this.mediaSettingForm.controls.videoQuality.valueChanges.subscribe(async (value) => {
      await this.localTracks.videoTrack.setEncoderConfiguration(value);
    });
  }

  private async _stopPlayingMedia(media: LocalTracks): Promise<void> {
    if (media) {
      for (const trackName in this.localTracks) {
        const track = this.localTracks[trackName];
        if (track) {
          track.stop();
          track.close();
          this.localTracks[trackName] = null;
        }
      }
    }
  }

  private async _colorVolumeBox(vol: number): Promise<void> {
    const allBoxes = Array.from(document.querySelectorAll('.meter'));
    for (const b of allBoxes) {
      (b as any).style.backgroundColor = '#e6e7e8';
      (b as any).classList.remove('active');
    }
    if (!this.dialogData.audioTrackMuted) {
      const numberOfPidsToColor = Math.round(vol / 4);
      const boxesToColor = allBoxes.slice(0, numberOfPidsToColor);
      for (const b of boxesToColor) {
        (b as any).classList.add('active');
      }
    }
  }

  private async _initMediaDevices(dialogData: MediaSettingsData): Promise<void> {
    try { this.localTracks.audioTrack = await AgoraRTC.createMicrophoneAudioTrack() } catch (e) { this._handleMicDeviceError(e) }
    try { dialogData.mics = await AgoraRTC.getMicrophones(); } catch (e) { this._handleMicDeviceError(e) }
    try { dialogData.cams = await AgoraRTC.getCameras(); } catch (e) { this._handleCameraDeviceError(e) }
    if (this.videoSettingEnabled) {
      try { this.localTracks.videoTrack = await AgoraRTC.createCameraVideoTrack() } catch (e) { this._handleCameraDeviceError(e) }
    }

    try { dialogData.speakers = await AgoraRTC.getPlaybackDevices(); } catch (e) { this._handleSpeakerDeviceError(e) }

    if (dialogData.mics && dialogData.mics.length) {
      if (!dialogData.selectedMicId || dialogData.mics.findIndex(x => x.deviceId === dialogData.selectedMicId) === -1) {
        dialogData.selectedMicId = dialogData.mics[0].deviceId;
        // await this.localTracks.audioTrack.setDevice(dialogData.selectedMicId);
      }
    }

    if (dialogData.cams && dialogData.cams.length) {
      if (!dialogData.selectedMicId || dialogData.cams.findIndex(x => x.deviceId === dialogData.selectedCamId) === -1) {
        dialogData.selectedCamId = dialogData.cams[0].deviceId;
        // await this.localTracks.videoTrack.setDevice(dialogData.selectedCamId);
      }
    }

    if (dialogData.speakers && dialogData.speakers.length) {
      if (!dialogData.selectedSpeakerId || dialogData.speakers.findIndex(x => x.deviceId === dialogData.selectedSpeakerId) === -1) {
        dialogData.selectedSpeakerId = dialogData.speakers[0].deviceId;
        // this.localTracks.audioTrack.setPlaybackDevice(dialogData.selectedSpeakerId);
      }
    }

    if (dialogData.virtualBackground && dialogData.virtualBackground.isEnabled) {
      if (dialogData.virtualBackground.type === 'img' && dialogData.virtualBackground.backgoundImage) {
        this.applyBackground(dialogData.virtualBackground.backgoundImage);

        if (!dialogData.virtualBackground.backgoundImage.preDefined) {
          fetch(dialogData.virtualBackground.backgoundImage.src).then(async res => {
            const blob = await res.blob();
            this.customBackgrounImage = blob as File;
          });
        }
      }

      if (dialogData.virtualBackground.type === 'blur') {
        // TODO
      }

      if (dialogData.virtualBackground.type === 'color') {
        // TODO
      }
    }
  }

  private async _getProcessorInstance(extension: VirtualBackgroundExtension): Promise<IVirtualBackgroundProcessor> {
    if (!this.processor && this.localTracks.videoTrack) {
      this.processor = extension.createProcessor();
      await this.processor.init('./assets/agora/wasms');
      this.localTracks.videoTrack.pipe(this.processor).pipe(this.localTracks.videoTrack.processorDestination);
    }
    return this.processor;
  }

  private async _setBackgroundImage(src: string) {
    const imgElement = document.createElement('img');

    imgElement.onload = async () => {
      this.spinner.show();
      try {
        this.processor = this.processor ?? await this._getProcessorInstance(this._virtualBackgroundeExtension);
        this.processor.setOptions({ type: 'img', source: imgElement });
        await this.processor.enable();
      } finally {
        this.spinner.hide();
      }
    }
    imgElement.src = src;
  }

  private async _setBackgroundColor() {
    if (this.localTracks.videoTrack) {
      this.spinner.show();
      try {
        this.processor = this.processor ?? await this._getProcessorInstance(this._virtualBackgroundeExtension);
        this.processor.setOptions({ type: 'color', color: '#00ff00' });
        await this.processor.enable();
      } finally {
        this.spinner.hide();
      }
    }
  }

  private async _setBackgroundBlurring() {
    if (this.localTracks.videoTrack) {
      this.spinner.show();
      try {
        this.processor = this.processor ?? await this._getProcessorInstance(this._virtualBackgroundeExtension);
        this.processor.setOptions({ type: 'blur', blurDegree: 2 });
        await this.processor.enable();
      } finally {
        this.spinner.hide();
      }
    }
  }

  async removeVirtualBackground(): Promise<void> {
    if (this.processor && this.processor.enabled) {
      await this.processor.disable();
    }
    this.backgrounds.forEach(b => { b.selected = false });
    this.dialogData.virtualBackground.reset();
  }

  async playSampleSound(): Promise<void> {
    this._audioPlayer = await this._messageService.getSampleAudioPlayer();
    this._audioPlayer.play();
    this.isSoundPlaying = true;
  }

  async stopPlayingSampleSound(): Promise<void> {
    if (this._audioPlayer) {
      this._audioPlayer.pause();
      this._audioPlayer.currentTime = 0;
      this.isSoundPlaying = false;
    }
  }

  async muteAudio(): Promise<void> {
    if (!this.localTracks.audioTrack) return;
    await this.localTracks.audioTrack.setMuted(true);
    this.dialogData.setAdudioMuted(true);
  }

  async muteVideo(): Promise<void> {
    if (!this.localTracks.videoTrack) return;
    await this.localTracks.videoTrack.setMuted(true);
    this.dialogData.setVideoMuted(true);
  }

  async unmuteAudio(): Promise<void> {
    if (!this.localTracks.audioTrack) return;
    await this.localTracks.audioTrack.setMuted(false);
    this.dialogData.setAdudioMuted(false);
  }

  async unmuteVideo(): Promise<void> {
    if (!this.localTracks.videoTrack) return;
    await this.localTracks.videoTrack.setMuted(false);
    this.dialogData.setVideoMuted(false);
  }

  async applyBackground(imgData: BackgroundImage, custom: boolean = false): Promise<void> {
    if (!this.localTracks.videoTrack) {
      this._messageService.showErrorMessage('Camera must be enabled to set virtual backgound!');
      return;
    }

    if(custom && this.customBackgrounImage) {
      let objectURL = URL.createObjectURL(this.customBackgrounImage);
      await this._setBackgroundImage(imgData.src);
      this.backgrounds.forEach(b => { b.selected = false });
      const backgoundImage = {
        id: 0,
        title: this.customBackgrounImage.name,
        active: true,
        preDefined: false,
        src: objectURL,
        selected: true
      } as BackgroundImage;
      await this._setBackgroundImage(backgoundImage.src);
      this.dialogData.virtualBackground.setEnabled('img', backgoundImage);
      return;
    }

    else if (imgData && imgData.src) {
      await this._setBackgroundImage(imgData.src);
      this.backgrounds.forEach(b => { b.selected = false });
      const img = this.backgrounds.find(x => x.id === imgData.id);
      if (img && img.preDefined) {
        img.selected = true;
      }
      this.dialogData.virtualBackground.setEnabled('img', imgData);
    }
  }

  async onImageUpload(event: NgxDropzoneChangeEvent) {
    if (event.addedFiles && event.addedFiles.length) {
      const reader = new FileReader();
      const file = event.addedFiles[0];
      reader.readAsDataURL(file);
      reader.onload = () => {
        const backgoundImage = {
          id: 0,
          title: file.name,
          active: true,
          preDefined: false,
          src: (reader.result as string),
          selected: true
        } as BackgroundImage;
        this.dialogData.virtualBackground.setBackgroundImage(backgoundImage);
        this.dialogData.virtualBackground.disable();
        this.customBackgrounImage = file;
      };
    }
  }

  async onRemoved(event: any): Promise<void> {
    this.removeVirtualBackground();
    this.customBackgrounImage = null;
  }

  async saveSettings(): Promise<void> {
    const res = this.dialogData as IMediaSettingsSerializable
    this._matDialogRef.close(res);
  }

  closeDialog(): void {
    this._matDialogRef.close()
  }

  private _handleMicDeviceError(err: any): void {
    this.micPermissionError = true;
    console.log(err);
  }

  private _handleCameraDeviceError(err: any): void {
    this.cameraPermissionError = true;
    console.log(err);
  }

  private _handleSpeakerDeviceError(err: any): void {
    this.speakerPermissionError = true;
    console.log(err);
  }

  get videoSettingEnabled() {
    return (!this.currentUser.isAttendee() || this.currentRoom?.roomType == 'breakout' || this.currentRoom?.roomType == 'private');
  }
}
