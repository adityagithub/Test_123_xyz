/* eslint-disable no-empty */
import { IMicrophoneAudioTrack, ICameraVideoTrack, ILocalVideoTrack } from 'agora-rtc-sdk-ng';

export class BackgroundImage {
  id: number;
  title: string;
  src: string;
  active: boolean;
  selected: boolean;
  preDefined: boolean;
}

export class LocalTracks {
  audioTrack: IMicrophoneAudioTrack;
  videoTrack: ICameraVideoTrack;
  screenTrack: ILocalVideoTrack;
  whiteboard: any // WhiteWebSdk;
}

export class VirtualBackground {
  isEnabled: boolean;

  type: 'img' | 'color' | 'blur';

  backgoundImage: BackgroundImage;
  color: string;

  blurDegree: number;

  disable() {
    this.isEnabled = false;
  }

  setEnabled(type: 'img' | 'color' | 'blur', value: any) {
    this.isEnabled = true;
    this.type = type;
    if (type === 'img') {
      const imgData = value as BackgroundImage;
      this.backgoundImage = imgData;
    }

    if (type === 'blur') {
    }

    if (type === 'color') {
    }
  }

  setBackgroundImage(img: BackgroundImage) {
    this.backgoundImage = img;
  }

  reset() {
    this.isEnabled = false;
    this.backgoundImage = null;
  }
}

export interface IMediaSettingsSerializable {
  audioTrackMuted: boolean;
  videoTrackMuted: boolean;
  selectedMicId: string;
  selectedCamId: string;
  selectedSpeakerId: string;
  selectedVideoQuality: string;
  virtualBackground: VirtualBackground;
}

export class MediaSettingsData implements IMediaSettingsSerializable {
  static localStorageSettingKey: string = 'media-devices.settings';

  constructor(json: IMediaSettingsSerializable) {
    this.selectedCamId = json.selectedCamId;
    this.selectedMicId = json.selectedMicId;
    this.selectedSpeakerId = json.selectedSpeakerId;
    this.selectedVideoQuality = json.selectedVideoQuality;
    this.audioTrackMuted = json.audioTrackMuted ?? true;
    this.videoTrackMuted = json.videoTrackMuted ?? true;
    this.virtualBackground = new VirtualBackground();

    if (json.virtualBackground) {
      this.virtualBackground.isEnabled = json.virtualBackground.isEnabled;
      this.virtualBackground.blurDegree = json.virtualBackground.blurDegree;
      this.virtualBackground.color = json.virtualBackground.color;
      this.virtualBackground.type = json.virtualBackground.type;

      this.virtualBackground.backgoundImage = new BackgroundImage();
      if (json.virtualBackground.backgoundImage) {
        this.virtualBackground.backgoundImage.id = json.virtualBackground.backgoundImage.id;
        this.virtualBackground.backgoundImage.active = json.virtualBackground.backgoundImage.active;
        this.virtualBackground.backgoundImage.preDefined = json.virtualBackground.backgoundImage.preDefined;
        this.virtualBackground.backgoundImage.src = json.virtualBackground.backgoundImage.src;
        this.virtualBackground.backgoundImage.selected = json.virtualBackground.backgoundImage.selected;
        this.virtualBackground.backgoundImage.title = json.virtualBackground.backgoundImage.title;
      }
    }
  }

  audioTrackMuted: boolean;
  videoTrackMuted: boolean;
  screenTrackMuted: boolean;
  selectedMicId: string;
  selectedCamId: string;
  selectedSpeakerId: string;
  selectedVideoQuality: string;
  virtualBackground: VirtualBackground;

  mics: MediaDeviceInfo[] = [];
  cams: MediaDeviceInfo[] = [];
  speakers: MediaDeviceInfo[] = [];

  setAdudioMuted(muted: boolean) {
    this.audioTrackMuted = muted;
    const settingString = localStorage.getItem(MediaSettingsData.localStorageSettingKey);
    if (settingString) {
      const setting = JSON.parse(settingString);
      setting.audioTrackMuted = muted;
      localStorage.setItem(MediaSettingsData.localStorageSettingKey, JSON.stringify(setting));
    }
  }

  setVideoMuted(muted: boolean) {
    this.videoTrackMuted = muted;
    const settingString = localStorage.getItem(MediaSettingsData.localStorageSettingKey);
    if (settingString) {
      const setting = JSON.parse(settingString);
      setting.videoTrackMuted = muted;
      localStorage.setItem(MediaSettingsData.localStorageSettingKey, JSON.stringify(setting));
    }
  }
}
