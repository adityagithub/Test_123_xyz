import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'no-schedule',
  templateUrl: './no-schedule.component.html',
  styleUrls: ['./no-schedule.component.scss']
})
export class RoomNoScheduleComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }
}
