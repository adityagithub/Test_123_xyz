import {
  AfterViewInit, ChangeDetectionStrategy, ChangeDetectorRef,
  Component, ElementRef, HostListener, Inject, OnDestroy, OnInit, ViewChild, ViewEncapsulation
} from '@angular/core';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { differenceInSeconds } from 'date-fns';
import * as moment from 'moment';
import { GuidedTourService } from 'ngx-guided-tour';
import { Subject, interval } from 'rxjs';
import { map, takeUntil } from 'rxjs/operators';
import { appAnimations } from 'src/app/core/animations';
import { EventModel, EventPollModel, EventScheduleModel } from 'src/app/shared/models/event.model';
import { CommandType, SignalDataContent, SignalDataModel, SignalLevel } from 'src/app/shared/models/signalr.models';
import { EventService } from 'src/app/shared/services/event.service';
import { MessageService } from 'src/app/shared/services/message.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { UserModel, UserStatusEnum } from '../../../shared/models/user.model';
import { UserService } from '../../../shared/services/user.service';
import { ConferenceService } from './conference/conference.service';
import { MediaSettingsDialogComponent } from './media-settings/media-settings.component';
import { IMediaSettingsSerializable, MediaSettingsData } from './media-settings/media-settings.models';
import { PollDialogComponent } from './polls/polls.component';
import { EnumRoomType, RoomModel } from './room.models';
import { RoomService } from './room.service';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import { FwConfigService } from 'src/app/core/services/config.service';
import { LayoutConfig } from 'src/app/core/layoutConfig';
import { DOCUMENT } from '@angular/common';
import { CustomizationService } from '../../warroom/customization/customization.service';
import { FwUtils } from 'src/app/core/utils';
import { equals } from 'ramda';

@Component({
  selector: 'room-details',
  templateUrl: './room.component.html',
  styleUrls: ['./room.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: appAnimations
})
export class RoomComponent implements OnInit, OnDestroy, AfterViewInit {
  eventData: EventModel;
  schedules: EventScheduleModel[];
  roomData: RoomModel;
  roomClientConnected: boolean;
  dialogRef: any;
  mediaSettingData: MediaSettingsData;
  pollsRequestSent: boolean;
  pollDialogRef: MatDialogRef<PollDialogComponent>;

  hasAccess: boolean;
  hasActiveSchedule: boolean;

  roomStartCountdown = 0;
  roomCloseCountdown: number = 0;
  roomCountdownFormat = 'h\'h\':m\'m\':s\'s\'';
  breakoutRoomCloseCountdown: number = 0;
  currentUser: UserModel;
  preventRouterChangeOnParamMerge: boolean;

  layoutConfig: LayoutConfig;
  docElement: any;
  trademarkText: string;

  resourceBaseUrl: string;

  @ViewChild('joinButton', { read: ElementRef }) set content(content: ElementRef) {
    if (content) {
      this._checkForAutoJoin().then(res => { });
    }
  }

  @HostListener('window:beforeunload', ['$event'])
  confirmCloseIfRecording($event: any) {
    if (this.roomClientConnected) {
      $event.preventDefault();
      $event.returnValue = 'Your recording will be lost!';
      return 'Are you sure?';
    }
  }

  @ViewChild('btnfullscreen', { static: false }) btnfullscreen: ElementRef<any>;

  private _unsubscribeAll: Subject<any> = new Subject();

  constructor(
    private _appConfig: FwConfigService,
    private _route: ActivatedRoute,
    private _router: Router,
    private _settingService: AppSettingService,
    private _userService: UserService,
    private _eventService: EventService,
    private _roomService: RoomService,
    private _changeDetectorRef: ChangeDetectorRef,
    private _messageService: MessageService,
    private _conferenceService: ConferenceService,
    private _matDialog: MatDialog,
    private _sharedService: SharedService,
    private _guidedTourService: GuidedTourService,
    private _signalrService: SignalrService,
    private _customizationService: CustomizationService
  ) {
    this.resourceBaseUrl = this._settingService.settings.resourceBaseUrl;
    this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe(user => {
      this.currentUser = user;
    });
    this._route.paramMap.pipe(takeUntil(this._unsubscribeAll)).subscribe(async params => {
      this.reset();
    });
    this._sharedService.enableMoveToAnotherRoomWithoutConfirmation(false);

  }

  async ngOnInit(): Promise<void> {
    this.docElement = document.documentElement;
    await this._registerSignalrEvents();

    this._eventService.event$.pipe(takeUntil(this._unsubscribeAll)).subscribe({
      next: (ev) => {
        this.eventData = ev;
        this._changeDetectorRef.markForCheck();
      },
      error: (err) => {
        this._messageService.showErrorMessage(err);
      }
    });

    this._eventService.rooms$.pipe(takeUntil(this._unsubscribeAll)).subscribe(rooms => {
      const roomId = parseInt(this._route.snapshot.params.roomId);
      let boothId = 0;
      if (this._route.snapshot.params.boothId) {
        boothId = parseInt(this._route.snapshot.params.boothId);
      }
      const _private = this._route.snapshot.params.roomtype === 'private';
      const _breakout = this._route.snapshot.params.roomtype === 'breakout';
      if (!_private && !_breakout) {
        this._roomService.getRoomDetails(boothId > 0 ? boothId : roomId).pipe(takeUntil(this._unsubscribeAll)).subscribe();
      }
    });

    this._roomService.roomDetails$.pipe(takeUntil(this._unsubscribeAll)).subscribe({
      next: (room) => {

        this.roomData = room;
        this._setRoomStatus();

        const _private = this._route.snapshot.params.roomtype === EnumRoomType.private;
        const _breakout = this._route.snapshot.params.roomtype === EnumRoomType.breakout;
        if (this.roomData && !this.pollsRequestSent && !_private && !_breakout) {
          this.pollsRequestSent = true;
          this._roomService.getPolls(this.roomData.roomId).pipe(takeUntil(this._unsubscribeAll)).subscribe();
        }

        this._sharedService.setThemeColor(room.settings.boardBackgroundColor);
        this._changeDetectorRef.detectChanges();
      },
      error: (err) => {
        this._messageService.showErrorMessage(err);
      }
    });

    this._conferenceService.onRoomJoined$.pipe(takeUntil(this._unsubscribeAll)).subscribe(async res => {
      if (this.roomData && res) {
        this.roomClientConnected = true;
        this._changeDetectorRef.markForCheck();
        const signalDataModel = {
          receiverId: this.eventData.eventId,
          command: CommandType.userStatusChanged,
          signalLevel: SignalLevel.event,
          data: { status: UserStatusEnum.inacall, roomId: this.roomData.roomId } as SignalDataContent
        } as SignalDataModel;
        await this._signalrService.sendSignal(signalDataModel);
      }
    });

    this._conferenceService.onRoomLeft$.pipe(takeUntil(this._unsubscribeAll)).subscribe(async (s) => {
      if (s) {
        this.roomClientConnected = false;
        this._changeDetectorRef.markForCheck();
        const signalDataModel = {
          receiverId: this.eventData.eventId,
          command: CommandType.userStatusChanged,
          signalLevel: SignalLevel.event,
          data: { status: UserStatusEnum.online, roomId: this.roomData?.roomId } as SignalDataContent
        } as SignalDataModel;
        await this._signalrService.sendSignal(signalDataModel);
      }
    });

    this._eventService.schedules$.pipe(takeUntil(this._unsubscribeAll)).subscribe(s => {
      if (s) { this._setRoomStatus(); }
    });

    this._roomService.polls$.pipe(takeUntil(this._unsubscribeAll)).subscribe(async polls => {
      if (polls) {
        this.pollDialogRef?.close();

        if (this.currentUser.isSystemUser()) { return; }

        polls = polls.filter(p => p.roomId === this.roomData.roomId);

        if (!polls || !polls.length) { return; }

        const userRespondedPollIds = await this._roomService.getUserCompletedPollIds(this.roomData.roomId);
        polls = polls.filter(p => !userRespondedPollIds.includes(p.pollId));

        polls.forEach(poll => {
          const startDate = new Date(moment.utc(poll.startDateUtc).local().format());
          const currentDate = new Date();
          const differece = differenceInSeconds(startDate, currentDate);

          if (poll.displayNow) {
            this._openPollDialog(poll);
            return;
          }

          if (differece <= 0) {
            this._openPollDialog(poll);
            return;
          }

          if (differece > 0) {
            const duration = (startDate.valueOf() - currentDate.valueOf());
            setTimeout(() => this._openPollDialog(poll), duration);
          }
        });
      }
    });

    this._customizationService.customization$.pipe(takeUntil(this._unsubscribeAll))
      .subscribe(res => {
        if (res) {
          this.trademarkText = res.trademarkText;
        }
      });
  }

  async ngAfterViewInit(): Promise<void> {
    if (!this.currentUser.isSystemUser()) {
      await this._initMediaSettings();
    }

    this._route.queryParamMap.pipe(takeUntil(this._unsubscribeAll)).subscribe(s => {
      if (s.get('layout') == 'recorder' && this.currentUser.isSystemUser()) {
        this.enableRecorderLayout(this.layoutConfig);
        this.roomClientConnected = true;
        this._changeDetectorRef.detectChanges();
      }
    });

    // interval(4000)
    //   .pipe(takeUntil(this._unsubscribeAll))
    //   .subscribe(value => {
    //     let container = window.document.getElementById('reaction-bubbles');
    //     let uid = FwUtils.generateGUID();
    //     let like = `<div id="${uid}-like" class="reaction-like"></div>`;
    //     let wow = `<div id="${uid}-wow" class="reaction-wow"></div>`;
    //     container.insertAdjacentHTML('afterend', like);
    //     container.insertAdjacentHTML('afterend', wow);     
    //   });
  }

  private async _checkForAutoJoin(): Promise<void> {

    if (this.currentUser.isHostOrCoHost()) {
      return;
    }

   let redirected = await this._checkBreakoutRoomAndRedirect();
   if( redirected) {
    return;
   }

    const result = this._roomService.breakoutRoomActiveAndOpen(this.roomData);
    if (result && result.roomActiveAndOpen) {
      this._sharedService.enableAutoJoinRoom(false);
      this._setBreakoutRoomCloseCountdown();
      this.checkMediaSettingPopupAndJoin();
      return;
    }

    const enabled = this._sharedService.isAutoJoinRoomEnabled();
    if (enabled) {
      this._sharedService.enableAutoJoinRoom(false);
      this.checkMediaSettingPopupAndJoin();
    }
  }

  checkMediaSettingPopupAndJoin(): void {

    if (this.roomClientConnected) { return; }

    const mSettings = this._conferenceService.getMediaSetting();
    if (mSettings) {
      this.mediaSettingData = mSettings;
      this.roomClientConnected = true;
      this._changeDetectorRef.detectChanges();
      return;
    }

    this.dialogRef = this._matDialog.open(MediaSettingsDialogComponent, {
      panelClass: 'media-setting-dialog',
      data: new MediaSettingsData({} as MediaSettingsData)
    });

    this.dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe((settings: IMediaSettingsSerializable) => {
      if (settings) {
        this._conferenceService.updateMediaSettings(settings);
        this.roomClientConnected = true;
        this._changeDetectorRef.markForCheck();
      }
    });
  }

  startTour(useOrb: boolean): void {
    this._guidedTourService.activateOrb();
    const appTours = this._sharedService.isMobileLayout ? this._sharedService.getAppToursMobile(useOrb) : this._sharedService.getAppTours(useOrb);
    this._guidedTourService.startTour(appTours);
  }

  onRoomStartCountdownFinish(finish: boolean): void {
    if (finish) {
      this.roomStartCountdown = 0;
    }
  }

  async onRoomCloseCountdownFinish(finish: boolean): Promise<void> {
    if (finish) {
      this.roomCloseCountdown = 0;
      if (this.roomData.roomType === EnumRoomType.breakout) {
        this.breakoutRoomCloseCountdown = 0;
        const lobbyRoomId = await this._roomService.getLobbyRoomId();
        setTimeout(() => { this._onMoveToAnotherRoomByHost(lobbyRoomId); }, 1000);
      }
    }
  }

  private async _initMediaSettings(): Promise<void> {
    const dialogData = await this._checkMediaSettingData();
    if (!dialogData) { return; }
    this.mediaSettingData = dialogData;
    this._conferenceService.updateMediaSettings(this.mediaSettingData);
  }

  private async _checkMediaSettingData(): Promise<MediaSettingsData> {
    return new Promise((resolve, reject) => {
      const obj = this._sharedService.getDataFromLocalStorage(MediaSettingsData.localStorageSettingKey);
      if (equals(obj, {})) {
        const dialogRef = this._matDialog.open(MediaSettingsDialogComponent, {
          panelClass: 'media-setting-dialog',
          data: new MediaSettingsData({} as MediaSettingsData)
        });
        dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe((response: IMediaSettingsSerializable) => {
          if (response) {
            resolve(new MediaSettingsData(response));
          }
        });
        if (this.currentUser.isSystemUser()) {
          dialogRef.close(new MediaSettingsData({} as IMediaSettingsSerializable));
        }
      } else {
        resolve(new MediaSettingsData(obj));
      }
    });
  }

  private _setRoomStatus(): void {
    this.hasActiveSchedule = false;

    if (!this.roomData) {
      this.hasActiveSchedule = false;
      this._changeDetectorRef.markForCheck();
      return;
    }

    if (this.currentUser.isHostOrCoHost() || this.currentUser.isSystemUser()) {
      this.roomStartCountdown = 0;
      this.hasActiveSchedule = true;
      this._setBreakoutRoomCloseCountdown();
      this._changeDetectorRef.markForCheck();
      return;
    }

    const set = this._setBreakoutRoomCloseCountdown();
    if (set) {
      this._changeDetectorRef.markForCheck();
      return;
    }

    const schedules = this._eventService.getSchedulesFromObserver();
    const roomSchedules = schedules?.filter(s => s.roomId === this.roomData.roomId);
    if ((!roomSchedules || !roomSchedules.length)) {
      this.hasActiveSchedule = false;
      this._changeDetectorRef.markForCheck();
      return;
    }

    this._setRoomStartCountdown(roomSchedules);
    this._setRoomCloseCountdown(roomSchedules);

    this._changeDetectorRef.markForCheck();
  }

  private _setRoomStartCountdown(roomSchedules: EventScheduleModel[]): void {
    if (this.currentUser.isHostOrCoHost()) {
      this.roomStartCountdown = 0;
      this.hasActiveSchedule = true;
      return;
    }

    const currentDateTimestamp = Date.parse(moment.utc().format());

    const activeSchedule = roomSchedules?.find(s =>
      Date.parse(moment.utc(s.startDateUtc).format()) <= currentDateTimestamp &&
      Date.parse(moment.utc(s.endDateUtc).format()) > currentDateTimestamp);

    if (activeSchedule) {
      this.roomStartCountdown = 0;
      this.hasActiveSchedule = true;
      return;
    }

    const sortedRoomSchedules = roomSchedules
      .filter(r => Date.parse(moment.utc(r.startDateUtc).format()) > currentDateTimestamp)
      .sort((a: EventScheduleModel, b: EventScheduleModel) => {
        return new Date(a.startDateUtc).getTime() - new Date(b.startDateUtc).getTime()
      });

    if (sortedRoomSchedules && sortedRoomSchedules.length) {
      this.roomStartCountdown = 0;
      const upcomingSchedule = sortedRoomSchedules[0];
      [this.roomStartCountdown, this.roomCountdownFormat] = this._getScheduleCountDown(upcomingSchedule.startDateUtc);
    }
  }

  private _setRoomCloseCountdown(roomSchedules: EventScheduleModel[]): void {
    if (!roomSchedules || !roomSchedules.length) { return; }
    const currentDateTimestamp = Date.parse(moment.utc().format());
    const activeSchedule = roomSchedules?.find(s =>
      Date.parse(moment.utc(s.startDateUtc).format()) <= currentDateTimestamp &&
      Date.parse(moment.utc(s.endDateUtc).format()) > currentDateTimestamp);

    if (!activeSchedule) { return; }
    const endDateTimestamp = Date.parse(moment.utc(activeSchedule.endDateUtc).format());
    const difference = (endDateTimestamp - currentDateTimestamp);
    this.roomCountdownFormat = this._sharedService.getCountdownFormat(difference);
    this.roomCloseCountdown = parseInt((difference / 1000).toFixed(), 10);
  }

  private _setBreakoutRoomCloseCountdown(): boolean {
    if (this.roomData.roomType === EnumRoomType.breakout && this.roomData.isRoomOpen) {
      const result = this._roomService.breakoutRoomActiveAndOpen(this.roomData);
      if (result && result.roomActiveAndOpen) {
        this.roomCountdownFormat = this._sharedService.getCountdownFormat(result.remainingCountDown);
        this.breakoutRoomCloseCountdown = result.remainingCountDown;
        this._sharedService.roomCloseTimerStartBefore = this.roomData.roomCloseCountDownTime * 60;
        return true;
      }
    }
    return false;
  }

  private _getScheduleCountDown(scheduleDate: Date): [countdown: number, format: string] {
    let countdown = 0
    let format = 'm\'m\':s\'s\''
    const startDateTimestamp = Date.parse(moment.utc(scheduleDate).format())
    const currentDateTimestamp = Date.parse(moment.utc().format())
    if (startDateTimestamp > currentDateTimestamp) {
      if (startDateTimestamp > currentDateTimestamp) {
        const difference = (startDateTimestamp - currentDateTimestamp)
        countdown = parseInt((difference / 1000).toFixed(), 10)
        format = this._sharedService.getCountdownFormat(difference)
      }
    }
    return [countdown, format]
  }

  private async _registerSignalrEvents(): Promise<void> {
    this._signalrService.onNewSignal$.pipe(takeUntil(this._unsubscribeAll)).subscribe(async (res: SignalDataModel) => {
      if (res && (res.receiverId === this.currentUser.userId || res.receiverIds?.includes(this.currentUser.userId))) {
        if (res.command === CommandType.moveToAnotherRoom) {
          if (this.roomData.roomId !== res.data.roomId) {
            await this._onMoveToAnotherRoomByHost(res.data.roomId);
          }
        } else if (res.command === CommandType.memberRoleChange) {
          this.currentUser.userRoles = res.data.userRoles;
          this._setRoomStatus();
        } else if (res.command === CommandType.openBreakoutRooms) {
          if (!this.currentUser.isHostOrCoHost()) {
            this._moveToBreakoutRoom(res.data.roomId, res.data.roomName);
          }
        } else if (res.command === CommandType.closeBreakoutRooms) {
          if (this.roomData.roomId === res.data.roomId && !this.currentUser.isHostOrCoHost()) {
            const lobbyRoomId = await this._roomService.getLobbyRoomId();
            // Wait a/c to timer configuration
            const remainingCountdown = this.roomData.roomCloseCountDownTime * 60;
            this.breakoutRoomCloseCountdown = remainingCountdown;
            this._changeDetectorRef.markForCheck();
            setTimeout(() => {
              this._onMoveToAnotherRoomByHost(lobbyRoomId);
            }, remainingCountdown * 1000);
          }
        } else if (res.command === CommandType.deleteBreakoutRooms) {
          if (this.roomData.roomId === res.data.roomId) {
            // Even host or cohost should also be moved to lobby as the room was deleted
            const lobbyRoomId = await this._roomService.getLobbyRoomId();
            this._onMoveToAnotherRoomByHost(lobbyRoomId);
          }
        }
      }

      if (res && res.command === CommandType.messageToBreakoutRooms &&
        this.roomData.roomType === 'breakout' && res.receiverId === this.roomData.roomId) {
        this._messageService.showSuccessMessage(res.data.extra, false);
      }

      if (res.command === CommandType.breakoutRoomsUpdated) {
        if (this.roomData.roomType === 'breakout') {
          this._roomService.getRoomDetails(this.roomData.roomId, false, true).pipe(takeUntil(this._unsubscribeAll)).subscribe();
        }
      }

      if (res && res.command === CommandType.messageToRooms &&
        res.receiverIds?.includes(this.roomData.roomId)) {
        this._messageService.showBroadcastMessageNotification(res.data.extra.message, true, res.data.extra.seconds);
      }
    });

    this._signalrService.onBackendUpdated$
      .pipe(takeUntil(this._unsubscribeAll)).subscribe(signal => {
        if (signal) {
          if (signal.command === CommandType.pollsDataUpdated) {
            this._roomService.getPolls(this.roomData.roomId).pipe(takeUntil(this._unsubscribeAll)).subscribe();
          } else if (signal.command === CommandType.pushPollResult && signal.data.roomId === this.roomData.roomId) {
            this._roomService.getPollDetail(signal.data.pollId).then((res) => {
              if (res) {
                res.pushResult = true;
                this._openPollDialog(res);
              }
            }, () => { });
          }
        }
      });

    this._appConfig.config
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((config: LayoutConfig) => {
        this.layoutConfig = config;
        this._changeDetectorRef.markForCheck();
      });
  }

  private async _goToRoom(roomId: number): Promise<void> {
    const id = this._route.snapshot.paramMap.get('id');
    const t = this._route.snapshot.paramMap.get('t');
    const url = await this._roomService.getJoinRoomUrl(roomId);
    const fullUrl = `/fireworks/${id}/${t}/${url}`;
    this._router.navigate([fullUrl]);
  }

  private _moveToBreakoutRoom(targetRoomId: number, roomName: string): void {
    if (this.roomData.roomId !== targetRoomId) {
      this._sharedService.enableMoveToAnotherRoomWithoutConfirmation(true);
      this.roomClientConnected = false;
      this._changeDetectorRef.detectChanges();
      roomName = roomName.replace(/ /g, '-').toLowerCase();
      const eId = this._route.snapshot.paramMap.get('id');
      const token = this._route.snapshot.paramMap.get('t');
      const url = `fireworks/${eId}/${token}/b/breakout/${targetRoomId}/${roomName}`;
      this._router.navigate([url], { replaceUrl: false });
      this._matDialog.closeAll();
    }
  }

  private async _checkBreakoutRoomAndRedirect(): Promise<boolean> {
    if (this.currentUser.isHostOrCoHost()) {
      return false;
    }
    const breakoutRoom = await this._roomService.checkAndGetUserBreakoutRoom();
    if (breakoutRoom && this.roomData.roomType !== EnumRoomType.breakout) {
      const result = this._roomService.breakoutRoomActiveAndOpen(breakoutRoom);
      if (result && result.roomActiveAndOpen) {
        this._moveToBreakoutRoom(breakoutRoom.roomId, breakoutRoom.roomName);
        return true;
      }
    }

    return false;
  }

  ngOnDestroy(): void {
    this.roomStartCountdown = 0;
    this.roomCloseCountdown = 0;
    this.roomClientConnected = false;
    this._conferenceService.removeConfereceMembers();
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  transform(value: number): string {
    const secnum = value;
    const hours = Math.floor(secnum / 3600);
    const minutes = Math.floor((secnum - (hours * 3600)) / 60);
    const seconds = secnum - (hours * 3600) - (minutes * 60);
    return this.pad(hours) + ':' + this.pad(minutes) + ':' + this.pad(seconds);
  }

  pad(n: number): any {
    return (n < 10) ? ('0' + n) : n;
  }

  reset(): void {
    this.roomStartCountdown = 0;
    this.roomCloseCountdown = 0;
    this.roomClientConnected = false;
    this._conferenceService.removeConfereceMembers();
    //this._conferenceService.notifyRoomLeft(); //TODO FIX
    //The above code need to be enabled, but when we enable it its creating issue in mobile view, the bottom control not showing
    this._changeDetectorRef.markForCheck();
  }

  private async _onMoveToAnotherRoomByHost(targetRoomId: number): Promise<void> {
    this._sharedService.enableMoveToAnotherRoomWithoutConfirmation(true);
    this.roomClientConnected = false;
    this._changeDetectorRef.detectChanges();
    await this._goToRoom(targetRoomId);
  }

  private _openPollDialog(poll: EventPollModel): void {
    this.pollDialogRef = this._matDialog.open(PollDialogComponent, {
      width: '450px',
      data: poll,
      hasBackdrop: false,
      disableClose: poll.isRequired
    });
  }

  private enableRecorderLayout(config: LayoutConfig): void {
    config.layout.sidepanel.hidden = true;
    config.layout.navbar.hidden = true;
    config.layout.footer.hidden = true;
    //config.layout.toolbar.hidden = true;    
    this._sharedService.enableAutoJoinRoom(true);
  }
}
