import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { SharedService } from 'src/app/shared/services/shared.service';

@Component({
  selector: 'room-countdown',
  templateUrl: './countdown.component.html',
  styleUrls: ['./countdown.component.scss']
})
export class RoomCountdownComponent implements OnInit {
  @Input() roomCountdown: number = 0;
  @Input() countdownFormat = 'h\'h\':m\'m\':s\'s\'';
  @Output() onRoomCountdownFinish: EventEmitter<any> = new EventEmitter<any>();
  @Input() type: 'start' | 'end';

  showTimer: boolean = false;

  constructor(private _sharedService: SharedService) { }

  ngOnInit(): void {
  }

  makeTextToHtml(text: string) {
    const timesArray = text.split(':');
    let timerHTML = ''; let timeElement = '';
    timesArray.forEach(el => {
      timeElement = el.replace(/[^\d.-]/g, '');
      timerHTML += '<strong class="timeCount">' + timeElement + '</strong>';
      if (el.indexOf('d') !== -1) {
        timerHTML += '<span class="timeValIn">d</span>';
      } else if (el.indexOf('h') !== -1) {
        timerHTML += '<span class="timeValIn">h</span>';
      } else if (el.indexOf('m') !== -1) {
        timerHTML += '<span class="timeValIn">m</span>';
      } else {
        timerHTML += '<span class="timeValIn">s</span>';
      }
    })
    return timerHTML;
  }

  onCountdownFinish(data: any): void {
    if (data.action === 'done') {
      this.onRoomCountdownFinish.emit(true);
    } else if (data.action === 'notify') {
      const timeleft = (data.left / 1000);
      if (timeleft <= this._sharedService.roomCloseTimerStartBefore) { // show timer after 90 sec left
        this.showTimer = true;
      }
    }
  }

  hideTimer(): void {
    this.showTimer = false;
  }
}
