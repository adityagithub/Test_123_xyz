
import { Component, Inject, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import * as moment from 'moment';
import { interval, Subject, Subscription, takeUntil } from 'rxjs';
import { appAnimations } from 'src/app/core/animations';
import { UserModel } from 'src/app/shared/models/user.model';
import { UserService } from 'src/app/shared/services/user.service';
import { EventPollModel, PollUserAnswer } from 'src/app/shared/models/event.model';
import { RoomService } from '../room.service';

@Component({
  selector: 'fireworks-polls',
  templateUrl: './polls.component.html',
  styleUrls: ['./polls.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: appAnimations
})
export class PollDialogComponent implements OnInit, OnDestroy {
  private _unsubscribeAll: Subject<any> = new Subject();
  currentUser: UserModel;
  pollData: EventPollModel;
  pollAnswerSaveResponse: any;
  selectedAnswerId: number;
  expiryCountDown: number;
  expiryCountDownFormat: string;

  constructor(
    public dialogRef: MatDialogRef<PollDialogComponent>,
    @Inject(MAT_DIALOG_DATA) pollData: EventPollModel,
    private _userService: UserService,
    private _roomService: RoomService) {
    this.pollData = pollData;
  }

  private subscription: Subscription;
  public dateNow = new Date();

  public timeDifference: number;
  public secondsRemaining: number;
  public minutesRemaining: number;
  public hoursRemaining: number;
  public daysRemaining: number;

  async ngOnInit(): Promise<void> {
    this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe(user => {
      this.currentUser = user;
    });

    if (this.pollData) {
      if (this.pollData.pushResult) {
        this.pollAnswerSaveResponse = await this._roomService.getPollSummary(this.pollData.pollId);
        return;
      }

      this.subscription = interval(1000)
        .subscribe(x => {
          const expiryDate = new Date(moment.utc(this.pollData.expiryDateUtc).local().format());
          const currentDate = new Date();
          if (expiryDate < currentDate) {
            if (this.pollData.isRequired) {
              this.subscription.unsubscribe();
            } else {
              if (this.pollAnswerSaveResponse) {
                this.subscription.unsubscribe();
              } else {
                this.dialogClose();
              }
            }
          } else {
            // Show Countdown
          }
        });

      if (this.pollData.displayTimeRemaining) {
        [this.expiryCountDown, this.expiryCountDownFormat] = this._getPollCountDown(this.pollData.expiryDateUtc);
      }
    }
  }

  ngOnDestroy() {
    if (!this.pollData) {
      this.subscription.unsubscribe();
    }
  }

  submitPollAnswer(): any {
    const userAnswer = {
      pollId: this.pollData.pollId,
      roomId: this._roomService.currentRoomId,
      updatedDateUtc: this.pollData.updatedDateUtc,
      userAnswerId: this.selectedAnswerId
    } as PollUserAnswer;
    this._roomService.savePollResponse(userAnswer).subscribe({
      next: async (res) => {
        if (this.pollData.displayResultToAttendees) {
          this.pollAnswerSaveResponse = await this._roomService.getPollSummary(this.pollData.pollId);
        } else {
          this.dialogClose();
        }
      },
      error: () => { this.dialogClose(); }
    });
  }

  dialogClose(): void {
    this.dialogRef.close();
  }

  private _getPollCountDown(expiryDateUtc: Date): [countdown: number, format: string] {
    let countdown = 0
    let format = 'm\'m\':s\'s\''
    const expiryDateTimestamp = Date.parse(moment.utc(expiryDateUtc).format())
    const currentDateTimestamp = Date.parse(moment.utc().format())
    if (expiryDateTimestamp > currentDateTimestamp) {
      if (expiryDateTimestamp > currentDateTimestamp) {
        const difference = (expiryDateTimestamp - currentDateTimestamp)
        countdown = parseInt((difference / 1000).toFixed(), 10)
        format = this.getCountdownFormat(difference)
      }
    }
    return [countdown, format]
  }

  onCountdownFinish(data: any): void {
    if (data) {
      // TODO
    }
  }

  getCountdownFormat(difference: number): string {
    if (difference > (24 * 60 * 60 * 1000)) { // Greater than a day
      return 'd\' day(s) and \'h\'h\':m\'m\':s\'s\''
    } else if (difference > (60 * 60 * 1000)) { // Greater than an hour
      return 'h\'h\':m\'m\':s\'s\''
    } else if (difference > 60 * 1000) { // Greater than a minute
      return 'm\'m\':s\'s\''
    }
    return 'm\'m\':s\'s\''
  }
}
