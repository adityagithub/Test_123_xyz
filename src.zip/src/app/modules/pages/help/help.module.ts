import { NgModule } from '@angular/core';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { HelpComponent } from './help.component';
import { MaterialModule } from 'src/app/core/material.module';
import { FwSidebarModule } from 'src/app/core/components';

@NgModule({
  declarations: [
    HelpComponent
  ],
  imports: [
    MaterialModule,
    FwCoreModule,
    FwSidebarModule
  ]
})
export class HelpModule {
}
