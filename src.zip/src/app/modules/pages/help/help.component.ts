import { AfterViewInit, ChangeDetectorRef, Component, OnDestroy, OnInit, QueryList, ViewChildren, ViewEncapsulation } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { FwSidebarService } from 'src/app/core/components/sidebar/sidebar.service';
import { FwPerfectScrollbarDirective } from 'src/app/core/directives/fw-perfect-scrollbar/fw-perfect-scrollbar.directive';

@Component({
  selector: 'fw-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class HelpComponent implements OnInit, OnDestroy, AfterViewInit {
  animationDirection: 'left' | 'right' | 'none';
  course: any;
  courseStepContent: any;
  currentStep: number;

  @ViewChildren(FwPerfectScrollbarDirective)
  fwScrollbarDirectives: QueryList<FwPerfectScrollbarDirective>;

  private _unsubscribeAll: Subject<any>;


  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _fwSidebarService: FwSidebarService
  ) {
    this.animationDirection = 'none';
    this.currentStep = 0;
    this._unsubscribeAll = new Subject();
  }

  ngOnInit(): void {
    this.course = {
      'id': '15459251a6d6b397565',
      'title': 'Basics of Angular',
      'slug': 'basics-of-angular',
      'description': 'Commits that need to be pushed lorem ipsum dolor sit amet.',
      'category': 'web',
      'length': 30,
      'totalSteps': 5,
      'updated': 'Jun 28, 2017',
      'steps': AcademyFakeDb.demoSteps
    };
  }

  ngAfterViewInit(): void {
    this.courseStepContent = this.fwScrollbarDirectives.find((fwScrollbarDirective) => {
      return fwScrollbarDirective.elementRef.nativeElement.id === 'course-step-content';
    });
  }


  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }


  gotoStep(step): void {
    // Decide the animation direction
    this.animationDirection = this.currentStep < step ? 'left' : 'right';

    // Run change detection so the change
    // in the animation direction registered
    this._changeDetectorRef.detectChanges();

    // Set the current step
    this.currentStep = step;
  }


  gotoNextStep(): void {
    if (this.currentStep === this.course.totalSteps - 1) {
      return;
    }

    // Set the animation direction
    this.animationDirection = 'left';

    // Run change detection so the change
    // in the animation direction registered
    this._changeDetectorRef.detectChanges();

    // Increase the current step
    this.currentStep++;
  }


  gotoPreviousStep(): void {
    if (this.currentStep === 0) {
      return;
    }

    this.animationDirection = 'right';

    // Run change detection so the change
    // in the animation direction registered
    this._changeDetectorRef.detectChanges();

    // Decrease the current step
    this.currentStep--;
  }


  toggleSidebar(name): void {
    this._fwSidebarService.getSidebar(name).toggleOpen();
  }
}


export class AcademyFakeDb {

   static demoSteps = [
    {
      'title': 'Introduction',
      'content': '<h1>Introduction</h1>' +
        '<br>' +
        'This is an example. Todo.'
    },
    {
      'title': 'Welcome New Users',
      'content': '<h1>Welcome New Users</h1>' 
    },
    {
      'title': 'New Message Notifications',
      'content': '<h1>New Message Notifications</h1>' 
    },
    {
      'title': 'Congratulations!',
      'content': '<h1>Congratulations Message!</h1>'
    }
  ];
}