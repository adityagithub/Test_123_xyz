import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { Error404Component } from '../../errors/404/error-404.component';

@NgModule({
  declarations: [
    Error404Component
  ],
  imports: [
    RouterModule.forChild([{
      path: '',
      component: Error404Component
    }]),
    MatIconModule,
    FwCoreModule
  ]
})
export class Error404Module {
}
