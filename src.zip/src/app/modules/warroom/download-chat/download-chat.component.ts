
import {
  ChangeDetectorRef,
  Component,
  Input, OnDestroy, OnInit,
  Output,
  ViewChild,
  ViewEncapsulation
} from '@angular/core';
import { MatMenuTrigger } from '@angular/material/menu';
import { NgxSpinnerService } from 'ngx-spinner';
import { Subject, takeUntil } from 'rxjs';
import { EventModel, RoomNavigationModel } from 'src/app/shared/models/event.model';
import { EventService } from 'src/app/shared/services/event.service';
import { MessageService } from 'src/app/shared/services/message.service';
import { EnumRoomType } from '../../rooms/room/room.models';
import { DownloadChatService } from './download-chat.service';
import { UserService } from '../../../shared/services/user.service';
import { UserModel } from '../../../shared/models/user.model';

@Component({
  selector: 'fw-download-chat',
  templateUrl: './download-chat.component.html',
  styleUrls: ['./download-chat.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class DownloadChatComponent implements OnInit, OnDestroy {
  private _unsubscribeAll: Subject<any> = new Subject();

  eventData: EventModel;
  user: UserModel;
  roomType = EnumRoomType;
  rooms: RoomNavigationModel[] = [];
  selectedRoomIds: number[] = [];
  radioEventOrRoom: 'event' | 'room' = 'event';
  panelOpenState: boolean = true;
  @Input() inline: boolean = false;
  @ViewChild(MatMenuTrigger) trigger: MatMenuTrigger;
  isDownloadChatDisabled: boolean;
  targetIconActive: boolean = false;

  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _messageService: MessageService,
    private _userService: UserService,
    private _eventService: EventService,
    private _downloadChatService: DownloadChatService,
    private _spinnerService: NgxSpinnerService
  ) {

  }

  ngOnInit(): void {

    this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe(user => {
      this.user = user;
      this.isDownloadChatDisabled = !this.eventData?.settings?.downloadChatsForAttendeeEnabled;
      if (this.user?.isHostOrCoHost()) {
        this.isDownloadChatDisabled = false;
      }
      this._changeDetectorRef.markForCheck();
    });

    this._eventService.event$.pipe(takeUntil(this._unsubscribeAll)).subscribe({
      next: (ev) => {
        this.eventData = ev;
        this.isDownloadChatDisabled = !this.eventData?.settings?.downloadChatsForAttendeeEnabled;
        if (this.user?.isHostOrCoHost()) {
          this.isDownloadChatDisabled = false;
        }
      },
      error: (err) => {
        this._messageService.showErrorMessage(err);
      }
    });

    this._eventService.navigations$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((data) => {
        this.rooms = this.prepareDropdownNavigations(data);
      });
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  prepareDropdownNavigations(data: RoomNavigationModel[]): RoomNavigationModel[] {
    const mainRooms = data.filter(x => x.roomType !== 'customroom');
    const customRooms = data.filter(x => x.roomType === 'customroom');
    const customRoomRoot = {
      roomId: 999,
      roomName: 'Custom Rooms',
      roomType: 'customroom',
      children: customRooms,
      displayOrder: null,
      isEnabled: true
    } as RoomNavigationModel;
    mainRooms.push(customRoomRoot);
    return mainRooms;
  }

  onRoomSelectionChange($event: any) {
    console.log(this.selectedRoomIds, 'selected room ids');
    if (this.selectedRoomIds.length == 0) {
      return;
    }
  }

  exportChats(event: any, format: 'pdf' | 'csv' | 'txt') {
    try {
      event.preventDefault();
      this._spinnerService.show('spinner-chat-download');
      let roomIds = [];
      let fileName = `${this.eventData.eventTitle}${this.radioEventOrRoom == 'room' ? '-rooms-' : '-'}chats.${format}`;
      if (this.radioEventOrRoom == 'room') {
        roomIds = this.selectedRoomIds;
      }
      this._downloadChatService.getChatData(this.radioEventOrRoom, roomIds)
        .pipe(takeUntil(this._unsubscribeAll))
        .subscribe({
          next: (rows) => {
            if (format == 'pdf') {
              this._downloadChatService.exportChatsToPdf(fileName, rows);
            } else {
              this._downloadChatService.exportChatsToCsv(fileName, rows);
            }
            this._spinnerService.hide('spinner-chat-download');
          },
          error: (e) => {
            this._spinnerService.hide('spinner-chat-download');
          }
        });
    } catch (e) {
      this._spinnerService.hide('spinner-chat-download');
    }
  }

  panelOpened(): void {
    this.targetIconActive = true;
  }

  panelClosed(): void {
    this.trigger.closeMenu();
    this.targetIconActive = false;
  }

}
