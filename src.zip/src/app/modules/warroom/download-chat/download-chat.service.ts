import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { ApiResponse } from 'src/app/shared/models/shared.model';
import { map } from 'rxjs/operators';
import * as moment from 'moment';
import { ScriptInjectorService } from 'src/app/shared/services/script.service';

@Injectable()
export class DownloadChatService {

    constructor(
        private _httpClient: HttpClient,
        private _scriptService: ScriptInjectorService) {
    }

    getChatData(section: string, roomIds: number[] = null, senderId: number = null) {
        let params = new HttpParams();
        params = params.append('section', section);
        if (roomIds) {
            roomIds.forEach((roomId: number) => {
                params = params.append(`roomIds`, roomId);
            })
        }
        if (senderId) {
            params = params.append('senderId', senderId);
        }
        return this._httpClient.get<ApiResponse<ChatDownloadResponse[]>>('api/chat/download-chats', { params: params })
            .pipe(map((response: ApiResponse<ChatDownloadResponse[]>) => {
                return response.data;
            }));
    }

    exportChatsToPdf(filename: string, chats: ChatDownloadResponse[]) {
        this._scriptService.loadJS('jspdf').then(res => {
            //@ts-ignore
            const { jsPDF } = window.jspdf;
            const doc = new jsPDF();
            chats.map((chat, i) => {
                if (i > 0 && doc.lastAutoTable) {
                    doc.text(chat.title, 14, doc.lastAutoTable.finalY + 10);
                } else {
                    doc.text(chat.title, 14, 16);
                }
                this.generatePDF(doc, chat.chatItems);
            })
            doc.save(filename);
        }).catch(error => console.log(error));
    }

    exportChatsToCsv(filename: string, chats: ChatDownloadResponse[]) {
        const objectToCsv = (chats: ChatDownloadResponse[]) => {
            const csvRows = [];
            return chats.map(data => {
                csvRows.push(data.title);
                /* Get headers as every csv data format
                has header (head means column name)
                so objects key is nothing but column name
                for csv data using Object.key() function.
                We fetch key of object as column name for
                csv */

                if (!data.chatItems.length) {
                    return;
                }

                const headers = Object.keys(data.chatItems[0]);

                /* Using push() method we push fetched
                   data into csvRows[] array */
                csvRows.push(headers.join(','));

                // Loop to get value of each objects key
                for (const row of data.chatItems) {
                    const values = headers.map(header => {
                        const val = row[header]
                        if (header == 'date') {
                            var stillUtc = moment.utc(val).toDate();
                            var local = moment(stillUtc).local().format('lll');
                            return local;
                        }
                        return `"${val}"`;
                    });

                    // To add, separator between each value
                    csvRows.push(values.join(','));
                }

                /* To add new line for each objects values
                   and this return statement array csvRows
                   to this function.*/
                return csvRows.join('\n');
            });
        };

        let csvFile = objectToCsv(chats);

        var blob = new Blob(csvFile, { type: 'text/csv;charset=utf-8;' });
        //@ts-ignore
        if (navigator.msSaveBlob) { // IE 10+
            //@ts-ignore
            navigator.msSaveBlob(blob, filename);
        } else {
            var link = document.createElement("a");
            if (link.download !== undefined) {
                var url = URL.createObjectURL(blob);
                link.setAttribute("href", url);
                link.setAttribute("download", filename);
                link.style.visibility = 'hidden';
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        }
    }

    generatePDF = (doc: any, rows: ChatDownloadItem[]) => {

        

        const mappedData = [];
        rows.forEach(r => {
            var stillUtc = moment.utc(r.date).toDate();
            var local = moment(stillUtc).local().format('lll');
            let nm = r.name + '\n' + local;

            if(r.type == 'emoji'){
                //@ts-ignore
                var encodedStr = Base64.encode(r.message);
                var imgData = 'data:image/jpeg;base64,'+ encodedStr;
                doc.setFontSize(40);
                doc.addImage(imgData, 'JPEG', 15, 40, 180, 160);
            }

            mappedData.push([nm, r.message]);
        });

        const margin = {
            left: 15,
            right: 15,
            top: 20,
            bottom: 20,
        };

        // space between each section
        const spacing = 5;

        const printWidht = doc.internal.pageSize.width - (margin.left + margin.right);

        let nextSection = 1;

        doc.autoTable({
            theme: 'grid',
            head: [['Name', 'Message']],
            body: mappedData,
            tableWidth: printWidht,
            columnStyles: {
                0: { cellWidth: 50 }
            },
            margin: {
                left: margin.left + ((nextSection - 1) * (printWidht + spacing)),
                top: margin.top,
                bottom: margin.bottom,
            },
            startY: (doc.lastAutoTable.finalY ?? 5) + 15,
            rowPageBreak: 'avoid', // avoid breaking rows into multiple sections
            didDrawPage({ table, pageNumber, pageCount }) {

                nextSection = (nextSection % 1) + 1;

                table.settings.margin.left = margin.left;

                // if next section is not the fist, move to previous page so when
                // autoTable calls addPage() it will still be the same current page
                if (nextSection > 1) {
                    doc.setPage(doc.internal.getNumberOfPages() - 1);
                }
            }
        });

        doc.setPage(doc.internal.getNumberOfPages());
        return doc;
    }
}

export interface ChatDownloadResponse {
    title: string;
    description: string;
    chatItems: ChatDownloadItem[];
}

export interface ChatDownloadItem {
    name: string;
    message: string;
    date: Date;
    type: string;
}