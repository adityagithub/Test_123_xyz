import { NgModule } from '@angular/core';
import { NgxSpinnerModule } from 'ngx-spinner';
import { MaterialModule } from 'src/app/core/material.module';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { DownloadChatComponent } from './download-chat.component';
import { DownloadChatService } from './download-chat.service';

@NgModule({
  declarations: [
    DownloadChatComponent
  ],
  imports: [
    MaterialModule,
    FwCoreModule,
    NgxSpinnerModule
  ],
  exports:[DownloadChatComponent],
  providers: [
    DownloadChatService
  ]
})
export class DownloadChatModule {
}
