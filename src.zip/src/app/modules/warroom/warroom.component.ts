
import { ChangeDetectorRef, Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { Subject, takeUntil } from 'rxjs';
import { appAnimations } from 'src/app/core/animations';
import { RoomService } from '../rooms/room/room.service';
import { WarroomService } from './warroom.service';
import { EventService } from 'src/app/shared/services/event.service';
import { FwSidebarService } from 'src/app/core/components/sidebar/sidebar.service';
import { MessageService } from 'src/app/shared/services/message.service';
import { EventModel, RoomNavigationModel } from 'src/app/shared/models/event.model';
import { ManageAttendeeComponent } from './manage-attendees/manage-attendees.component';
import { BreakoutRoomComponent } from './breakout/breakout.component';
import { BroadcastMessageComponent } from './broadcast-message/broadcast-message.component';
import { EnumRoomType } from '../rooms/room/room.models';
import { SharedService } from 'src/app/shared/services/shared.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { CommonModule } from '@angular/common';
import { WarroomModule } from './warroom.module';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { CommandType } from 'src/app/shared/models/signalr.models';
import { UserModel } from '../../shared/models/user.model';
import { UserService } from '../../shared/services/user.service';
import { CustomizationComponent } from './customization/customization.component';
import { FwRecordingListComponent } from './recordings/recording-list/recording-list.component';

@Component({
  selector: 'fireworks-warroom',
  templateUrl: './warroom.component.html',
  styleUrls: ['./warroom.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: appAnimations
})
export class WarroomComponent implements OnInit, OnDestroy {
  private _unsubscribeAll: Subject<any> = new Subject();

  eventData: EventModel;
  currentUser: UserModel;
  roomType = EnumRoomType;
  rooms: RoomNavigationModel[] = [];
  selectedRoomIds: number[] = [];
  radioEventOrRoom: 'event' | 'room' = 'event';
  panelOpenState: boolean = true;
  openInDialog: boolean;


  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _matDialog: MatDialog,
    private _userService: UserService,
    private _messageService: MessageService,
    private _warroomService: WarroomService,
    private _eventService: EventService,
    private _roomService: RoomService,
    private _sidebarService: FwSidebarService,
    private _sharedService: SharedService,
    private _spinnerService: NgxSpinnerService
  ) {

  }

  ngOnInit(): void {

    if (!this.openInDialog) {
      this._roomService.getRoomDetails(0).pipe(takeUntil(this._unsubscribeAll)).subscribe();
    }

    this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe(u => {
      this.currentUser = new UserModel(u);
    });

    this._eventService.event$.pipe(takeUntil(this._unsubscribeAll)).subscribe({
      next: (ev) => {
        this.eventData = ev;
      },
      error: (err) => {
        this._messageService.showErrorMessage(err);
      }
    });

    this._eventService.navigations$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((data) => {
        this.rooms = this.prepareDropdownNavigations(data);
      });
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  toggleSidebar(dataType: string): void {
    this._sidebarService.getSidebar('warRoomSidenav').toggleOpen();
    this._warroomService.setSidePanelView(dataType, this.eventData);
  }

  openManageAttendeesDialog(): void {
    this._matDialog.open(ManageAttendeeComponent, {
      panelClass: 'manage-attendees-dialog',
      data: {},
      hasBackdrop: true
    });
  }

  openBreakoutRoomDialog(): void {
    this._matDialog.open(BreakoutRoomComponent, {
      panelClass: 'breakout-room-dialog',
      data: {},
      hasBackdrop: true
    });
  }

  openBroadcastMessageDialog(): void {
    this._matDialog.open(BroadcastMessageComponent, {
      panelClass: 'broadcast-message-dialog',
      data: {},
      hasBackdrop: true
    });
  }

  prepareDropdownNavigations(data: RoomNavigationModel[]): RoomNavigationModel[] {
    const mainRooms = data.filter(x => x.roomType !== 'customroom');
    const customRooms = data.filter(x => x.roomType === 'customroom');
    const customRoomRoot = {
      roomId: 999,
      roomName: 'Custom Rooms',
      roomType: 'customroom',
      children: customRooms,
      displayOrder: null,
      isEnabled: true
    } as RoomNavigationModel;
    mainRooms.push(customRoomRoot);
    return mainRooms;
  }

  openCustomizationDialog(): void {
    let dialogRef = this._matDialog.open(CustomizationComponent, {
      panelClass: 'customization-dialog',
      data: {},
      disableClose: true,
    });
    dialogRef.componentInstance.openInDialog = true;
  }

  openRecordingListDialog(): void {
    let dialogRef = this._matDialog.open(FwRecordingListComponent, {
      panelClass: 'recprding-list-dialog',
      data: {},
      disableClose: true,
    });
    dialogRef.componentInstance.openInDialog = true;
  }
}