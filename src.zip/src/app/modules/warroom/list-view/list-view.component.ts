import { AfterViewInit, ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { appAnimations } from 'src/app/core/animations';
import { EventService } from 'src/app/shared/services/event.service';
import { MatDialog } from '@angular/material/dialog';
import { FwSidebarService } from 'src/app/core/components/sidebar/sidebar.service';
import { RoomModel, RoomType, EnumRoomType } from '../../rooms/room/room.models';
import { RoomService } from '../../rooms/room/room.service';
import { WarroomService } from '../warroom.service';
import { FwSidebarComponent } from 'src/app/core/components/sidebar/sidebar.component';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { UserService } from '../../../shared/services/user.service';
import { UserModel, UserStatusEnum } from '../../../shared/models/user.model';
import { MessageService } from 'src/app/shared/services/message.service';
import { CommandType, SignalDataContent } from 'src/app/shared/models/signalr.models';
import { EnumScheduleStatus, EventModel } from 'src/app/shared/models/event.model';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import * as moment from 'moment';
import { CustomizationService } from '../customization/customization.service';

@Component({
  selector: 'list-view',
  templateUrl: './list-view.component.html',
  styleUrls: ['./list-view.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: appAnimations
})
export class ListViewComponent implements OnInit, OnDestroy, AfterViewInit {

  eventData: EventModel;
  currentUser: UserModel;
  rooms: RoomModel[];
  simpleRooms: RoomModel[];
  multiBoothRooms: RoomModel[];

  filteredSimpleRooms: RoomModel[];
  filteredMultiBoothRooms: RoomModel[];
  activeEditorRoomId: number;
  resourceBaseUrl: string;
  defaultRoomBackgroundUrl: string;
  @Input() openInDialog: boolean

  categories: any[] = [
    { name: 'All Rooms', systemName: 'all' },
    { name: 'Custom Rooms', systemName: 'customroom' },
    { name: 'Sessions', systemName: 'session' },
    { name: 'Expo', systemName: 'expo' },
    { name: 'Networking', systemName: 'networking' },
    { name: 'Breakout Rooms', systemName: 'breakout' },
    { name: 'Private Rooms', systemName: 'private' }
  ];

  currentRoomCategory: string;
  searchTerm: string;
  sidebarInstance: FwSidebarComponent;
  attendees: UserModel[];
  onlineAttendees: SignalDataContent[];

  private _unsubscribeAll: Subject<any> = new Subject();

  constructor(
    private _matDialog: MatDialog,
    private _changeDetectorRef: ChangeDetectorRef,
    private _userService: UserService,
    private _warRoomService: WarroomService,
    private _eventService: EventService,
    private _roomService: RoomService,
    private _sidebarService: FwSidebarService,
    private _signalrService: SignalrService,
    private _messageService: MessageService,
    private _settingService: AppSettingService,
    private _customizationService: CustomizationService
  ) {
    this.currentRoomCategory = 'all';
    this.searchTerm = '';
    this.resourceBaseUrl = this._settingService.settings.resourceBaseUrl;
  }

  ngOnInit(): void {

    this._customizationService.customization$.pipe(takeUntil(this._unsubscribeAll))
    .subscribe(res => {
      if (res) {
        this.defaultRoomBackgroundUrl = res.roomBackgroundImageUrl;
        this._changeDetectorRef.detectChanges();
      }
    });

    this._eventService.rooms$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe(rooms => {
        this.rooms = rooms;
        if (this.rooms) {
          this.prepareRoomsAndBooth();
        }
        this._changeDetectorRef.markForCheck();
      });

    this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe(u => {
      this.currentUser = new UserModel(u);
    });

    this._eventService.event$.pipe(takeUntil(this._unsubscribeAll)).subscribe({
      next: (ev) => {
        this.eventData = ev;
      },
      error: (err) => {
        this._messageService.showErrorMessage(err);
      }
    });

    this._eventService.attendees$.pipe(takeUntil(this._unsubscribeAll)).subscribe(atts => {
      this.attendees = atts?.filter(a => a.userId !== this.currentUser.userId);
    });

    this._signalrService.onNewSignal$.pipe(takeUntil(this._unsubscribeAll)).subscribe(st => {
      if (st && st.command === CommandType.userStatusChanged) {
        const targetAtt = this.onlineAttendees?.find(a => a.userId === st.data.userId);
        if (targetAtt) {
          targetAtt.status = st.data.status;
          targetAtt.roomId = st.data.roomId;
          this._changeDetectorRef.markForCheck();
        }
      }
    });

    this._signalrService.getEventAttendees(this._eventService.getEventId()).then(d => {
      if (d) {
        this.onlineAttendees = d;
        this._changeDetectorRef.markForCheck();
      }
    });
  }

  ngAfterViewInit(): void {
    this.sidebarInstance = this._sidebarService.getSidebar('warRoomSidenav');
    this.sidebarInstance?.openedChanged?.pipe(takeUntil(this._unsubscribeAll))?.subscribe(s => {
      if (!s) {
        this.activeEditorRoomId = undefined;
        this._changeDetectorRef.markForCheck();
      }
    })
  }

  filterRoomsByCategory(): void {
    if (this.currentRoomCategory === 'all') {
      this.filteredSimpleRooms = this.simpleRooms
      this.filteredMultiBoothRooms = this.multiBoothRooms;
    }
    else {
      this.filteredSimpleRooms = [];
      this.filteredMultiBoothRooms = this.multiBoothRooms.filter(r => r.roomType == this.currentRoomCategory)
    }
  }

  toggleSidebar(dataType: string, room: RoomModel): void {
    this.sidebarInstance.open();
    this._warRoomService.setSidePanelView(dataType, room);
    this.activeEditorRoomId = room?.roomId;
  }

  private prepareRoomsAndBooth() {

    if (this.rooms) {

      const simpleRoomTypes: RoomType[] = [EnumRoomType.stage, EnumRoomType.keynote, EnumRoomType.greenRoom];
      this.simpleRooms = this.filteredSimpleRooms = this.rooms.filter(r => simpleRoomTypes.includes(r.roomType));

      const multiBoothRoomTypes: RoomType[] = [EnumRoomType.session, EnumRoomType.expo, EnumRoomType.networking];
      this.multiBoothRooms = this.filteredMultiBoothRooms = this.rooms.filter(r => simpleRoomTypes.indexOf(r.roomType) === -1 && multiBoothRoomTypes.includes(r.roomType));

      const cuustomRooms = this.rooms.filter(r => r.roomType === EnumRoomType.customRoom);
      if (cuustomRooms && cuustomRooms.length) {
        const customRoom = {
          roomName: 'Custom Rooms',
          roomType: EnumRoomType.customRoom,
          booths: cuustomRooms
        } as unknown as RoomModel;
        this.multiBoothRooms = this.filteredMultiBoothRooms = [...this.multiBoothRooms, customRoom];
      }
    }
  }

  getAttendeesCount(roomId: number) {
    const count = this.onlineAttendees?.filter(a => a.roomId == roomId && a.status == UserStatusEnum.inacall)?.length ?? 0;
    return count;
  }

  getBackgroundImageUrl(room: RoomModel): string {
    let roomBackgroundUrl = '';
    if (room) {
      if (room.settings.backgroundImageEnabled && room.backgroundImage) {
        roomBackgroundUrl = this.resourceBaseUrl + room.backgroundImage.imagePath;
      } else if (room.thumbImage) {
        roomBackgroundUrl = this.resourceBaseUrl + room.thumbImage.imagePath;
      } else if (room.mediaType && room.mediaType.toLowerCase() === 'image' && room.roomImage) {
        roomBackgroundUrl = this.resourceBaseUrl + room.roomImage.imagePath;
      } else if (this.eventData &&
        this.eventData.settings.backgroundImageEnabled &&
        this.eventData.backgroundImagePath) {
        roomBackgroundUrl = this.resourceBaseUrl + this.eventData.backgroundImagePath;
      } else {
        roomBackgroundUrl = this.defaultRoomBackgroundUrl;
      }
    }
    return roomBackgroundUrl;
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }
}
