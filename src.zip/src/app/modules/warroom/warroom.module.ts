import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { MaterialModule } from 'src/app/core/material.module';
import { ListViewComponent } from './list-view/list-view.component';
import { WarRoomSidenavComponent } from './sidenav/sidenav.component';
import { WarroomComponent } from './warroom.component';
import { EventEditorComponent } from './sidenav/event-editor/event-editor.component';
import { FwSidebarModule } from 'src/app/core/components';
import { NgxSpinnerModule } from 'ngx-spinner';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { RoomEditorComponent } from './sidenav/room-editor/room-editor.component';
import { QuillModule } from 'ngx-quill';
import { FwColorPickerModule } from 'src/app/core/components/color-picker/color-picker.module';
import { DownloadChatModule } from './download-chat/download-chat.module';
import { BroadcastMessageModule } from './broadcast-message/broadcast-message.module';
import { RightPanelModule } from 'src/app/layout/components/right-panel/right-panel.module';
import { ManageAttendeeModule } from './manage-attendees/manage-attendee.module';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

const routes: Routes = [
  {
    path: '**',
    component: WarroomComponent
  }
];

@NgModule({
  
  declarations: [
    WarroomComponent,
    WarRoomSidenavComponent,
    ListViewComponent,
    EventEditorComponent,
    RoomEditorComponent
  ],
  bootstrap: [WarroomComponent],
  imports: [
    RouterModule.forChild(routes),
    MaterialModule,
    FwSidebarModule,
    FwCoreModule,
    NgxSpinnerModule,
    NgxDropzoneModule,
    QuillModule.forRoot(),
    FwColorPickerModule,
    DownloadChatModule,
    FwColorPickerModule,
    BroadcastMessageModule,
    RightPanelModule,
    ManageAttendeeModule
  ],
  exports: [ 
    WarroomComponent,
    WarRoomSidenavComponent,
    ListViewComponent,
    EventEditorComponent,
    RoomEditorComponent
  ],
  providers: [
    { provide: MAT_DIALOG_DATA, useValue: {} },
    { provide: MatDialogRef, useValue: {} }
  ]
})
export class WarroomModule {
}
