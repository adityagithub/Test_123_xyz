import { AfterViewInit, ChangeDetectorRef, Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { UserModel } from 'src/app/shared/models/user.model';
import { UserService } from 'src/app/shared/services/user.service';
import { EventModel, RoomNavigationModel } from 'src/app/shared/models/event.model';
import { CommandType, SignalDataContent, SignalDataModel, SignalLevel } from 'src/app/shared/models/signalr.models';
import { EventService } from 'src/app/shared/services/event.service';
import { MessageService } from 'src/app/shared/services/message.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { EnumRoomType } from '../../rooms/room/room.models';
import { NotificationModel } from '../../../shared/models/notifications.models';
import { NotificationsService } from '../../../shared/services/notifications.service';

@Component({
  selector: 'broadcast-message',
  templateUrl: './broadcast-message.component.html',
  styleUrls: ['./broadcast-message.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class BroadcastMessageComponent implements OnInit, AfterViewInit {
  private _unsubscribeAll: Subject<any> = new Subject();
  currentUser: UserModel;
  eventData: EventModel;
  messageType: 'event' | 'rooms' = 'event';
  broadcastMessageContent: string;
  roomType = EnumRoomType;
  rooms: RoomNavigationModel[] = [];
  selectedRoomIds: number[] = [];
  displayUntilSeconds: number = 15;

  @Input() inline = false;

  constructor(
    private _messageService: MessageService,
    private _userService: UserService,
    private _eventService: EventService,
    private _signalrService: SignalrService,
    private _changeDetectorRef: ChangeDetectorRef,
    private _notificationService: NotificationsService) {
  }

  ngOnInit(): void {
    this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe(u => {
      this.currentUser = new UserModel(u);
    });

    this._eventService.event$.pipe(takeUntil(this._unsubscribeAll)).subscribe(data => {
      this.eventData = data;
      this._changeDetectorRef.markForCheck();
    });

    this._eventService.navigations$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((data) => {
        this.rooms = this.prepareDropdownNavigations(data);
      });
  }

  ngAfterViewInit() {

  }

  prepareDropdownNavigations(data: RoomNavigationModel[]): RoomNavigationModel[] {
    const mainRooms = data.filter(x => x.roomType !== 'customroom');
    const customRooms = data.filter(x => x.roomType === 'customroom');
    const customRoomRoot = {
      roomId: 999,
      roomName: 'Custom Rooms',
      roomType: 'customroom',
      children: customRooms,
      displayOrder: null,
      isEnabled: true
    } as RoomNavigationModel;
    mainRooms.push(customRoomRoot);
    return mainRooms;
  }

  async broadcastMessage(): Promise<void> {

    if (!this.broadcastMessageContent) {
      this._messageService.showErrorMessage('Please write your message');
      return;
    }

    const data = {
      receiverIds: [],
      command: CommandType.messageToEvent,
      signalLevel: SignalLevel.event,
      data: {
        extra: {
          message: `<h1>${this.broadcastMessageContent}</h1>`,
          seconds: this.displayUntilSeconds
        }
      } as SignalDataContent,
    } as SignalDataModel;

    if (this.messageType == 'rooms') {
      data.receiverIds = this.selectedRoomIds;
      data.command = CommandType.messageToRooms;
      data.signalLevel = SignalLevel.rooms;
      let extra1: any[] = this.rooms.filter(x => this.selectedRoomIds.includes(x.roomId)).map(({ roomId, roomType }) => ({ roomId, roomType }))
      let extra2: any[] = this.rooms.flatMap(m => m.children).filter(x => this.selectedRoomIds.includes(x.roomId)).map(({ roomId, roomType }) => ({ roomId, roomType }))
      const extra = extra1.concat(extra2);
      data.data.extra.roomsMapping = extra;
    }

    await this._signalrService.sendSignal(data);

    this.updateNotificationInDb();

    this._messageService.showSuccessMessage('Message sent');
    this.broadcastMessageContent = '';
  }

  private updateNotificationInDb() {
    const notification = {
      notificationMessage: this.broadcastMessageContent,
      notificationSentBy: this.currentUser.userId,
      notificationSentFor: this.messageType == 'rooms' ? this.selectedRoomIds.join() : this.eventData.virtualEventId.toString(),
      notificationType: this.messageType == 'rooms' ? 'room-broadcast' : 'event-broadcast',
      eventId: this.eventData.eventId,
      virtualEventId: this.eventData.virtualEventId
    } as NotificationModel;

    this._notificationService.addUserNotification(notification)
      .pipe(takeUntil(this._unsubscribeAll)).subscribe(async (notification) => {
        console.log(notification);
      });
  }

  async ngOnDestroy(): Promise<void> {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }
}
