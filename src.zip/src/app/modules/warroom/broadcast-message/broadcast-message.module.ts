import { NgModule } from '@angular/core';
import { MaterialModule } from 'src/app/core/material.module';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { BroadcastMessageComponent } from './broadcast-message.component';

@NgModule({
  declarations: [
    BroadcastMessageComponent
  ],
  imports: [
    MaterialModule,
    FwCoreModule
  ],
  exports: [
    BroadcastMessageComponent
  ]
})
export class BroadcastMessageModule {

}
