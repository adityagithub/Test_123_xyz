import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class WarroomService {

    private _viewData: Subject<any> = new Subject<any>();

    get onViewChange$(): Observable<any> {
        return this._viewData.asObservable()
    }

    setSidePanelView(view: string, viewData: any) {
        this._viewData.next({ view, viewData });
    }
}
