import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MaterialModule } from 'src/app/core/material.module';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { RecordingComponent } from './recordings.component';
import { RecordingListModule } from './recording-list/recording-list.module';

const routes: Routes = [
  {
    path: '**',
    component: RecordingComponent
  }
];

@NgModule({
  declarations: [
    RecordingComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    MaterialModule,
    FwCoreModule,
    RecordingListModule
  ],
  providers: [
  ]
})
export class RecordingModule {
}
