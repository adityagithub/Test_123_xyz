import {
  Component,
  OnDestroy, OnInit,
  ViewEncapsulation
} from '@angular/core'
import { Subject, takeUntil } from 'rxjs'
import { appAnimations } from 'src/app/core/animations'
import { FwConfigService } from 'src/app/core/services/config.service'
import { RoomService } from '../../rooms/room/room.service'
import { LayoutConfig } from 'src/app/core/layoutConfig'
import { EventService } from 'src/app/shared/services/event.service'
import { RecordingModel } from './recordings.models'
import { RecordingListService } from './recording-list/recording-list.service'

@Component({
  selector: 'fw-Recording-list',
  templateUrl: './recordings.component.html',
  styleUrls: ['./recordings.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: appAnimations
})
export class RecordingComponent implements OnInit, OnDestroy {
  private _unsubscribeAll: Subject<any> = new Subject();

  selectedRecording: string;
  currentRecording: RecordingModel;

  constructor(
    private _recordingService: RecordingListService,
    private _eventService: EventService,
    private _roomService: RoomService,
    private _fwConfigService: FwConfigService
  ) {

    this._fwConfigService.config
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((config: LayoutConfig) => {
        //config.layout.navbar.hidden = true;
        //config.layout.sidepanel.hidden = true;
        //config.layout.toolbar.hidden = true;
      });
  }

  ngOnInit(): void {
    this._roomService.getRoomDetails(0).pipe(takeUntil(this._unsubscribeAll)).subscribe();
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }
}
