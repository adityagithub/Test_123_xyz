
export class RecordingModel {
    id: number;
    type: string;
    title: string;
    description: string;
}