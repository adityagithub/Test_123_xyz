import { NgModule } from "@angular/core";
import { MaterialModule } from "src/app/core/material.module";
import { FwCoreModule } from "src/app/core/fw.core.module";
import { RecordingListService } from "./recording-list.service";
import { FwRecordingListComponent } from "./recording-list.component";
import { NgxSpinnerModule } from "ngx-spinner";

@NgModule({
  declarations: [   
    FwRecordingListComponent
  ],
  imports: [
    MaterialModule,
    FwCoreModule,
    NgxSpinnerModule
  ],
  exports: [
    FwRecordingListComponent
  ],
  providers:[]
})
export class RecordingListModule {
}