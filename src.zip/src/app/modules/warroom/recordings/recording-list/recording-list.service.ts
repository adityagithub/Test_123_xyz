import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ApiResponse } from 'src/app/shared/models/shared.model';
import { RecordingDataViewModel } from './recording-list.model';

@Injectable({providedIn: 'root'})
export class RecordingListService {

    constructor(private _httpClient: HttpClient) {
    }

    getRecordings(params: any): Observable<RecordingDataViewModel[]> {
        return this._httpClient.get<ApiResponse<RecordingDataViewModel[]>>('api/room/recording/list', { params })
            .pipe(map((notifications) => {
                return notifications.data;
            }))
    }

    downloadRecording(key: string, fileName: string): Promise<boolean> {

        fileName = fileName + '.mp4'
        const myPromise = new Promise<boolean>((resolve, reject) => {
            this._httpClient.get(`api/room/recording/download?key=${key}&fileName=${fileName}`, {
                responseType: 'arraybuffer'
            }).subscribe({
                next: (res) => {
                    const url = window.URL.createObjectURL(new Blob([res]));
                    const a = document.createElement('a');
                    a.style.display = 'none';
                    a.href = url;
                    a.target = "_blank";
                    a.download = fileName;
                    document.body.appendChild(a);
                    a.click();
                    window.URL.revokeObjectURL(url);
                    resolve(true)
                },
                error: () => {
                    reject(true)
                }
            })
        });

        return myPromise;
    }

    downloadRecordingByUrl(key: string, fileName: string): Promise<boolean> {

        const myPromise = new Promise<boolean>((resolve, reject) => {
            this._httpClient.get<ApiResponse<any>>(`api/room/recording/download-url?key=${key}&fileName=${fileName}`).subscribe({
                next: (res) => {
                    const url = res.data.fileUrl;
                    const a = document.createElement('a');
                    a.style.display = 'none';
                    a.href = url;
                    a.target = "_blank"
                    a.download = fileName;
                    document.body.appendChild(a);
                    a.click();
                    window.URL.revokeObjectURL(url);
                    resolve(true)
                },
                error: () => {
                    reject(true)
                }
            })
        });

        return myPromise;
    }

    getDownloadUrl(key: string): Observable<any> {
        return this._httpClient.get(`api/room/recording/download-url?key=${key}`)
            .pipe(map((res) => {
                return res;
            }))
    }

    deleteRecording(roomId: number, recordingId: string): Observable<boolean> {
        return this._httpClient.post<ApiResponse<boolean>>('api/room/recording/delete', { roomId, recordingId})
            .pipe(map((data: ApiResponse<boolean>) => {
                return data.data;
            }))
    }

}
