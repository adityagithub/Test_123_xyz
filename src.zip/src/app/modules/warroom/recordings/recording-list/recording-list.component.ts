import { Component, OnDestroy, OnInit } from '@angular/core';
import { RecordingListService } from './recording-list.service';
import { RecordingDataViewModel, RecordingStatus } from './recording-list.model';
import { SharedService } from 'src/app/shared/services/shared.service';
import { FwUtils } from 'src/app/core/utils';
import { Subject, takeUntil } from 'rxjs';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmDialogComponent } from 'src/app/core/components/confirm-dialog/confirm-dialog.component';
import { MessageService } from 'src/app/shared/services/message.service';
import { RoomNavigationModel } from 'src/app/shared/models/event.model';
import { EventService } from 'src/app/shared/services/event.service';
import { EnumRoomType } from 'src/app/modules/rooms/room/room.models';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'fw-recording-list',
  styleUrls: ['recording-list.component.scss'],
  templateUrl: 'recording-list.component.html',
})
export class FwRecordingListComponent implements OnInit, OnDestroy {

  private _unsubscribeAll: Subject<any> = new Subject<any>();
  activeDownloads: string[] = [];
  recordingList: RecordingDataViewModel[];
  filteredRecordingList: RecordingDataViewModel[];

  roomType = EnumRoomType;
  rooms: RoomNavigationModel[] = [];
  selectedRoomIds: number[] = [];
  rStatus = RecordingStatus;

  displayedColumns = ['position', 'name', 'weight', 'symbol'];
  loading = false;
  openInDialog: boolean;


  constructor(
    private _matDialog: MatDialog,
    private _eventService: EventService,
    private _recordingService: RecordingListService,
    private _sharedService: SharedService,
    private _messageService: MessageService,
    private _ngxSpinnerService: NgxSpinnerService
  ) {
    this._eventService.navigations$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((data) => {
        this.rooms = this.prepareDropdownNavigations(data);
      });
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  ngOnInit(): void {
    this.getRecordingList();
  }

  prepareDropdownNavigations(data: RoomNavigationModel[]): RoomNavigationModel[] {
    const mainRooms = data.filter(x => x.roomType !== 'customroom');
    const customRooms = data.filter(x => x.roomType === 'customroom');
    const customRoomRoot = {
      roomId: 999,
      roomName: 'Custom Rooms',
      roomType: 'customroom',
      children: customRooms,
      displayOrder: null,
      isEnabled: true
    } as RoomNavigationModel;
    mainRooms.push(customRoomRoot);
    return mainRooms;
  }

  downloadRecording(data: RecordingDataViewModel) {
    this.activeDownloads.push(data.recordingId);
    this._recordingService.downloadRecording(data.recordingS3Id, data.fileName).then(res => {
      this.removeFromActiveDownload(data.recordingId)
    }, err => {
      this.removeFromActiveDownload(data.recordingId)
    });
  }

  downloadRecordingByUrl(data: RecordingDataViewModel) {
    this.activeDownloads.push(data.recordingId);
    this._recordingService.downloadRecordingByUrl(data.recordingS3Id, data.fileName).then(res => {
      this.removeFromActiveDownload(data.recordingId)
    }, err => {
      this.removeFromActiveDownload(data.recordingId)
    });
  }

  deleteRecording(data: RecordingDataViewModel) {

    const index = this.activeDownloads.indexOf(data.recordingId);
    if (index > -1) {
      this._messageService.showErrorMessage("Sorry! The request cannot be completed. Please try after some time.");
      return;
    }

    const dialogRef = this._matDialog.open(ConfirmDialogComponent, {
      data: {
        Title: 'Please confirm',
        Message: 'Are you sure you want to delete <b>' + data.roomName + '</b> recording?',
        CancelText: 'No',
        OkText: 'Yes'
      }
    });
    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(async result => {
      if (result) {
        this._recordingService.deleteRecording(data.roomId, data.recordingS3Id)
          .pipe(takeUntil(this._unsubscribeAll))
          .subscribe({
            next: () => {
              this.getRecordingList();
            },
            error: () => {

            }
          });
      }
    });
  }

  convertBytes(bytes: any) {
    return FwUtils.bytesToDisplayForm(bytes)
  }

  onRoomSelectionChange($event: any) {
    console.log(this.selectedRoomIds, 'selected room ids');
    if (this.selectedRoomIds.length == 0) {
      this.filteredRecordingList = this.recordingList;
      return;
    }
    this.filteredRecordingList = this.recordingList.filter(r => this.selectedRoomIds.includes(r.roomId));
  }

  private removeFromActiveDownload(recordingId: string) {
    const index = this.activeDownloads.indexOf(recordingId);
    if (index > -1) {
      this.activeDownloads.splice(index, 1);
    }
  }

  getRecordingList(): any {
    this.loading = true;
    this._ngxSpinnerService.show();
    this._recordingService.getRecordings(this._eventService.getEventId())
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe({
        next: (res) => {
          this.loading = false;
          this._ngxSpinnerService.hide();
          this.recordingList = this.filteredRecordingList = res;     
        },
        error: (err) => {
          this.loading = false;
          this._ngxSpinnerService.hide();
        }
      });
  }
}