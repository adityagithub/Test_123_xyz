
export interface RecordingDataViewModel {
    recordingId: string;
    recordingS3Id: string;
    fileName: string;
    roomId: number;
    roomName: string;
    storageSize: string;
    recordingDate: Date;
    duration: string;
    status: RecordingStatus
}

export enum RecordingStatus {
    initiated,
    started,
    paused,
    stopped,
    complete,
    error
}