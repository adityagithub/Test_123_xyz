import { SelectionModel } from '@angular/cdk/collections';
import { AfterViewInit, ChangeDetectorRef, Component, Inject, Input, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSelectChange } from '@angular/material/select';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { BehaviorSubject, combineLatest, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ConfirmDialogComponent } from 'src/app/core/components/confirm-dialog/confirm-dialog.component';
import { ConfirmDialogComponentData } from 'src/app/core/components/confirm-dialog/confirm.dialog.models';
import { ChangeRoleRequest, UserModel, UserRoleAction, UserStatusEnum } from 'src/app/shared/models/user.model';
import { UserService } from 'src/app/shared/services/user.service';
import { EventModel, RoomNavigationModel } from 'src/app/shared/models/event.model';
import { CommandType, SignalDataContent, SignalDataModel, SignalLevel } from 'src/app/shared/models/signalr.models';
import { EventService } from 'src/app/shared/services/event.service';
import { MessageService } from 'src/app/shared/services/message.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { EnumRoomType, RoomModel } from '../../rooms/room/room.models';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';

@Component({
  selector: 'manage-attendees',
  templateUrl: './manage-attendees.component.html',
  styleUrls: ['./manage-attendees.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class ManageAttendeeComponent implements OnInit, AfterViewInit {
  private _unsubscribeAll: Subject<any> = new Subject();

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  dataSource: MatTableDataSource<UserModel>;
  currentUser: UserModel;
  eventData: EventModel;
  genericUrl: string;
  genericRow: any = { tooltip : 'Copy Link' };

  displayedColumns: string[] = ['userId', 'fullName', 'roomName', 'uniqueUrl', 'status'];

  selection = new SelectionModel<UserModel>(true, []);
  roomType = EnumRoomType;
  userStatusType = UserStatusEnum;
  rooms: RoomNavigationModel[] = [];
  selectedRoomIds: number[] = [];
  attendees: UserModel[];
  searchTerm: string;
  filteredAttendees: UserModel[] = [];
  breakoutUnAssignedAttendeeIds: number[];
  callForBreakout: boolean;
  filters: {
    status$: BehaviorSubject<string>;
    query$: BehaviorSubject<string>;
    role$: BehaviorSubject<string>;
    roomIds$: BehaviorSubject<number[]>;
  } = {
      status$: new BehaviorSubject('online'),
      query$: new BehaviorSubject(''),
      role$: new BehaviorSubject('all'),
      roomIds$: new BehaviorSubject([])
    };

  @Input() warroom: boolean = false;

  constructor(
    private _settingService: AppSettingService,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private _matDialogRef: MatDialogRef<ManageAttendeeComponent>,
    private _matDialog: MatDialog,
    private _messageService: MessageService,
    private _userService: UserService,
    private _eventService: EventService,
    private _signalrService: SignalrService,
    private _changeDetectorRef: ChangeDetectorRef) {
    this.breakoutUnAssignedAttendeeIds = data.unAssignedAttendeeIds ?? [];
    this.callForBreakout = data.callFor === 'breakoutRooms';
  }

  ngOnInit(): void {
    this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe(u => {
      this.currentUser = new UserModel(u);
    });

    this._eventService.event$.pipe(takeUntil(this._unsubscribeAll)).subscribe(data => {
      this.eventData = data;
      let hostingFolderName = location.pathname.replace(/^\/([^\/]*).*$/, '$1');
      this.genericUrl = location.origin + `/${hostingFolderName}/` + this.eventData.eventId + '/login';
      this._changeDetectorRef.markForCheck();
    });

    this._eventService.attendees$.pipe(takeUntil(this._unsubscribeAll)).subscribe(atts => {
      this.attendees = this.filteredAttendees = atts?.filter(a => a.userId !== this.currentUser.userId);
      let hostingFolderName = location.pathname.replace(/^\/([^\/]*).*$/, '$1');
      var baseUrl = location.origin + `/${hostingFolderName}` + '/fireworks/' + this.eventData.eventId + '/';
      this.filteredAttendees.forEach(a => {
        a.uniqueUrl = baseUrl + a.token + '/lobby';
        a.roomName = this._eventService.findRoom(a.roomId)?.roomName;
      });
      if (this.callForBreakout) {
        this.attendees = this.filteredAttendees = atts?.filter(a => a.userId !== this.currentUser.userId &&
          this.breakoutUnAssignedAttendeeIds.includes(a.userId));
      }
      this.filterByStatus(this.filters.status$?.value);
      this.dataSource = new MatTableDataSource(this.filteredAttendees);
      this._changeDetectorRef.markForCheck();
    });

    this._signalrService.onNewSignal$.pipe(takeUntil(this._unsubscribeAll)).subscribe(st => {
      if (st && st.command === CommandType.userStatusChanged) {
        const targetAtt = this.filteredAttendees.find(a => a.userId === st.data.userId);
        if (targetAtt) {
          targetAtt.status = st.data.status;
          targetAtt.roomId = st.data.roomId;
          targetAtt.roomName = this._eventService.findRoom(st.data.roomId)?.roomName;
          this._changeDetectorRef.markForCheck();
        }

        this.filterByStatus(this.filters.status$?.value);
      }
    });

    this._signalrService.getEventAttendees(this._eventService.getEventId()).then(d => {
      if (d) {
        d.forEach(u => {
          const att = this.filteredAttendees.find(a => a.userId === u.userId);
          if (att) {
            att.status = u.status;
            att.roomId = u.roomId;
            att.roomName = this._eventService.findRoom(u.roomId)?.roomName
          }
        });
        this._changeDetectorRef.markForCheck();
      }
    });

    combineLatest([this.filters.status$, this.filters.query$, this.filters.role$, this.filters.roomIds$])
      .subscribe(([status, query, role, roomIds]) => {
        // Reset the filtered attendees
        this.filteredAttendees = this.attendees;
        this.selection?.clear();

        // Filter by Role
        if (role !== 'all') {
          if (role === 'cohost') {
            this.filteredAttendees = this.attendees.filter(a => a.isHostOrCoHost());
          } else if (role === 'speaker') {
            this.filteredAttendees = this.attendees.filter(a => a.isPresenter());
          } else if (role === 'attendee') {
            this.filteredAttendees = this.attendees.filter(a => a.isAttendee());
          }
        }

        // Filter by Status
        if (status !== 'all') {
          if (status === 'online') {
            this.filteredAttendees = this.filteredAttendees
              .filter((a) => a.status !== UserStatusEnum.offline &&
                a.status !== UserStatusEnum.none &&
                a.status !== UserStatusEnum.away);
          } else if (status === 'offline') {
            this.filteredAttendees = this.filteredAttendees
              .filter((a) => a.status === UserStatusEnum.offline ||
                a.status === UserStatusEnum.none ||
                a.status === UserStatusEnum.away);
          } else {
            this.filteredAttendees = this.filteredAttendees.filter((a) => this.userStatusType[a.status] === status);
          }
        }

        // Filter by Rooms
        if (roomIds?.length) {
          this.filteredAttendees = this.filteredAttendees.filter(a => roomIds?.includes(a.roomId));
        }

        // Filter by search query
        if (query !== '') {
          this.filteredAttendees = this.filteredAttendees.filter((att) => {
            return att.getFullName().toLowerCase().includes(query.toLowerCase()) ||
              att.roomName?.toLowerCase()?.includes(query.toLowerCase());
          });
          if (this.dataSource.paginator) {
            this.dataSource.paginator.firstPage();
          }
        }

        this.dataSource.data = this.filteredAttendees;
        this._changeDetectorRef.markForCheck();
      });

    this._eventService.navigations$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((data) => {
        this.rooms = data;
        this._changeDetectorRef.markForCheck();
      });
  }

  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  masterToggle() {
    this.isAllSelected()
      ? this.selection.clear()
      : this.dataSource.data.forEach((row: UserModel) => this.selection.select(row));
  }

  assignAttendees() {
    this._matDialogRef.close(this.selection.selected);
  }

  async kickOutAttendee(member: UserModel = null): Promise<void> {
    let memberIds = [];
    if (member) {
      memberIds.push(member.userId);
    } else {
      memberIds = this.selection.selected
        .filter(z => z.userId !== this.currentUser.userId)
        .map(x => x.userId);
    }
    if (!this.selection.selected.length && !memberIds.length) {
      this._messageService.showErrorMessage('Please select attendee to remove from room.');
      return;
    }
    const dialogRef = this._matDialog.open(ConfirmDialogComponent, {
      data: {
        Title: 'Please confirm',
        Message: 'Are you sure you want to remove selected attendees?',
        CancelText: 'No',
        OkText: 'Yes'
      } as ConfirmDialogComponentData
    });
    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(async (result) => {
      if (result) {
        if (memberIds.length) {
          const data = {
            receiverIds: memberIds,
            command: CommandType.kickoutAttendee,
            signalLevel: SignalLevel.persons,
            data: {} as SignalDataContent
          } as SignalDataModel;

          await this._signalrService.sendSignalToUsers(data);
          // TODO: Move to waitroom functionality.
          this._messageService.showSuccessMessage('Selected users removed from room(s)');
          this.selection.clear();
        }
      }
    });
  }

  async moveAttendeetoAnotherRoom(targetRoom: RoomNavigationModel, member: UserModel = null): Promise<void> {

    let memberIds = [];
    if (member) {
      memberIds.push(member.userId);
    } else {
      memberIds = this.selection.selected
        .filter(z => z.userId !== this.currentUser.userId)
        .map(x => x.userId);
    }
    if (!this.selection.selected.length && !memberIds.length) {
      this._messageService.showErrorMessage('Please select attendees to move.');
      return;
    }

    if (memberIds.length) {
      const data = {
        receiverIds: memberIds,
        command: CommandType.moveToAnotherRoom,
        signalLevel: SignalLevel.persons,
        data: { roomId: targetRoom.roomId }
      } as SignalDataModel;
      await this._signalrService.sendSignalToUsers(data);
      this._messageService.showSuccessMessage('Selected users moved to ' + targetRoom.roomName);
      this.selection.clear();
    }
  }

  filterByQuery(search: string): void {
    this.filters.query$.next(search);
  }

  filterByStatus(status: any): void {
    this.filters.status$.next(status);
  }

  filterByRole(role: MatSelectChange): void {
    this.filters.role$.next(role.value);
  }

  filterByRooms(roomIds: number[]): void {
    this.filters.roomIds$.next(roomIds);
  }

  async ngOnDestroy(): Promise<void> {
    if (this.dataSource) {
      this.dataSource.disconnect();
    }
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  copyAttendeLink($this: any, row: any, url: string = ''): void {
    // create temp element

    if(url){ row.uniqueUrl = url };

    var copyElement = document.createElement("span");
    copyElement.appendChild(document.createTextNode(row.uniqueUrl));
    copyElement.id = 'tempCopyToClipboard';
    document.body.append(copyElement);

    // select the text
    var range = document.createRange();
    range.selectNode(copyElement);
    window.getSelection().removeAllRanges();
    window.getSelection().addRange(range);

    // copy & cleanup
    document.execCommand('copy');
    window.getSelection().removeAllRanges();
    copyElement.remove();
    row.tooltip = 'Link copied!';
    $this.target.classList.add('text-primary');
    setTimeout(function () {
      $this.target.classList.remove('text-primary');
      row.tooltip = 'Copy Link';
    }, 4000);
  }

  changeUserRole(action: UserRoleAction, attendee: UserModel) {
    const dialogRef = this._matDialog.open(ConfirmDialogComponent, {
      data: {
        Title: 'Are you sure?',
        Message: 'Change <b>' + attendee.firstName + '</b>\'s role to <b>' + this.getRoleDisplayName(action) + '</b>',
        CancelText: 'No',
        OkText: 'Yes'
      }
    });
    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(result => {
      if (result) {
        const request = { action, userId: attendee.userId } as ChangeRoleRequest;
        this._userService.changeUserRole(request).subscribe(s => {
          const signalDataModel = {
            receiverId: attendee.userId,
            command: CommandType.memberRoleChange,
            signalLevel: SignalLevel.event,
            data: { userRoles: s.updatedRoles }
          } as SignalDataModel;
          this._signalrService.sendSignal(signalDataModel).then(res => {
            this._eventService.getAttendees().pipe(takeUntil(this._unsubscribeAll)).subscribe();
          });
        });
      }
    });
  }

  getRoleDisplayName(userAction: UserRoleAction): string {
    if (userAction === UserRoleAction.make_attendee) {
      return 'Attendee';
    } else if (userAction === UserRoleAction.make_cohost) {
      return 'Co-Host';
    } else if (userAction === UserRoleAction.make_presenter) {
      return 'Presenter';
    }
  }

  changeUserVisibility(user: UserModel): void {

    const dialogRef = this._matDialog.open(ConfirmDialogComponent, {
      data: {
        Title: 'Please confirm',
        Message: user.hideFromScreen ? `Do you want to show ${user.getFullName()} on screen?` : `Do you want to hide ${user.getFullName()} from screen?`,
        CancelText: 'Cancel',
        OkText: 'Yes'
      }
    });
    dialogRef.afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(async result => {
      if (result) {
        const signalDataModel = {
          receiverIds: [user.userId],
          command: CommandType.hideFromScreen,
          signalLevel: SignalLevel.event,
          data: { extra: { hide: !user.hideFromScreen } }
        } as SignalDataModel;
        this._signalrService.sendSignal(signalDataModel).then(res => {
          this.currentUser.hideFromScreen = !user.hideFromScreen;
        });
      }
    });
  }

}
