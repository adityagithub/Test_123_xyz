import { NgModule } from '@angular/core';
import { MaterialModule } from 'src/app/core/material.module';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { ManageAttendeeComponent } from './manage-attendees.component';

@NgModule({
  declarations: [
    ManageAttendeeComponent
  ],
  imports: [
    MaterialModule,
    FwCoreModule
  ],
  exports: [ManageAttendeeComponent]
})
export class ManageAttendeeModule {

}
