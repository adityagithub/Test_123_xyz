import { NgModule } from '@angular/core';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { MaterialModule } from 'src/app/core/material.module';
import { BreakoutRoomComponent } from './breakout.component';
import { NgxSpinnerModule } from 'ngx-spinner';

@NgModule({
  declarations: [
    BreakoutRoomComponent
  ],
  imports: [
    MaterialModule,
    FwCoreModule,
    NgxSpinnerModule
  ],
  providers: [
  ],
  exports: [
    BreakoutRoomComponent
  ]
})
export class BreakoutRoomModule {
}
