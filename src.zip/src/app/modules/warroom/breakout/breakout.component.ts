import { ChangeDetectorRef, Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ConfirmDialogComponent } from 'src/app/core/components/confirm-dialog/confirm-dialog.component';
import { ConfirmDialogComponentData } from 'src/app/core/components/confirm-dialog/confirm.dialog.models';
import { UserModel, UserStatusEnum } from 'src/app/shared/models/user.model';
import { UserService } from 'src/app/shared/services/user.service';
import { EventModel } from 'src/app/shared/models/event.model';
import { CommandType, SignalDataContent, SignalDataModel, SignalLevel } from 'src/app/shared/models/signalr.models';
import { EventService } from 'src/app/shared/services/event.service';
import { MessageService } from 'src/app/shared/services/message.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { ManageAttendeeComponent } from '../manage-attendees/manage-attendees.component';
import { AttendeeAllocationType, BreakoutRoomModel, EnumRoomType, PrivateRoomModel, RoomModel } from '../../rooms/room/room.models';
import { RoomService } from '../../rooms/room/room.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';

@Component({
  selector: 'breakout-room',
  templateUrl: './breakout.component.html',
  styleUrls: ['./breakout.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class BreakoutRoomComponent implements OnInit, OnDestroy {
  private _unsubscribeAll: Subject<any> = new Subject();
  private _attendees: UserModel[] = [];
  private _distrubutedRoomsAttendee: any[] = [];
  currentUser: UserModel;
  eventData: EventModel;
  roomData: RoomModel;
  filteredAttendees: UserModel[] = [];
  roomNumber = 0;
  breakoutRoomData: BreakoutRoomModel;
  step1 = false;
  step2 = false;
  broadcastMessage: string;
  allChecked: boolean = false;
  resourceBaseUrl: string;
  allocationTypes: string[] = ["automatic", "manual"];

  constructor(
    private _router: Router,
    private _changeDetectorRef: ChangeDetectorRef,
    private _userService: UserService,
    private _eventService: EventService,
    private _roomService: RoomService,
    private _sharedService: SharedService,
    private _messageService: MessageService,
    private _signalrService: SignalrService,
    private _spinnerService: NgxSpinnerService,
    private _settingService: AppSettingService,
    public dialog: MatDialog
  ) {
    this.resourceBaseUrl = this._settingService.settings.resourceBaseUrl;
  }

  ngOnInit(): void {

    this._userService.user$.pipe(takeUntil(this._unsubscribeAll)).subscribe(user => {
      this.currentUser = user;
    });

    this._eventService.event$.pipe(takeUntil(this._unsubscribeAll)).subscribe(ev => {
      this.eventData = ev;
    });

    this._eventService.attendees$.pipe(takeUntil(this._unsubscribeAll)).subscribe(atts => {
      this._attendees = atts?.filter(a => a.userId !== this.currentUser.userId && a.isAttendee());
      this.filteredAttendees = this._attendees.filter((a) => a.isOnline());
      this._changeDetectorRef.markForCheck();
    });

    this._roomService.roomDetails$.pipe(takeUntil(this._unsubscribeAll)).subscribe(room => {
      this.roomData = room;
    });

    this._signalrService.getEventAttendees(this._eventService.getEventId()).then(d => {
      if (d) {
        d.forEach(u => {
          const att = this._attendees.find(a => a.userId === u.userId);
          if (att) {
            att.status = u.status;
            att.roomId = u.roomId;
            att.roomName = this._eventService.findRoom(u.roomId)?.roomName
          }
        });
        this.filteredAttendees = this._attendees.filter((a) => a.isOnline());
        this._changeDetectorRef.markForCheck();
      }
    });

    this._signalrService.onNewSignal$.pipe(takeUntil(this._unsubscribeAll)).subscribe(res => {
      if (res && res.command === CommandType.userStatusChanged) {
        const targetAtt = this._attendees.find(a => a.userId === res.data.userId);
        if (targetAtt) {
          targetAtt.status = res.data.status;
        }
        this.filteredAttendees = this._attendees.filter((a) => a.isOnline());
        this._changeDetectorRef.markForCheck();
      } else if (res.command === CommandType.openBreakoutRooms ||
        res.command === CommandType.closeBreakoutRooms ||
        res.command === CommandType.deleteBreakoutRooms ||
        res.command === CommandType.breakoutRoomsUpdated) {
        this._roomService.getBreakoutRooms().pipe(takeUntil(this._unsubscribeAll)).subscribe();
        this._messageService.showInfoMessage('Breakout Rooms has been updated by ' + res.data.extra);
      }
    });

    this._roomService.breakoutRooms$.pipe(takeUntil(this._unsubscribeAll)).subscribe(rooms => {
      this.breakoutRoomData = rooms;
      if (this.breakoutRoomData) {
        this.assignRoomMembers();
        if (this.breakoutRoomData.rooms.length > 0) {
          this.gotoNextStep();
        } else {
          this.fillRoomArray();
          this.goBack();
        }
      }
    });

    this._roomService.getBreakoutRooms().pipe(takeUntil(this._unsubscribeAll)).subscribe();
  }

  ngOnDestroy() {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  fillRoomArray() {
    const maxPresenter = 16; // environment.maxPresenter
    if (this.breakoutRoomData.attendeePerBreakout > this.filteredAttendees.length && this.breakoutRoomData.attendeePerBreakout > 0) {
      this.breakoutRoomData.attendeePerBreakout = this.filteredAttendees.length;
    } else if (this.breakoutRoomData.attendeePerBreakout > maxPresenter) {
      this.breakoutRoomData.attendeePerBreakout = maxPresenter;
    }

    if (this.breakoutRoomData.attendeePerBreakout) {
      const copy = [];
      Object.assign(copy, this.filteredAttendees);
      this._distrubutedRoomsAttendee = this.getAttendeesPerRoom(copy, this.breakoutRoomData.attendeePerBreakout);
      this.roomNumber = this._distrubutedRoomsAttendee.length;
    }
  }

  getAttendeesPerRoom(myArray: any[], chunkSize: any) {
    const results = [];
    while (myArray.length) {
      results.push(myArray.splice(0, chunkSize));
    }
    return results;
  }

  openCloseSpecificRoom(breakoutRoom: PrivateRoomModel) {
    const message = 'Breakout room ' + (breakoutRoom.isRoomOpen ? 'closed' : 'opened') + ' successfully.';
    breakoutRoom.isRoomOpen = !breakoutRoom.isRoomOpen;
    this.saveBreakoutInDB().pipe(takeUntil(this._unsubscribeAll)).subscribe(() => {
      this._messageService.showSuccessMessage(message);
      this.sendBreakoutSignalToMembers(breakoutRoom, breakoutRoom.isRoomOpen ? CommandType.openBreakoutRooms : CommandType.closeBreakoutRooms);
    });
  }

  openCloseAllRooms(opt: string) {
    this.breakoutRoomData.rooms.forEach(br => {
      br.isRoomOpen = (opt === 'opened');
      this.sendBreakoutSignalToMembers(br, br.isRoomOpen ? CommandType.openBreakoutRooms : CommandType.closeBreakoutRooms);
    })
    this.saveBreakoutInDB().pipe(takeUntil(this._unsubscribeAll)).subscribe(() => {
      this._messageService.showSuccessMessage('Breakout room(s) ' + opt + ' successfully.');
    });
  }

  joinBreakoutRoom(breakoutRoom: PrivateRoomModel) {
    if (this.roomData.roomType === EnumRoomType.breakout &&
      this.roomData.roomId === breakoutRoom.privateRoomId) {
      return;
    }
    this.dialog.closeAll();
    this._sharedService.enableAutoJoinRoom(true);
    const eId = this._eventService.getEventId();
    const token = this._sharedService.paramToken;
    const roomName = breakoutRoom.roomName.replace(/ /g, '-').toLowerCase();
    const url = `fireworks/${eId}/${token}/b/breakout/${breakoutRoom.privateRoomId}/${roomName}`;
    this._router.navigate([url], { replaceUrl: false });
  }

  showOpenCloseAllRooms(check: string): any {
    const res = this.breakoutRoomData.rooms.find(x => (check === 'open' ? x.isRoomOpen : !x.isRoomOpen)) !== undefined;
    return res;
  }

  moveAttendeetoAnotherRoom(sourceRoomId: number, destinationRoomId: number, attendeeId: number) {
    const sourceBreakoutRoom = this.breakoutRoomData.rooms.find(x => x.privateRoomId === sourceRoomId);
    const destinationBreakoutRoom = this.breakoutRoomData.rooms.find(x => x.privateRoomId === destinationRoomId);
    const attendee = sourceBreakoutRoom.roomParticipants.find(x => x.userId === attendeeId);
    destinationBreakoutRoom.roomParticipants.push(attendee);
    sourceBreakoutRoom.roomParticipants.splice(sourceBreakoutRoom.roomParticipants.indexOf(attendee), 1);
    sourceBreakoutRoom.participantIds = sourceBreakoutRoom.roomParticipants.map(x => { return x.userId }).join(',');
    destinationBreakoutRoom.participantIds = destinationBreakoutRoom.roomParticipants.map(x => { return x.userId }).join(',');
    this.saveBreakoutRooms();
  }

  goBack() {
    this.step2 = false;
    this.step1 = true;
  }

  gotoNextStep() {
    this.step2 = true;
    this.step1 = false;
  }

  getUnassignedAttendees(): UserModel[] {
    let roomParticipantIds = [];
    this.breakoutRoomData.rooms.forEach(br => {
      if (br.roomParticipants) {
        roomParticipantIds = roomParticipantIds.concat(br.roomParticipants.map(x => { return x.userId }));
      }
    });
    if (roomParticipantIds.length > 0) {
      return this.filteredAttendees.filter(x => roomParticipantIds.indexOf(x.userId) === -1);
    } else {
      return this.filteredAttendees;
    }
  }

  getUnassignedAttendeeIds(): number[] {
    let roomParticipantIds = [];
    this.breakoutRoomData.rooms.forEach(br => {
      if (br.roomParticipants) {
        roomParticipantIds = roomParticipantIds.concat(br.roomParticipants.map(x => { return x.userId }));
      }
    });
    if (roomParticipantIds.length > 0) {
      return this.filteredAttendees.filter(x => roomParticipantIds.indexOf(x.userId) === -1).map(m => m.userId);
    } else {
      return this.filteredAttendees.map(m => m.userId);
    }
  }

  createNewBreakoutRoom() {
    if (this.breakoutRoomData.rooms.length > 150) {
      this._messageService.showErrorMessage('Sorry! Cannot create more than 150 breakout rooms');
      return;
    }

    const unAssignedMembers = this.getUnassignedAttendees();
    if (unAssignedMembers.length === 0) {
      this._messageService.showErrorMessage('Sorry!! no more attendee(s) to assign.');
      return;
    }

    this.createBreakoutRoom(this.breakoutRoomData.rooms.length, 'none');
    if (this.breakoutRoomData.attendeeAllocationType.toLowerCase() === 'automatic') {
      const newRoom = this.breakoutRoomData.rooms[this.breakoutRoomData.rooms.length - 1];
      newRoom.roomParticipants = [];
      const selectedAttendee = unAssignedMembers.splice(0, this.breakoutRoomData.attendeePerBreakout);
      newRoom.roomParticipants = newRoom.roomParticipants.concat(selectedAttendee);
      newRoom.participantIds = newRoom.roomParticipants.map(x => { return x.userId }).join(',');
    }
    this.saveBreakoutRooms();
  }

  createBreakoutRoom(index: number, allocationType: AttendeeAllocationType) {
    const breakoutRoom = {
      userId: this.currentUser.userId,
      eventId: this.eventData.eventId,
      roomName: 'Breakout Room ' + (index + 1),
      allowGuestInvite: true,
      allowHandouts: true,
      allowPollsAndSurvey: true,
      allowRecording: true,
      participantIds: '',
      roomParticipants: []
    } as PrivateRoomModel;
    if (allocationType.toLowerCase() === 'automatic') {
      breakoutRoom.roomParticipants = this._distrubutedRoomsAttendee[index];
      breakoutRoom.participantIds = this._distrubutedRoomsAttendee[index].map((x: { VirtualEventUserId: any; }) => { return x.VirtualEventUserId }).join(',');
    }
    this.breakoutRoomData.rooms.push(breakoutRoom);
  }

  saveBreakoutInDB() {
    return this._roomService.createBreakoutRooms(this.breakoutRoomData);
  }

  saveBreakoutRooms() {
    this.saveBreakoutInDB().pipe(takeUntil(this._unsubscribeAll)).subscribe(res => {
      if (res) {
        this.breakoutRoomData = res;
        this.assignRoomMembers();
        if (this.breakoutRoomData) {
          this.gotoNextStep();
        }
        this.sendBreakoutSignalToMembers(null, CommandType.breakoutRoomsUpdated);
      } else {
        this._messageService.showErrorMessage('Sorry, An error occurred while creating breakout room');
      }
    });
  }

  saveBreakoutRoomSettings() {
    this.saveBreakoutInDB().pipe(takeUntil(this._unsubscribeAll)).subscribe(res => {
      if (res) {
        this._messageService.showSuccessMessage('Setting saved successfully.');
        this.sendBreakoutSignalToMembers(null, CommandType.breakoutRoomsUpdated);
      }
    });
  }

  renameBreakoutRoom(breakoutRoom) {
    breakoutRoom.enableEdit = false;
    this.saveBreakoutRooms();
  }

  deleteAllRooms() {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        Title: 'Please confirm',
        Message: 'Are you sure you want to delete selected room(s)?',
        CancelText: 'No',
        OkText: 'Yes'
      } as ConfirmDialogComponentData
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        const selectedRooms = this.breakoutRoomData.rooms.filter(x => x.checked);
        const roomIds = selectedRooms.map(x => { return x.privateRoomId });
        this._roomService.deleteBreakoutRooms(roomIds).pipe(takeUntil(this._unsubscribeAll)).subscribe(res => {
          if (res) {
            selectedRooms.forEach(breakoutRoom => {
              this.sendBreakoutSignalToMembers(breakoutRoom, CommandType.deleteBreakoutRooms);
              this.breakoutRoomData.rooms.splice(this.breakoutRoomData.rooms.indexOf(breakoutRoom), 1);
            })
            if (this.breakoutRoomData.rooms.length === 0) {
              this.goBack();
              this.allChecked = false;
              this.fillRoomArray();
            }
            this._messageService.showSuccessMessage('Selected breakout room(s) deleted successfully.');
          }
        })
      }
    });
  }

  deleteRoom(breakoutRoom: PrivateRoomModel) {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: {
        Title: 'Please confirm',
        Message: 'Are you sure you want to delete this room?',
        CancelText: 'No',
        OkText: 'Yes'
      } as ConfirmDialogComponentData
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this._roomService.deleteBreakoutRooms([breakoutRoom.privateRoomId]).pipe(takeUntil(this._unsubscribeAll)).subscribe(res => {
          if (res) {
            this.sendBreakoutSignalToMembers(breakoutRoom, CommandType.deleteBreakoutRooms);
            this.breakoutRoomData.rooms.splice(this.breakoutRoomData.rooms.indexOf(breakoutRoom), 1);
            if (this.breakoutRoomData.rooms.length === 0) {
              this.goBack();
              this.allChecked = false;
              this.fillRoomArray();
            }
            this._messageService.showSuccessMessage('Breakout room deleted successfully.');
          }
        })
      }
    });
  }

  createBreakoutRooms() {
    this.breakoutRoomData.rooms = [];
    if (this.breakoutRoomData.attendeePerBreakout > 0) {
      for (let index = 0; index < this.roomNumber; index++) {
        this.createBreakoutRoom(index, this.breakoutRoomData.attendeeAllocationType);
      }
      this.saveBreakoutRooms();
    } else {
      this._messageService.showErrorMessage('Please assign some attendees.');
    }
  }

  openManageAttendeePopup(breakout: PrivateRoomModel) {
    this.dialog.open(ManageAttendeeComponent, {
      panelClass: 'manage-attendees-dialog',
      data: { unAssignedAttendeeIds: this.getUnassignedAttendeeIds(), callFor: 'breakoutRooms' }
    }).afterClosed().pipe(takeUntil(this._unsubscribeAll)).subscribe(res => {
      if (res && res.length) {
        if (!breakout.roomParticipants) { breakout.roomParticipants = []; }
        res.forEach((member: { userId: number; }) => {
          const em = this.filteredAttendees.find(x => x.userId === member.userId);
          if (em) {
            breakout.roomParticipants.push(em);
            breakout.participantIds = breakout.roomParticipants.map(x => { return x.userId }).join(',');
          }
        });
        this._spinnerService.show('spinner-breakout');
        this.saveBreakoutInDB().pipe(takeUntil(this._unsubscribeAll)).subscribe(res => {
          if (res) {
            this.assignRoomMembers();
            this._spinnerService.hide('spinner-breakout');
            this.sendBreakoutSignalToMembers(null, CommandType.breakoutRoomsUpdated);
          } else {
            this._messageService.showErrorMessage('Sorry, An error occurred while creating breakout room');
          }
        }, (err) => { this._spinnerService.hide(); });
      }
    });
  }

  assignRoomMembers() {
    this.breakoutRoomData.rooms.forEach(room => {
      room.userId = this.currentUser.userId;
      if (room.participantIds) {
        const ids = room.participantIds.split(',').map(x => { return parseInt(x) });
        room.roomParticipants = this._attendees.filter((x) => ids.indexOf(x.userId) !== -1 && x.isOnline());
      }
    })
  }

  updateAllComplete() {
    this.allChecked = this.breakoutRoomData.rooms != null && this.breakoutRoomData.rooms.every(t => t.checked);
  }

  setAll(checked: boolean) {
    this.allChecked = checked;
    if (this.breakoutRoomData.rooms == null) {
      return;
    }
    this.breakoutRoomData.rooms.forEach(t => { t.checked = checked });
  }

  someChecked(): boolean {
    if (this.breakoutRoomData.rooms == null) {
      return false;
    }
    return this.breakoutRoomData.rooms.filter(t => t.checked).length > 0 && !this.allChecked;
  }

  async removeParticipant(participant: UserModel, breakoutRoom: PrivateRoomModel): Promise<void> {
    const signalDataModel = {
      receiverId: participant.userId,
      command: CommandType.removeBreakoutAttendee,
      signalLevel: SignalLevel.person,
      data: { extra: breakoutRoom.privateRoomId } as SignalDataContent
    } as SignalDataModel;
    await this._signalrService.sendSignal(signalDataModel);
    breakoutRoom.roomParticipants.splice(breakoutRoom.roomParticipants.indexOf(participant), 1);
    breakoutRoom.participantIds = breakoutRoom.roomParticipants.map(x => { return x.userId }).join(',');
    this.saveBreakoutRooms();
    this._messageService.showSuccessMessage('Attendee removed successfully.');
  }

  async broadcastMessageToBreakoutRooms(): Promise<void> {
    if (!this.broadcastMessage) {
      this._messageService.showErrorMessage('Please enter message!!');
      return;
    }

    const roomIds = this.breakoutRoomData.rooms.filter(r => r.checked).map(x => { return x.privateRoomId });
    if (!roomIds.length) {
      this._messageService.showErrorMessage('Please select a room first!!');
      return;
    }

    const signalDataModel = {
      receiverType: EnumRoomType.breakout,
      command: CommandType.messageToBreakoutRooms,
      signalLevel: SignalLevel.room,
      data: { extra: this.broadcastMessage } as SignalDataContent
    } as SignalDataModel;
    roomIds.forEach(async r => {
      signalDataModel.receiverId = r;
      await this._signalrService.sendSignal(signalDataModel);
    });
    this._messageService.showSuccessMessage('Message broadcasted to selected room(s)!!');
    this.broadcastMessage = '';
  }

  async sendBreakoutSignalToMembers(breakoutRoom: PrivateRoomModel, commandType: CommandType): Promise<void> {
    const hostCohostIds = this._eventService.getHostOrCohostIds();
    let memberIds = [];
    let breakoutRoomId = 0;
    let breakoutRoomName = '';
    if (breakoutRoom && breakoutRoom.participantIds.length) {
      memberIds = breakoutRoom.participantIds.split(',').map(m => parseInt(m));
      breakoutRoomId = breakoutRoom.privateRoomId;
      breakoutRoomName = breakoutRoom.roomName;
    }
    let participantIds = memberIds.concat(hostCohostIds);
    if (commandType === CommandType.breakoutRoomsUpdated) {
      // Skip receiving signal for current user while updating breakout room by self
      participantIds = participantIds.filter(i => i !== this.currentUser.userId);
    }
    if (commandType === CommandType.deleteBreakoutRooms) {
      // Skip receiving signal for current user for all other action than deleteBreakoutRooms
      participantIds = participantIds.filter(i => i !== this.currentUser.userId);
    }
    const data = {
      receiverIds: participantIds,
      command: commandType,
      signalLevel: SignalLevel.persons,
      data: {
        roomId: breakoutRoomId,
        roomName: breakoutRoomName,
        extra: this.currentUser.getFullName()
      }
    } as SignalDataModel;
    await this._signalrService.sendSignalToUsers(data);
  }
}
