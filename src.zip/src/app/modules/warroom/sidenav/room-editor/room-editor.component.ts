import { KeyValue } from '@angular/common';
import { ChangeDetectorRef, Component, OnInit, ViewEncapsulation, Input, OnDestroy } from '@angular/core';
import { AbstractControl, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NgxDropzoneChangeEvent } from 'ngx-dropzone';
import { NgxSpinnerService } from 'ngx-spinner';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { FwSidebarComponent } from 'src/app/core/components/sidebar/sidebar.component';
import { FwSidebarService } from 'src/app/core/components/sidebar/sidebar.service';
import { RoomModel, RoomImageType as RoomImageType } from 'src/app/modules/rooms/room/room.models';
import { RoomService } from 'src/app/modules/rooms/room/room.service';
import { UserModel } from 'src/app/shared/models/user.model';
import { EventModel, EventScheduleModel, ImageViewModel } from 'src/app/shared/models/event.model';
import { CommandType, SignalDataModel, SignalLevel } from 'src/app/shared/models/signalr.models';
import { EventService } from 'src/app/shared/services/event.service';
import { MessageService } from 'src/app/shared/services/message.service';
import { SharedService } from 'src/app/shared/services/shared.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import { ImageService } from 'src/app/shared/services/image.service';

export type RoomEditorViewSections = 'editor' | 'attendees' | 'chats' | 'schedule';


@Component({
  selector: 'fw-room-editor',
  templateUrl: './room-editor.component.html',
  styleUrls: ['./room-editor.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class RoomEditorComponent implements OnInit, OnDestroy {
  @Input() currentUser: UserModel;
  @Input() roomData: RoomModel
  eventData: EventModel;
  schedules: EventScheduleModel[];
  WELCOME_MSG_MAX_LENGTH = 256;
  activeSection: RoomEditorViewSections = 'editor';
  sidebarInstance: FwSidebarComponent;

  resourceBaseUrl: string;

  roomImage: File;
  logoImage: File;
  thumbImage: File;
  backgroundImage: File;

  roomImageModified: boolean;
  logoImageModified: boolean;
  thumbImageModified: boolean;
  backgroundImageModified: boolean;

  roomEditorForm: FormGroup;
  submitted = false;
  videoSources: KeyValue<string, string>[] = [
    { value: 'Eventcombo', key: 'eventcombo' },
    { value: 'Youtube', key: 'youtube' },
    { value: 'Vimeo', key: 'vimeo' },
    { value: 'Wistia', key: 'wistia' },
    { value: 'Sprout Video', key: 'sprout_video' },
    { value: 'Bigmarker', key: 'bigmarker' },
  ];
  roomTypes: KeyValue<string, string>[] = [
    { value: 'Stage', key: 'stage' },
    { value: 'Keynote', key: 'keynoteroom' },
    { value: 'Green Room', key: 'greenroom' },
    { value: 'Expo', key: 'expo_booth' },
    { value: 'Session', key: 'session_booth' },
    { value: 'Networking', key: 'networking_booth' },
    { value: 'Custom Room', key: 'customroom' }
  ];

  private _unsubscribeAll: Subject<any> = new Subject();

  constructor(
    private _formBuilder: FormBuilder,
    private _changeDetectorRef: ChangeDetectorRef,
    private _spinnerService: NgxSpinnerService,
    private _messageService: MessageService,
    private _eventService: EventService,
    private _roomService: RoomService,
    private _sidebarService: FwSidebarService,
    private _signalrService: SignalrService,
    private _sharedService: SharedService,
    private _settingService: AppSettingService,
    private _imageService: ImageService
  ) {
    this.resourceBaseUrl = this._settingService.settings.resourceBaseUrl;
  }

  ngOnInit(): void {

    this.sidebarInstance = this._sidebarService.getSidebar('warRoomSidenav');

    this._eventService.event$
      .pipe(takeUntil(this._unsubscribeAll)).subscribe(data => {
        this.eventData = data;
        this._changeDetectorRef.markForCheck();
      });

    this._eventService.schedules$
      .pipe(takeUntil(this._unsubscribeAll)).subscribe(data => {
        this.schedules = data;
        this._changeDetectorRef.markForCheck();
      });

    if (!this.roomData) {
      this.roomData = new RoomModel();
    } else {
      this.roomData.logoImage = this.roomData.logoImage ?? new ImageViewModel();
      this.roomData.thumbImage = this.roomData.thumbImage ?? new ImageViewModel();
      this.roomData.roomImage = this.roomData.roomImage ?? new ImageViewModel();
      this.roomData.backgroundImage = this.roomData.backgroundImage ?? new ImageViewModel();
    }

    this.prepareRoomImages();

    this.roomEditorForm = this._formBuilder.group({
      roomName: [this.roomData.roomName],
      roomType: [this.roomData.roomType, Validators.required],

      description: [this.roomData.description, [
        Validators.required,
        Validators.minLength(2),
        Validators.maxLength(2000)
      ]],
      mediaType: [this.roomData.mediaType, Validators.required],
      videoSource: [this.roomData.videoSource, Validators.required],
      videoSourceUrl: [this.roomData.videoUrl],
      whoCanJoin: [this.roomData.whoCanJoin, [Validators.required]],

      settings: this._formBuilder.group({
        attendeeViewEnabled: [this.roomData.settings.attendeeViewEnabled],
        attendeesCountEnabled: [this.roomData.settings.attendeesCountEnabled],
        autoPlayEnabled: [this.roomData.settings.autoPlayEnabled],
        backgroundImageEnabled: [this.roomData.settings.backgroundImageEnabled],
        canAttendeePlayVideo: [this.roomData.settings.canAttendeePlayVideo],
        groupChatEnabled: [this.roomData.settings.groupChatEnabled],
        guestInviteEnabled: [this.roomData.settings.guestInviteEnabled],
        handoutsEnabled: [this.roomData.settings.handoutsEnabled],
        isAllowedToJoinRoom: [this.roomData.settings.isAllowedToJoinRoom],
        oneToOneNetworkingEnabled: [this.roomData.settings.oneToOneNetworkingEnabled],
        peopleSectionEnabled: [this.roomData.settings.peopleSectionEnabled],
        pollsAndSurveyEnabled: [this.roomData.settings.pollsAndSurveyEnabled],
        boardBackgroundColor: [this.roomData.settings.boardBackgroundColor]
      }),

      logoImage : [this.roomData.logoImage],
      thumbImage : [this.roomData.thumbImage],
      roomImage : [this.roomData.roomImage],
      backgroundImage : [this.roomData.backgroundImage]

    });

    this.registerFormControlEvents(this.roomEditorForm);

    this._sharedService.setThemeColor(this.roomData.settings.boardBackgroundColor);
  }

  private prepareRoomImages() {
    if (this.roomData.backgroundImage && this.roomData.backgroundImage.imageId) {
      let url = this.roomData.backgroundImage.imagePath;
      if (url) {
        url = this.resourceBaseUrl + url;
        fetch(url).then(async (res) => {
          if (res) {
            const blob = await res.blob();
            if (blob.size) {
              this.backgroundImage = blob as File;
            }
          }
        });
      }
    }

    if (this.roomData.roomImage && this.roomData.roomImage.imageId) {
      let url = this.roomData.roomImage.imagePath;
      if (url) {
        url = this.resourceBaseUrl + url;
        fetch(url).then(async (res) => {
          if (res) {
            const blob = await res.blob();
            if (blob.size) {
              this.roomImage = blob as File;
            }
          }
        });
      }
    }
  }

  private registerFormControlEvents(roomEditorForm: FormGroup) {

    let mediaTypeControl = roomEditorForm.get('mediaType');
    let videoSourceControl = roomEditorForm.get('videoSource');
    let videoSourceUrlControl = roomEditorForm.get('videoSourceUrl');
    let roomTypeControl = roomEditorForm.get('roomType');

    setVideoSourceDataForEventcombo();

    mediaTypeControl.valueChanges.subscribe(val => {
      if (val == 'video' && videoSourceControl.value != 'eventcombo') {
        videoSourceUrlControl.setValidators([Validators.required]);
      } else {
        videoSourceUrlControl.clearValidators();
      }
      videoSourceUrlControl.updateValueAndValidity();

      setVideoSourceDataForEventcombo();
    });

    videoSourceControl.valueChanges.subscribe(val => {
      if (val !== 'eventcombo') {
        videoSourceUrlControl.setValidators([Validators.required]);
      } else {
        videoSourceUrlControl.clearValidators();
      }
      videoSourceUrlControl.updateValueAndValidity();

      setVideoSourceDataForEventcombo();
    });

    function setVideoSourceDataForEventcombo() {
      if (videoSourceControl.value == 'eventcombo') {
        videoSourceUrlControl.setValue('URL will be auto generated by system');
        videoSourceUrlControl.disable();
      } else {
        videoSourceUrlControl.setValue('');
        videoSourceUrlControl.enable();
      }
    }

    if (this.roomData && this.roomData.roomType) {
      roomTypeControl.disable();
    }

    roomTypeControl.valueChanges.subscribe(val => {

    });
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  get f(): { [key: string]: AbstractControl } {
    return this.roomEditorForm.controls;
  }

  async onSubmit($event): Promise<void> {
    $event.preventDefault();
    this._spinnerService.hide();
    this.submitted = true;
    if (this.roomEditorForm.invalid) {
      return;
    }
    this._spinnerService.show();
    let payload = this.roomEditorForm.value as RoomModel;
    payload.settings.boardBackgroundColor = this.roomData.settings.boardBackgroundColor;
    payload.roomId = this.roomData.roomId;

    payload.logoImage.file = this.logoImage;
    payload.logoImage.isModified = this.logoImageModified;

    payload.thumbImage.file = this.thumbImage;
    payload.thumbImage.isModified = this.thumbImageModified;

    payload.roomImage.file = this.roomImage;
    payload.roomImage.isModified = this.roomImageModified;

    payload.backgroundImage.file = this.backgroundImage;
    payload.backgroundImage.isModified = this.backgroundImageModified;

    let formData = new FormData()

    this._roomService.updateRoomData(payload).pipe(takeUntil(this._unsubscribeAll)).subscribe({
      next: (status) => {
        if (status) {
          this._messageService.showSuccessMessage('Room Settings updated successfully.');
          this._spinnerService.hide();
          const signalDataModel = {
            command: CommandType.roomDataUpdated,
            signalLevel: SignalLevel.event,
            data: {}
          } as SignalDataModel;
          this._signalrService.sendSignal(signalDataModel).then(res => {
            this._eventService.getSchedules().pipe(takeUntil(this._unsubscribeAll)).subscribe();
            this._eventService.getRooms().pipe(takeUntil(this._unsubscribeAll)).subscribe();
            this._eventService.getHandouts().pipe(takeUntil(this._unsubscribeAll)).subscribe();
          });
        } else {
          this._spinnerService.hide();
          this._messageService.showErrorMessage('Sorry!, An error occurred while updating room settings.');
        }
      },
      error: (err) => {
        this._spinnerService.hide();
        this._messageService.showErrorMessage('Sorry!, An error occurred while updating room settings.');
      }
    });
  }

  async onImageUpload(event: NgxDropzoneChangeEvent, type: RoomImageType) {
    if (event.addedFiles && event.addedFiles.length) {
      const reader = new FileReader();
      const file = event.addedFiles[0];
      reader.readAsDataURL(file);
      reader.onload = async () => {
        if (type == 'roomImage') {
          this.roomImage = file;
          this.thumbImageModified = true;
        } else if (type == 'logoImage') {
          this.logoImage = file;
          this.logoImageModified = true;
        } else if (type == 'backgroundImage') {
          this.backgroundImage = file;
          this.backgroundImageModified = true;
        } else if (type == 'thumbImage') {
          this.thumbImage = file;
          this.thumbImageModified = true;
        }
      };
    }
  }

  async onRemoved(type: RoomImageType): Promise<void> {
    if (type == 'roomImage') {
      this.roomImage = null;
      this.thumbImageModified = true;
    } else if (type == 'logoImage') {
      this.logoImage = null;
      this.logoImageModified = true;
    } else if (type == 'backgroundImage') {
      this.backgroundImage = null;
      this.backgroundImageModified = true;
    } else if (type == 'thumbImage') {
      this.thumbImage = null;
      this.thumbImageModified = true;
    }
  }

  editorOptions = {
    toolbar: [
      ['bold', 'italic', 'underline'],
      [{ 'list': 'ordered' }, { 'list': 'bullet' }, { 'align': [] }],
      [{ 'background': [] }, { 'color': [] }],
      [{ 'header': [1, 2, 3, 4, 5, 6, false] },]
    ]
  }

  textChanged($event) {
    if ($event.editor.getLength() > this.WELCOME_MSG_MAX_LENGTH) {
      $event.editor.deleteText(this.WELCOME_MSG_MAX_LENGTH, $event.editor.getLength());
    }
  }

  activateRoomSection(section: RoomEditorViewSections): void {
    this.activeSection = section;
  }

  closeSidebar(): void {
    this.sidebarInstance.close();
  }

  onColorChange($event: any) {
    this.roomData.settings.boardBackgroundColor = $event;
    this._sharedService.setThemeColor(this.roomData.settings.boardBackgroundColor);
  }
}