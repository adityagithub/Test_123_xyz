import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { ChangeDetectorRef, Component, OnInit, ViewEncapsulation, Input, OnChanges, SimpleChanges, OnDestroy } from '@angular/core';
import { AbstractControl, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatChipEditedEvent, MatChipInputEvent } from '@angular/material/chips';
import { NgxDropzoneChangeEvent } from 'ngx-dropzone';
import { NgxSpinnerService } from 'ngx-spinner';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { FwSidebarComponent } from 'src/app/core/components/sidebar/sidebar.component';
import { FwSidebarService } from 'src/app/core/components/sidebar/sidebar.service';
import { UserModel } from 'src/app/shared/models/user.model';
import { EventModel, EventScheduleModel, EventSpeakerModel, EventSponsorModel } from 'src/app/shared/models/event.model';
import { CommandType, SignalDataModel, SignalLevel } from 'src/app/shared/models/signalr.models';
import { EventService } from 'src/app/shared/services/event.service';
import { MessageService } from 'src/app/shared/services/message.service';
import { SignalrService } from 'src/app/shared/services/signalr.service';

export type EventEditorViewSections = 'editor' | 'attendees' | 'chats' | 'schedule';

@Component({
  selector: 'fw-event-editor',
  templateUrl: './event-editor.component.html',
  styleUrls: ['./event-editor.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class EventEditorComponent implements OnInit, OnDestroy {
  @Input() currentUser: UserModel;
  @Input() eventData: EventModel;
  speakers: EventSpeakerModel[];
  sponsors: EventSponsorModel[];
  schedules: EventScheduleModel[];

  profileImgFile: File;
  eventForm: FormGroup;
  submitted = false;
  sidebarInstance: FwSidebarComponent;
  activeSection: EventEditorViewSections = 'editor';
  readonly separatorKeysCodes = [ENTER, COMMA] as const;
  chatBlockingWords: string[];

  attendeeEditable: boolean = false;
  scheduleEditable: boolean = false;
  speakerEditable: boolean = false;
  sponsorEditable: boolean = false;

  private _unsubscribeAll: Subject<any> = new Subject();

  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _eventService: EventService,
    private _spinnerService: NgxSpinnerService,
    private _messageService: MessageService,
    private _sidebarService: FwSidebarService,
    private _signalrService: SignalrService) {

  }

  ngOnInit(): void {

    this.sidebarInstance = this._sidebarService.getSidebar('warRoomSidenav');

    this._eventService.event$
      .pipe(takeUntil(this._unsubscribeAll)).subscribe(data => {
        this.eventData = data;
        this.chatBlockingWords = this.eventData.settings?.chatBlockingWords?.split(',') ?? [];
        this._changeDetectorRef.markForCheck();
      });

    this._eventService.speakers$
      .pipe(takeUntil(this._unsubscribeAll)).subscribe(data => {
        this.speakers = data;
        this._changeDetectorRef.markForCheck();
      });

    this._eventService.sponsors$
      .pipe(takeUntil(this._unsubscribeAll)).subscribe(data => {
        this.sponsors = data;
        this._changeDetectorRef.markForCheck();
      });

    this._eventService.schedules$
      .pipe(takeUntil(this._unsubscribeAll)).subscribe(data => {
        this.schedules = data;
        this._changeDetectorRef.markForCheck();
      });
  }


  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }


  async onSubmit(event: any): Promise<void> {
    this.submitted = true;
    this._spinnerService.show();
    this.eventData.settings.chatBlockingWords = this.chatBlockingWords?.join();
    this._eventService.updateEventData(this.eventData).pipe(takeUntil(this._unsubscribeAll)).subscribe(status => {
      if (status) {
        this._messageService.showSuccessMessage('Event Settings updated successfully.');
        this._spinnerService.hide();
        const signalDataModel = {
          command: CommandType.eventDataUpdated,
          signalLevel: SignalLevel.event,
          data: {}
        } as SignalDataModel;
        this._signalrService.sendSignal(signalDataModel).then(res => {
          this._eventService.getEvent().pipe(takeUntil(this._unsubscribeAll)).subscribe();
          this._eventService.getSchedules().pipe(takeUntil(this._unsubscribeAll)).subscribe();
          this._eventService.getRooms().pipe(takeUntil(this._unsubscribeAll)).subscribe();
          this._eventService.getHandouts().pipe(takeUntil(this._unsubscribeAll)).subscribe();
        });
      } else {
        this._spinnerService.hide();
        this._messageService.showSuccessMessage('Sorry!, An error occurred while updating event settings.');
      }
    });
  }

  async onImageUpload(event: NgxDropzoneChangeEvent) {
    if (event.addedFiles && event.addedFiles.length) {
      const reader = new FileReader();
      const file = event.addedFiles[0];
      reader.readAsDataURL(file);
      reader.onload = () => {
        this.profileImgFile = file;
      };
    }
  }

  async deleteImage(): Promise<void> {
    // TODO
    //this.personalInfoPicName = '';
  }

  async onRemoved(event: any): Promise<void> {
    this.profileImgFile = null;
  }

  closeSidebar(): void {
    this.sidebarInstance.close();
  }


  activateEventSection(section: EventEditorViewSections): void {
    this.activeSection = section;
    this._changeDetectorRef.markForCheck();
  }

  addBlockingWord(event: MatChipInputEvent): void {
    const value = (event.value || '').trim();

    // Add our word
    if (value) {
      let index = this.chatBlockingWords.indexOf(value);
      if (index == -1) {
        this.chatBlockingWords.push(value);
      }
    }

    // Clear the input value
    event.chipInput!.clear();
  }

  removeBlockingWord(word: any): void {
    const index = this.chatBlockingWords.indexOf(word);

    if (index >= 0) {
      this.chatBlockingWords.splice(index, 1);
    }
  }

  editBlockingWord(word: any, event: MatChipEditedEvent) {
    const value = event.value.trim();

    // Remove word if it no longer has a name
    if (!value) {
      this.removeBlockingWord(word);
      return;
    }

    // Edit existing word
    const index = this.chatBlockingWords.indexOf(word);
    if (index >= 0) {
      this.chatBlockingWords[index] = value;
    }
  }

  toggleAttendeeEditable(input: HTMLInputElement) {
    this.attendeeEditable = !this.attendeeEditable;
    if (this.attendeeEditable) {
      input.focus();
    } else {
      input.blur();
    }
  }

  toggleScheduleEditable(input: HTMLInputElement) {
    this.scheduleEditable = !this.scheduleEditable;
    if (this.scheduleEditable) {
      input.focus();
    } else {
      input.blur();
    }
  }

  toggleSponsorEditable(input: HTMLInputElement) {
    this.sponsorEditable = !this.sponsorEditable;
    if (this.sponsorEditable) {
      input.focus();
    } else {
      input.blur();
    }
  }

  toggleSpeakerEditable(input: HTMLInputElement) {
    this.speakerEditable = !this.speakerEditable;
    if (this.speakerEditable) {
      input.focus();
    } else {
      input.blur();
    }
  }
}
