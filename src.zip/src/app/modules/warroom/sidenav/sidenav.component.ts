import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { appAnimations } from 'src/app/core/animations';
import { WarroomService } from '../warroom.service';
import { FwSidebarService } from 'src/app/core/components/sidebar/sidebar.service';
import { FwSidebarComponent } from 'src/app/core/components/sidebar/sidebar.component';

@Component({
  selector: 'warroom-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: appAnimations
})
export class WarRoomSidenavComponent implements OnInit, OnDestroy {
 
  view: string;
  viewData: any;
  sidebarInstance: FwSidebarComponent;

  private _unsubscribeAll: Subject<any> = new Subject();

  constructor(
    private _warroomService: WarroomService,
    private _sidebarService: FwSidebarService
  ) {

  }

  ngOnInit(): void {
    this.sidebarInstance = this._sidebarService.getSidebar('warRoomSidenav');
    this._warroomService.onViewChange$
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((res) => {
        this.view = res.view;
        this.viewData = res.viewData;        
      });

    this.sidebarInstance.openedChanged.pipe(takeUntil(this._unsubscribeAll))
      .subscribe(opened => {
        if (!opened) {
          this.resetView();
        }
      })
  }


  closeSidebar(): void {
    this.sidebarInstance.close();
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  resetView(): void {
    this.view = undefined
    this.viewData = undefined;
  }
}
