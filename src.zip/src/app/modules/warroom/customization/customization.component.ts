import {
  Component,
  OnDestroy, OnInit,
  ViewEncapsulation
} from '@angular/core'
import { Subject, takeUntil } from 'rxjs'
import { appAnimations } from 'src/app/core/animations'
import { BrandingModel, CustomizationImageType } from './customization.models'
import { CustomizationService } from './customization.service'
import { EventService } from 'src/app/shared/services/event.service'
import { NgxDropzoneChangeEvent } from 'ngx-dropzone'
import { CommandType, SignalDataModel, SignalLevel } from 'src/app/shared/models/signalr.models'
import { MessageService } from 'src/app/shared/services/message.service'
import { NgxSpinnerService } from 'ngx-spinner'
import { SignalrService } from 'src/app/shared/services/signalr.service'
import { AppSettingService, AppSettings } from 'src/app/shared/services/appsetting.service'
import { RoomService } from '../../rooms/room/room.service'
import { MatDialog } from '@angular/material/dialog'
import { ConfirmDialogComponent } from 'src/app/core/components/confirm-dialog/confirm-dialog.component'
import { ConfirmDialogComponentData } from 'src/app/core/components/confirm-dialog/confirm.dialog.models'

@Component({
  selector: 'fw-customization',
  templateUrl: './customization.component.html',
  styleUrls: ['./customization.component.scss'],
  encapsulation: ViewEncapsulation.None,
  animations: appAnimations
})
export class CustomizationComponent implements OnInit, OnDestroy {
  private _unsubscribeAll: Subject<any> = new Subject();

  selectedBranding: string;
  currentBranding: BrandingModel;

  faviconMaxSize: number = 4 * 1024 * 1024; // 4MB, will be optimized by system on upload
  faviconFile: File;

  logoImageMaxSize: number = 4 * 1024 * 1024; // 4MB, will be optimized by system on upload
  logoImageFile: File;

  roomBgImageMaxSize: number = 4 * 1024 * 1024; // 4MB, will be optimized by system on upload
  roomDefaultImageFile: File;

  standbyImageMaxSize: number = 4 * 1024 * 1024; // 4MB, will be optimized by system on upload
  standbyDefaultImageFile: File;

  formSubmitted: boolean;
  appSettings: AppSettings;
  swithBackToDefault: string = 'N';  
  openInDialog: boolean;

  constructor(
    private _customizationService: CustomizationService,
    private _eventService: EventService,
    private _roomService: RoomService,
    private _messageService: MessageService,
    private _spinnerService: NgxSpinnerService,
    private _signalrService: SignalrService,
    private _matDialog: MatDialog
  ) {

  }

  async ngOnInit(): Promise<void> {
    if (!this.openInDialog) {
      this._roomService.getRoomDetails(0).pipe(takeUntil(this._unsubscribeAll)).subscribe();
    }
    await this.init();
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  async onImageUpload(event: NgxDropzoneChangeEvent, type: CustomizationImageType) {

    if (event.rejectedFiles?.length) {
      if (event.rejectedFiles[0].reason == 'size') {
        this._messageService.showErrorMessage('Sorry, Max 4MB file size allowed!');
      }
      if (event.rejectedFiles[0].reason == 'type') {
        this._messageService.showErrorMessage('Sorry, This file type is not supported!');
      }
    }

    if (event.addedFiles?.length) {

      const file = event.addedFiles[0];
      if (type == 'favicon') {
        const conpressed = await this.compressImage(file, 64, 64);
        this.faviconFile = conpressed;
      } else if (type == 'logo') {
        const conpressed = await this.compressImage(file, 256, 192);
        this.logoImageFile = conpressed;
      } else if (type == 'room-background') {
        const conpressed = await this.compressImage(file, 384, 256);
        this.roomDefaultImageFile = conpressed;
      } else if (type == 'standby') {
        const conpressed = await this.compressImage(file, 384, 256);
        this.standbyDefaultImageFile = conpressed;
      }
    }
  }

  async onRemoved(event: any, type: CustomizationImageType): Promise<void> {
    if (type == 'favicon') {
      this.faviconFile = null;
    } else if (type == 'logo') {
      this.logoImageFile = null;
    } else if (type == 'room-background') {
      this.roomDefaultImageFile = null;
    } else if (type == 'standby') {
      this.standbyDefaultImageFile = null;
    }
  }

  async compressImage(file: File, maxWidth: number, maxHeight: number): Promise<File> {
    const src = await this.toBase64(file) as string;
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.src = src;
      img.onload = () => {

        var width = img.width;
        var height = img.height;

        if (width > height) {
          if (width > maxWidth) {
            height = height * (maxWidth / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = width * (maxHeight / height);
            height = maxHeight;
          }
        }

        const elem = document.createElement('canvas');
        elem.width = width;
        elem.height = height;
        const ctx = elem.getContext('2d');
        ctx.drawImage(img, 0, 0, width, height);
        const data = ctx.canvas.toDataURL();
        fetch(data).then(async res => {
          const blob = await res.blob();
          resolve(blob as File);
        });
      }
      img.onerror = error => reject(error);
    })
  }

  toBase64 = file => new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
  });


  async onSubmit(): Promise<void> {

    this.formSubmitted = true;
    this._spinnerService.show();

    try {

      if (!this.trademarkText) {
        this.trademarkText = '';
      }

      var formData = new FormData();
      formData.append('faviconFile', this.faviconFile);
      formData.append('logoImageFile', this.logoImageFile);
      formData.append('roomBackgroundImageFile', this.roomDefaultImageFile);
      formData.append('standbyBackgroundImageFile', this.standbyDefaultImageFile);
      formData.append('trademarkText', this.trademarkText);
      formData.append('switchBackToDefault', this.swithBackToDefault);

      let response = await this._customizationService.updateCustomizationDetail(formData);
      if (response) {
        this._spinnerService.hide();
        this._messageService.showSuccessMessage('Data updated successfully.');
        const signalData = {
          command: CommandType.customizationByHostCohost,
          receiverId: this._eventService.getEventId(),
          signalLevel: SignalLevel.event,
          data: {}
        } as SignalDataModel;
        await this._signalrService.sendSignal(signalData);
      } else {
        this._spinnerService.hide();
        this._messageService.showErrorMessage('Sorry!, An error occurred while updating the settings.');
      }
    } catch (error) {
      this._spinnerService.hide();
      this._messageService.showErrorMessage('Sorry!, An error occurred while updating the settings.');
    }
  }

  faviconUrl: string;
  logoImageUrl: string;
  roomBgImageUrl: string;
  standbyImageUrl: string;
  trademarkFileUrl: string;
  trademarkText: string;

  async init(): Promise<void> {

    try {
      this.faviconUrl = this._customizationService.getCustomizedFaviconUrl();
      let res = await fetch(this.faviconUrl, { mode: "no-cors" });
      if (res) {
        let data = await res.blob();
        if (data.size) {
          this.faviconFile = data as File;
        }
      }
    } catch (e) {

    }

    try {
      this.logoImageUrl = this._customizationService.getCustomizedLogoImageUrl();
      let res = await fetch(this.logoImageUrl, { mode: "no-cors" });
      if (res) {
        let data = await res.blob();
        if (data.size) {
          this.logoImageFile = data as File;
        }
      }
    } catch (e) {

    }

    try {
      this.roomBgImageUrl = this._customizationService.getCustomizedRoomImageUrl();
      let res = await fetch(this.roomBgImageUrl, { mode: "no-cors" });
      if (res) {
        let data = await res.blob();
        if (data.size) {
          this.roomDefaultImageFile = data as File;
        }
      }
    } catch (e) {

    }

    try {
      this.standbyImageUrl = this._customizationService.getCustomizedStandbyImageUrl();
      let res = await fetch(this.standbyImageUrl, { mode: "no-cors" });
      if (res) {
        let data = await res.blob();
        if (data.size) {
          this.standbyDefaultImageFile = data as File;
        }
      }
    } catch (e) {

    }

    try {
      this.trademarkFileUrl = this._customizationService.getCustomizedTrademarkFileUrl();
      let res = await fetch(this.trademarkFileUrl, { mode: "no-cors" });
      if (res) {
        let data = await res.text();
        if (data.length) {
          this.trademarkText = data;
        }
      }
    } catch (e) {

    }
  }

  resetToDefault(): void {
    const dialogRef = this._matDialog.open(ConfirmDialogComponent, {
      data: {
        Title: 'Please confirm',
        Message: 'The customized images will be removed and switch back to defaut?',
        CancelText: 'No, Cancel',
        OkText: 'Yes, Reset'
      } as ConfirmDialogComponentData
    })
    dialogRef.afterClosed().subscribe(async (result: boolean) => {
      if (result) {
        this.faviconFile = null;
        this.logoImageFile = null;
        this.roomDefaultImageFile = null;
        this.standbyDefaultImageFile = null;
        this.trademarkFileUrl = null;
        this.trademarkText = 'Fireworks';
        this.swithBackToDefault = 'Y';
        await this.onSubmit();
        await this.init();
      } else {
        this.swithBackToDefault = 'N';
      }
    })
  }
}