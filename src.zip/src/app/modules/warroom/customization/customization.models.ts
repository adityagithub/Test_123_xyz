
export class BrandingModel {
    id: number;
    type: string;
    title: string;
    description: string;
    class: string;
    cols: number;
    rows: number;
    x:number;
    y:number;
    component: string;
    selected: boolean;
    logoUrl: string;
}


export type CustomizationImageType = 'favicon' | 'logo' | 'room-background' | 'expo-background' | 'standby';