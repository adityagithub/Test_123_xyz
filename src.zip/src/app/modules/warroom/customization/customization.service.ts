import { Inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { ApiResponse } from 'src/app/shared/models/shared.model';
import { CustomizationInfo } from 'src/app/shared/models/event.model';
import { DOCUMENT } from '@angular/common';
import { Title } from '@angular/platform-browser';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';
import { EventService } from 'src/app/shared/services/event.service';

@Injectable({ providedIn: 'root' })
export class CustomizationService {
  private _customizationInfo: CustomizationInfo;
  private _customization: BehaviorSubject<CustomizationInfo | null> = new BehaviorSubject(null);

  customizationBaseUrl: string;
  paramEventId: string;

  constructor(
    private _httpClient: HttpClient,
    @Inject(DOCUMENT) private _document: Document,
    private _titleService: Title,
    private _settingService: AppSettingService,
    private _eventService: EventService
  ) {
    this.customizationBaseUrl = this._settingService.settings.baseUrl + '/Uploads/Customization/';
    this._customizationInfo = new CustomizationInfo();
  }

  getCustomizationDetail(): Promise<CustomizationInfo> {
    this.paramEventId = this._eventService.getEventId().toString();
    return new Promise(async (resolve, reject) => {
      try {
        await this.prepareCustomizationInfo();
        this._customization.next(this._customizationInfo);
        resolve(this._customizationInfo);
      } catch (e) {
        reject(e);
      }
    })
  }

  updateCustomizationDetail(form: FormData): Promise<CustomizationInfo> {
    return new Promise((resolve, reject) => {
      this._httpClient.post<ApiResponse<CustomizationInfo>>('api/event/customize', form)
        .subscribe({
          next: async (res) => {
            if (res.data) {
              await this.prepareCustomizationInfo();
              this._customization.next(this._customizationInfo);
              resolve(res.data);
            }
          },
          error: (err) => {
            reject(err);
          }
        })
    })
  }

  get customization$(): Observable<CustomizationInfo> {
    return this._customization.asObservable();
  }


  documentExists(doc_url: string) {
    try {
      var http = new XMLHttpRequest();
      http.open('HEAD', doc_url, false);
      http.send();
      return http.status != 404;
    } catch (e) {
      return false;
    }
  }

  private get _faviconUrl(): string { return 'favicon.ico?dt=' + new Date().getTime().toString(); }
  private get _logoImageUrl(): string { return 'assets/images/logos/fireworks.png?dt=' + new Date().getTime().toString(); }
  private get _roomBgImageUrl(): string { return 'assets/images/default_room.png?dt=' + new Date().getTime().toString(); }
  private get _standbyImageUrl(): string { return 'assets/images/fw-standby.png?dt=' + new Date().getTime().toString(); }
  private get _trademarkFileUrl(): string { return 'assets/images/trademark.txt?dt=' + new Date().getTime().toString(); }

  faviconUrl: string;
  logoImageUrl: string;
  roomBgImageUrl: string;
  standbyImageUrl: string;
  trademarkFileUrl: string;
  trademarkText: string;

  customizedFaviconExist(): [boolean, string] {
    const url = this.customizationBaseUrl + `favicon-${this.paramEventId}.ico` + '?dt=' + new Date().getTime().toString();
    return [this.documentExists(url), url];
  }

  customizedLogoImageExist(): [boolean, string] {
    const url = this.customizationBaseUrl + `logo-${this.paramEventId}.png` + '?dt=' + new Date().getTime().toString();
    return [this.documentExists(url), url];
  }

  customizedRoomDefaultImageExist(): [boolean, string] {
    const url = this.customizationBaseUrl + `room-background-${this.paramEventId}.png` + '?dt=' + new Date().getTime().toString();
    return [this.documentExists(url), url];
  }

  customizedTrademarkFileExist(): [boolean, string] {
    const url = this.customizationBaseUrl + `trademark-${this.paramEventId}.txt` + '?dt=' + new Date().getTime().toString();
    return [this.documentExists(url), url];
  }

  customizedStandbyDefaultImageExist(): [boolean, string] {
    const url = this.customizationBaseUrl + `standby-background-${this.paramEventId}.png` + '?dt=' + new Date().getTime().toString();
    return [this.documentExists(url), url];
  }

  getCustomizedFaviconUrl(): string {
    let [exists, url] = this.customizedFaviconExist();
    if (exists) { this.faviconUrl = url; } else { this.faviconUrl = this._faviconUrl }
    return this.faviconUrl;
  }

  getCustomizedLogoImageUrl(): string {
    let [exists, url] = this.customizedLogoImageExist();
    if (exists) { this.logoImageUrl = url; } else { this.logoImageUrl = this._logoImageUrl }
    return this.logoImageUrl;
  }

  getCustomizedRoomImageUrl(): string {
    let [exists, url] = this.customizedRoomDefaultImageExist();
    if (exists) { this.roomBgImageUrl = url; } else { this.roomBgImageUrl = this._roomBgImageUrl }
    return this.roomBgImageUrl;
  }

  getCustomizedStandbyImageUrl(): string {
    let [exists, url] = this.customizedStandbyDefaultImageExist();
    if (exists) { this.standbyImageUrl = url; } else { this.standbyImageUrl = this._standbyImageUrl }
    return this.standbyImageUrl;
  }

  getCustomizedTrademarkFileUrl(): string {
    let [exists, url] = this.customizedTrademarkFileExist();
    if (exists) { this.trademarkFileUrl = url; } else { this.trademarkFileUrl = this._trademarkFileUrl }
    return this.trademarkFileUrl;
  }

  async getCustomizedTrademarkText(): Promise<string> {
    let [exists, url] = this.customizedTrademarkFileExist();
    if (exists) {
      this.trademarkFileUrl = url;
      let res = await fetch(this.trademarkFileUrl, { mode: "no-cors" });
      if (res && res.ok) {
        let data = await res.text();
        this.trademarkText = data;
      }
    }
    return this.trademarkText;
  }

  setAppFavicon(faviconUrl: string) {
    this._document.getElementById('favicon').setAttribute('href', faviconUrl);
  }

  setAppTitle(title: string) {
    this._titleService.setTitle(title);
  }

  private async prepareCustomizationInfo(): Promise<void> {
    this._customizationInfo.faviconUrl = this.getCustomizedFaviconUrl();
    this._customizationInfo.logoImageUrl = this.getCustomizedLogoImageUrl();
    this._customizationInfo.roomBackgroundImageUrl = this.getCustomizedRoomImageUrl();
    this._customizationInfo.standbyBackgroundImageUrl = this.getCustomizedStandbyImageUrl();
    this._customizationInfo.trademarkText = await this.getCustomizedTrademarkText();
  }
}
