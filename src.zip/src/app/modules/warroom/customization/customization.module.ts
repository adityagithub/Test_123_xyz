import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MaterialModule } from 'src/app/core/material.module';
import { FwCoreModule } from 'src/app/core/fw.core.module';
import { CustomizationComponent } from './customization.component';
import { NgxDropzoneModule } from 'ngx-dropzone';
import { NgxSpinnerModule } from 'ngx-spinner';

const routes: Routes = [
  {
    path: '**',
    component: CustomizationComponent
  }
];

@NgModule({
  declarations: [
    CustomizationComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    MaterialModule,
    FwCoreModule,
    NgxDropzoneModule,
    NgxSpinnerModule
  ],
  providers: []
})
export class CustomizationModule {
}
