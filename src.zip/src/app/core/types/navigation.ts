export interface FwNavigationItem {
  id: string;
  title: string;
  type: 'item' | 'group' | 'collapsable';
  icon?: string;
  hidden?: boolean;
  url?: string;
  classes?: string;
  exactMatch?: boolean;
  externalUrl?: boolean;
  openInNewTab?: boolean;
  function?: any;
  badge?: {
    title?: string;
    bg?: string;
    fg?: string;
  };
  children?: FwNavigationItem[];
}

export interface FwNavigation extends FwNavigationItem {
  children?: FwNavigationItem[];
}
