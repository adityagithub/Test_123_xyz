import { AdgoConfig } from 'app/core/types';

export const adgoConfig: AdgoConfig = {
    colorTheme      : 'theme-default',
    customScrollbars: true,
    layout          : {
        style    : 'vertical-layout',
        width    : 'fullwidth',
        navbar   : {
            primaryBackground  : 'adgo-white-700',
            secondaryBackground: 'adgo-white-900',
            folded             : false,
            hidden             : false,
            position           : 'left',
            variant            : 'vertical'
        },
        toolbar  : {
            customBackgroundColor: false,
            background           : 'adgo-white-500',
            hidden               : false,
            position             : 'above'
        },
        footer   : {
            customBackgroundColor: true,
            background           : 'adgo-white-900',
            hidden               : false,
            position             : 'below-static'
        },
        sidepanel: {
            hidden  : false,
            position: 'right'
        }
    }
};
