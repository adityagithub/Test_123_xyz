import { Inject, Injectable, InjectionToken } from '@angular/core';
import { ResolveEnd, Router } from '@angular/router';
import { Platform } from '@angular/cdk/platform';
import { BehaviorSubject, Observable } from 'rxjs';
import { filter } from 'rxjs/operators';
import { equals, clone, mergeDeepRight } from 'ramda'

export const APP_CONFIG = new InjectionToken('appCustomConfig');

@Injectable({
  providedIn: 'root'
})
export class FwConfigService {
  private _configSubject: BehaviorSubject<any>;
  private readonly _defaultConfig: any;

  constructor(
    private _platform: Platform,
    private _router: Router,
    @Inject(APP_CONFIG) _config
  ) {
    this._defaultConfig = _config;

    this._init();
  }

  set config(value) {
    let config = this._configSubject.getValue();

    config = mergeDeepRight(config, value);

    this._configSubject.next(config);
  }

  get config(): any | Observable<any> {
    return this._configSubject.asObservable();
  }

  get defaultConfig(): any {
    return this._defaultConfig;
  }

  private _init(): void {
    if (this._platform.ANDROID || this._platform.IOS) {
      this._defaultConfig.customScrollbars = false;
    }

    this._configSubject = new BehaviorSubject(clone(this._defaultConfig));

    // Reload the default layout config on every RoutesRecognized event
    // if the current layout config is different from the default one
    this._router.events
      .pipe(filter(event => event instanceof ResolveEnd))
      .subscribe(() => {
        if (!equals(this._configSubject.getValue().layout, this._defaultConfig.layout)) {
          const config = clone(this._configSubject.getValue());

          config.layout = clone(this._defaultConfig.layout);

          this._configSubject.next(config);
        }
      });
  }

  setConfig(value, opts = { emitEvent: true }): void {
    let config = this._configSubject.getValue();

    config = mergeDeepRight(config, value);

    if (opts.emitEvent === true) {
      this._configSubject.next(config);
    }
  }

  getConfig(): Observable<any> {
    return this._configSubject.asObservable();
  }

  resetToDefaults(): void {
    this._configSubject.next(clone(this._defaultConfig));
  }
}
