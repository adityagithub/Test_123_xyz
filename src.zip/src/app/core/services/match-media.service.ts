import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FwMatchMediaService {
  activeMediaQuery: string;
  onMediaChange: BehaviorSubject<string> = new BehaviorSubject<string>('');

  constructor(private _screenSizeService: ScreenSizeService) {
    this.activeMediaQuery = '';
    this._init();
  }

  private _init(): void {
    if (this._screenSizeService.isScreenSmall()) {
      this.activeMediaQuery = 'sm';
    } else {
      this.activeMediaQuery = 'lg';
    }
    this.onMediaChange.next(this.activeMediaQuery);
  }

  isActive(val: string): boolean {
    return val.toLowerCase() == this.activeMediaQuery;
  }
}

const SMALL_WIDTH_BREAKPOINT = 720;
@Injectable({
  providedIn: 'root'
})
export class ScreenSizeService {
  private mediaMatcher: MediaQueryList = matchMedia(`(max-width: ${SMALL_WIDTH_BREAKPOINT}px)`);

  constructor() {

  }
  isScreenSmall(): boolean {
    return this.mediaMatcher.matches;
  }
}