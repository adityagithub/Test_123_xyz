import { AdgoNavigationItem } from 'core/components/navigation';

export interface Navigation
{
    compact: AdgoNavigationItem[];
    default: AdgoNavigationItem[];
    futuristic: AdgoNavigationItem[];
    horizontal: AdgoNavigationItem[];
}
