import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FwDirectivesModule } from 'src/app/core/directives/directives';
import { FwPipesModule } from 'src/app/core/pipes/pipes.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    FwDirectivesModule,
    FwPipesModule
  ],
  exports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    FwDirectivesModule,
    FwPipesModule
  ]
})
export class FwCoreModule {
}
