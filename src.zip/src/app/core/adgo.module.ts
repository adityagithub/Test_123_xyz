import { ModuleWithProviders, NgModule, Optional, SkipSelf } from '@angular/core';

import { ADGO_CONFIG } from 'app/core/services/config.service';

@NgModule()
export class AdgoModule
{
    constructor(@Optional() @SkipSelf() parentModule: AdgoModule)
    {
        if ( parentModule )
        {
            throw new Error('AdgoModule is already loaded. Import it in the AppModule only!');
        }
    }

    static forRoot(config): ModuleWithProviders<AdgoModule>
    {
        return {
            ngModule : AdgoModule,
            providers: [
                {
                    provide : ADGO_CONFIG,
                    useValue: config
                }
            ]
        };
    }
}
