import {
  ChangeDetectorRef, Component, ElementRef, EventEmitter, HostBinding, HostListener,
  Input, OnDestroy, OnInit, Output, Renderer2, ViewEncapsulation
} from '@angular/core';
import { animate, AnimationBuilder, AnimationPlayer, style } from '@angular/animations';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { FwSidebarService } from './sidebar.service';
import { FwMatchMediaService } from 'src/app/core/services/match-media.service';
import { FwConfigService } from 'src/app/core/services/config.service';

@Component({
  selector: 'fw-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class FwSidebarComponent implements OnInit, OnDestroy {
  @Input() name: string;

  @Input() key: string;

  @Input() position: 'left' | 'right';

  @HostBinding('class.open') opened: boolean;

  @Input() lockedOpen: string;

  @HostBinding('class.locked-open') isLockedOpen: boolean;

  @Input() foldedWidth: number;

  @Input() foldedAutoTriggerOnHover: boolean;

  @HostBinding('class.unfolded') unfolded: boolean;

  @Input() invisibleOverlay: boolean;

  @Output() foldedChanged: EventEmitter<boolean>;

  @Output() openedChanged: EventEmitter<boolean>;

  private _folded: boolean;
  private _fwConfig: any;
  private _wasActive: boolean;
  private _wasFolded: boolean;
  private _backdrop: HTMLElement | null = null;
  private _player: AnimationPlayer;
  private _unsubscribeAll: Subject<any>;

  @HostBinding('class.animations-enabled')
  private _animationsEnabled: boolean;

  constructor(
    private _animationBuilder: AnimationBuilder,
    private _changeDetectorRef: ChangeDetectorRef,
    private _elementRef: ElementRef,
    private _fwConfigService: FwConfigService,
    private _fwMatchMediaService: FwMatchMediaService,
    private _fwSidebarService: FwSidebarService,
    private _renderer: Renderer2
  ) {
    this.foldedAutoTriggerOnHover = true;
    this.foldedWidth = 64;
    this.foldedChanged = new EventEmitter();
    this.openedChanged = new EventEmitter();
    this.opened = false;
    this.position = 'left';
    this.invisibleOverlay = false;

    this._animationsEnabled = false;
    this._folded = false;
    this._unsubscribeAll = new Subject();
  }

  @Input()
  set folded(value: boolean) {
    this._folded = value;

    if (!this.opened) {
      return;
    }

    let sibling: any;
    let styleRule: string;

    const styleValue = this.foldedWidth + 'px';

    if (this.position === 'left') {
      sibling = this._elementRef.nativeElement.nextElementSibling;
      styleRule = 'padding-left';
    } else {
      sibling = this._elementRef.nativeElement.previousElementSibling;
      // styleRule = 'padding-right';
    }

    if (!sibling) {
      return;
    }

    if (value) {
      this.fold();

      this._renderer.setStyle(this._elementRef.nativeElement, 'width', styleValue);
      this._renderer.setStyle(this._elementRef.nativeElement, 'min-width', styleValue);
      this._renderer.setStyle(this._elementRef.nativeElement, 'max-width', styleValue);

      this._renderer.setStyle(sibling, styleRule, styleValue);
      this._renderer.addClass(this._elementRef.nativeElement, 'folded');
    } else {
      this.unfold();

      this._renderer.removeStyle(this._elementRef.nativeElement, 'width');
      this._renderer.removeStyle(this._elementRef.nativeElement, 'min-width');
      this._renderer.removeStyle(this._elementRef.nativeElement, 'max-width');

      this._renderer.removeStyle(sibling, styleRule);
      this._renderer.removeClass(this._elementRef.nativeElement, 'folded');
    }

    this.foldedChanged.emit(this.folded);
  }

  get folded(): boolean {
    return this._folded;
  }

  ngOnInit(): void {
    this._fwConfigService.config
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe((config: any) => {
        this._fwConfig = config;
      });

    this._fwSidebarService.register(this.name, this);

    this._setupVisibility();

    this._setupPosition();

    this._setupLockedOpen();

    this._setupFolded();
  }

  ngOnDestroy(): void {
    if (this.folded) {
      this.unfold();
    }

    this._fwSidebarService.unregister(this.name);

    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  private _setupVisibility(): void {
    // Remove the existing box-shadow
    this._renderer.setStyle(this._elementRef.nativeElement, 'box-shadow', 'none');

    // Make the sidebar invisible
    this._renderer.setStyle(this._elementRef.nativeElement, 'display', 'none');
  }

  private _setupPosition(): void {
    // Add the correct class name to the sidebar
    // element depending on the position attribute
    if (this.position === 'right') {
      this._renderer.addClass(this._elementRef.nativeElement, 'right-positioned');
    } else {
      this._renderer.addClass(this._elementRef.nativeElement, 'left-positioned');
    }
  }

  private _setupLockedOpen(): void {
    // Return if the lockedOpen wasn't set
    if (!this.lockedOpen) {
      // Return
      return;
    }

    // Set the wasActive for the first time
    this._wasActive = false;

    this._wasFolded = this.folded;

    this._showSidebar();

    const isActive = this._fwMatchMediaService.isActive(this.lockedOpen);
    // If the both status are the same, don't act
    if (this._wasActive === isActive) {
      return;
    }

    if (isActive) {
      this.isLockedOpen = true;
      this._showSidebar();
      this.opened = true;
      this.openedChanged.emit(this.opened);

      // If the sidebar was folded, forcefully fold it again
      if (this._wasFolded) {
        this._enableAnimations();
        this.folded = true;
        this._changeDetectorRef.markForCheck();
      }
      this._hideBackdrop();
    } else {
      this.isLockedOpen = false;
      this.unfold();
      // Force the the opened status to close
      this.opened = false;
      this.openedChanged.emit(this.opened);
      this._hideSidebar();
    }

    this._wasActive = isActive;
  }

  private _setupFolded(): void {

  }

  private _showBackdrop(): void {
    this._backdrop = this._renderer.createElement('div');
    this._backdrop.classList.add('fw-sidebar-overlay');
    if (this.invisibleOverlay) {
      this._backdrop.classList.add('fw-sidebar-overlay-invisible');
    }
    // Append the backdrop to the parent of the sidebar
    this._renderer.appendChild(this._elementRef.nativeElement.parentElement, this._backdrop);
    this._player =
      this._animationBuilder
        .build([
          animate('300ms ease', style({ opacity: 1 }))
        ]).create(this._backdrop);
    this._player.play();
    this._backdrop.addEventListener('click', () => {
      this.close();
    });
    this._changeDetectorRef.markForCheck();
  }

  private _hideBackdrop(): void {
    if (!this._backdrop) {
      return;
    }

    this._player =
      this._animationBuilder
        .build([
          animate('300ms ease', style({ opacity: 0 }))
        ]).create(this._backdrop);

    this._player.play();
    this._player.onDone(() => {
      if (this._backdrop) {
        this._backdrop.parentNode.removeChild(this._backdrop);
        this._backdrop = null;
      }
    });
    this._changeDetectorRef.markForCheck();
  }

  private _showSidebar(): void {
    this._renderer.removeStyle(this._elementRef.nativeElement, 'box-shadow');
    this._renderer.removeStyle(this._elementRef.nativeElement, 'display');
    this._changeDetectorRef.markForCheck();
  }

  private _hideSidebar(delay = true): void {
    const delayAmount = delay ? 300 : 0;
    // Add a delay so close animation can play
    setTimeout(() => {
      this._renderer.setStyle(this._elementRef.nativeElement, 'box-shadow', 'none');
      this._renderer.setStyle(this._elementRef.nativeElement, 'display', 'none');
    }, delayAmount);
    this._changeDetectorRef.markForCheck();
  }

  private _enableAnimations(): void {
    if (this._animationsEnabled) {
      return;
    }
    this._animationsEnabled = true;
    this._changeDetectorRef.markForCheck();
  }

  open(): void {
    if (this.opened || this.isLockedOpen) {
      if (this.name !== 'navbar') {
        this._showSidebar();
        this.opened = true;
      }
      return;
    }
    this._enableAnimations();
    this._showSidebar();
    this._showBackdrop();
    this.opened = true;
    this.openedChanged.emit(this.opened);
    this._changeDetectorRef.markForCheck();
  }

  close(): void {
    if (!this.opened || this.isLockedOpen) {
      if (this.name !== 'navbar') {
        this._hideSidebar();
        this.opened = false;
      }
      return;
    }

    this._enableAnimations();
    this._hideBackdrop();
    this.opened = false;
    this.openedChanged.emit(this.opened);
    this._hideSidebar();
    this._changeDetectorRef.markForCheck();
  }

  toggleOpen(): void {
    if (this.opened) {
      this.close();
    } else {
      this.open();
    }
  }

  @HostListener('mouseenter')
  onMouseEnter(): void {
    if (!this.foldedAutoTriggerOnHover) {
      return;
    }

    this.unfoldTemporarily();
  }

  @HostListener('mouseleave')
  onMouseLeave(): void {
    if (!this.foldedAutoTriggerOnHover) {
      return;
    }
    this.foldTemporarily();
  }

  fold(): void {
    if (this.folded) {
      return;
    }
    this._enableAnimations();
    this.folded = true;
    this._changeDetectorRef.markForCheck();
  }

  unfold(): void {
    if (!this.folded) {
      return;
    }
    this._enableAnimations();
    this.folded = false;
    this._changeDetectorRef.markForCheck();
  }

  toggleFold(): void {
    if (this.folded) {
      this.unfold();
    } else {
      this.fold();
    }
  }

  foldTemporarily(): void {
    if (!this.folded) {
      return;
    }
    this._enableAnimations();
    this.unfolded = false;
    const styleValue = this.foldedWidth + 'px';
    this._renderer.setStyle(this._elementRef.nativeElement, 'width', styleValue);
    this._renderer.setStyle(this._elementRef.nativeElement, 'min-width', styleValue);
    this._renderer.setStyle(this._elementRef.nativeElement, 'max-width', styleValue);
    this._changeDetectorRef.markForCheck();
  }

  unfoldTemporarily(): void {
    if (!this.folded) {
      return;
    }
    this._enableAnimations();
    this.unfolded = true;
    this._renderer.removeStyle(this._elementRef.nativeElement, 'width');
    this._renderer.removeStyle(this._elementRef.nativeElement, 'min-width');
    this._renderer.removeStyle(this._elementRef.nativeElement, 'max-width');
    this._changeDetectorRef.markForCheck();
  }
}
