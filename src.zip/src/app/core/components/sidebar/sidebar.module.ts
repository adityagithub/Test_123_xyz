import { NgModule } from '@angular/core';

import { FwSidebarComponent } from './sidebar.component';

@NgModule({
  declarations: [
    FwSidebarComponent
  ],
  exports: [
    FwSidebarComponent
  ]
})
export class FwSidebarModule {
}
