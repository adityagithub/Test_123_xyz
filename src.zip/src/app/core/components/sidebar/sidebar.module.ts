import { NgModule } from '@angular/core';

import { AdgoSidebarComponent } from './sidebar.component';

@NgModule({
    declarations: [
        AdgoSidebarComponent
    ],
    exports     : [
        AdgoSidebarComponent
    ]
})
export class AdgoSidebarModule
{
}
