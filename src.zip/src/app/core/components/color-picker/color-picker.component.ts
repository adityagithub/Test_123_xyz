import { Component, EventEmitter, Input, Output, ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'fw-color-picker',
    templateUrl: './color-picker.component.html',
    styleUrls: ['./color-picker.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class FwColorPickerComponent {       
    selectedColor: any;   
    @Output() colorChanged: EventEmitter<any>;
    private _color: string;

    constructor() {
        this.colorChanged = new EventEmitter();     
        this._color = '';
    }


    @Input()
    set color(value) {        
        this._color = value;
    }

    get color(): string {
        return this._color;
    }

    updateSelectedColor($event): void {
        console.log($event, 'color')
        this.selectedColor = $event;
        this.colorChanged.emit(this.selectedColor);
    }
}
