import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[ecWidgetToggle]'
})
export class FwWidgetToggleDirective {
  /**
     * Constructor
     *
     * @param {ElementRef} elementRef
     */
  constructor(
        public elementRef: ElementRef
  ) {
  }
}
