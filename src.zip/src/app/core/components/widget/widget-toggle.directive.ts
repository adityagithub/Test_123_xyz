import { Directive, ElementRef } from '@angular/core';

@Directive({
    selector: '[adgoWidgetToggle]'
})
export class AdgoWidgetToggleDirective
{
    /**
     * Constructor
     *
     * @param {ElementRef} elementRef
     */
    constructor(
        public elementRef: ElementRef
    )
    {
    }
}
