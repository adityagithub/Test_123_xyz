import { NgModule } from '@angular/core';

import { FwWidgetComponent } from './widget.component';
import { FwWidgetToggleDirective } from './widget-toggle.directive';

@NgModule({
  declarations: [
    FwWidgetComponent,
    FwWidgetToggleDirective
  ],
  exports: [
    FwWidgetComponent,
    FwWidgetToggleDirective
  ]
})
export class FwWidgetModule {
}
