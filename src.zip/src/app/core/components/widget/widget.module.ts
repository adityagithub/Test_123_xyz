import { NgModule } from '@angular/core';

import { AdgoWidgetComponent } from './widget.component';
import { AdgoWidgetToggleDirective } from './widget-toggle.directive';

@NgModule({
    declarations: [
        AdgoWidgetComponent,
        AdgoWidgetToggleDirective
    ],
    exports     : [
        AdgoWidgetComponent,
        AdgoWidgetToggleDirective
    ],
})
export class AdgoWidgetModule
{
}
