import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatOptionModule } from '@angular/material/core';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatRadioModule } from '@angular/material/radio';
import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

import { AdgoDirectivesModule } from 'app/core/directives/directives';
import { AdgoSidebarModule } from 'app/core/components/sidebar/sidebar.module';

import { AdgoThemeOptionsComponent } from 'app/core/components/theme-options/theme-options.component';
import { AdgoSharedModule } from 'app/shared/shared.module';

@NgModule({
    declarations: [
        AdgoThemeOptionsComponent
    ],
    imports: [
        AdgoSharedModule,
        MatButtonModule,
        MatCheckboxModule,
        MatDividerModule,
        MatFormFieldModule,
        MatIconModule,
        MatOptionModule,
        MatRadioModule,
        MatSelectModule,
        MatSlideToggleModule,
        AdgoDirectivesModule,
        AdgoSidebarModule
    ],
    exports: [
        AdgoThemeOptionsComponent
    ]
})
export class AdgoThemeOptionsModule {
}
