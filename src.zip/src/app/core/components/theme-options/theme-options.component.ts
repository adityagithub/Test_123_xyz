import { Component, HostBinding, Inject, OnDestroy, OnInit, Renderer2, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { DOCUMENT } from '@angular/common';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { adgoAnimations } from 'app/core/animations';
import { AdgoConfigService } from 'app/core/services/config.service';
import { AdgoNavigationService } from 'app/core/components/navigation/navigation.service';
import { AdgoSidebarService } from 'app/core/components/sidebar/sidebar.service';

@Component({
    selector     : 'adgo-theme-options',
    templateUrl  : './theme-options.component.html',
    styleUrls    : ['./theme-options.component.scss'],
    encapsulation: ViewEncapsulation.None,
    animations   : adgoAnimations
})
export class AdgoThemeOptionsComponent implements OnInit, OnDestroy
{
    adgoConfig: any;
    form: FormGroup;

    @HostBinding('class.bar-closed')
    barClosed: boolean;

    private _unsubscribeAll: Subject<any>;

    constructor(
        @Inject(DOCUMENT) private document: any,
        private _formBuilder: FormBuilder,
        private _adgoConfigService: AdgoConfigService,
        private _adgoNavigationService: AdgoNavigationService,
        private _adgoSidebarService: AdgoSidebarService,
        private _renderer: Renderer2
    )
    {
        this.barClosed = true;

        this._unsubscribeAll = new Subject();
    }

    ngOnInit(): void
    {
        this.form = this._formBuilder.group({
            colorTheme      : new FormControl(),
            customScrollbars: new FormControl(),
            layout          : this._formBuilder.group({
                style    : new FormControl(),
                width    : new FormControl(),
                navbar   : this._formBuilder.group({
                    primaryBackground  : new FormControl(),
                    secondaryBackground: new FormControl(),
                    folded             : new FormControl(),
                    hidden             : new FormControl(),
                    position           : new FormControl(),
                    variant            : new FormControl()
                }),
                toolbar  : this._formBuilder.group({
                    background           : new FormControl(),
                    customBackgroundColor: new FormControl(),
                    hidden               : new FormControl(),
                    position             : new FormControl()
                }),
                footer   : this._formBuilder.group({
                    background           : new FormControl(),
                    customBackgroundColor: new FormControl(),
                    hidden               : new FormControl(),
                    position             : new FormControl()
                }),
                sidepanel: this._formBuilder.group({
                    hidden  : new FormControl(),
                    position: new FormControl()
                })
            })
        });

        this._adgoConfigService.config
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe((config) => {

                this.adgoConfig = config;

                // Set the config form values without emitting an event
                // so that we don't end up with an infinite loop
                this.form.setValue(config, {emitEvent: false});
            });

        this.form.get('layout.style').valueChanges
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe((value) => {
                this._resetFormValues(value);
            });

        this.form.valueChanges
            .pipe(takeUntil(this._unsubscribeAll))
            .subscribe((config) => {

                this._adgoConfigService.config = config;
            });

        const customFunctionNavItem = {
            id      : 'custom-function',
            title   : '',
            type    : 'group',
            icon    : '',
            children: [
                {
                    id      : 'customize',
                    title   : '',
                    type    : 'item',
                    icon    : '',
                    function: () => {
                        this.toggleSidebarOpen('themeOptionsPanel');
                    }
                }
            ]
        };

        this._adgoNavigationService.addNavigationItem(customFunctionNavItem, 'end');
    }

    ngOnDestroy(): void
    {
        this._unsubscribeAll.next();
        this._unsubscribeAll.complete();

        this._adgoNavigationService.removeNavigationItem('custom-function');
    }

    private _resetFormValues(value): void
    {
        switch ( value )
        {
            case 'vertical-layout':
            {
                this.form.patchValue({
                    layout: {
                        width    : 'fullwidth',
                        navbar   : {
                            primaryBackground  : 'adgo-white-700',
                            secondaryBackground: 'adgo-white-900',
                            folded             : false,
                            hidden             : false,
                            position           : 'left',
                            variant            : 'vertical'
                        },
                        toolbar  : {
                            background           : 'adgo-white-500',
                            customBackgroundColor: false,
                            hidden               : false,
                            position             : 'below-static'
                        },
                        footer   : {
                            background           : 'adgo-white-900',
                            customBackgroundColor: true,
                            hidden               : false,
                            position             : 'below-static'
                        },
                        sidepanel: {
                            hidden  : false,
                            position: 'right'
                        }
                    }
                });

                break;
            }

            case 'horizontal-layout':
            {
                this.form.patchValue({
                    layout: {
                        width    : 'fullwidth',
                        navbar   : {
                            primaryBackground  : 'adgo-navy-700',
                            secondaryBackground: 'adgo-navy-900',
                            folded             : false,
                            hidden             : false,
                            position           : 'top',
                            variant            : 'vertical'
                        },
                        toolbar  : {
                            background           : 'adgo-white-500',
                            customBackgroundColor: false,
                            hidden               : false,
                            position             : 'above'
                        },
                        footer   : {
                            background           : 'adgo-navy-900',
                            customBackgroundColor: true,
                            hidden               : false,
                            position             : 'above-fixed'
                        },
                        sidepanel: {
                            hidden  : false,
                            position: 'right'
                        }
                    }
                });

                break;
            }
        }
    }

    toggleSidebarOpen(key): void
    {
        this._adgoSidebarService.getSidebar(key).toggleOpen();
    }
}
