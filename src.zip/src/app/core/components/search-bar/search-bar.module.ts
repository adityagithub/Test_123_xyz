import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

import { AdgoSearchBarComponent } from './search-bar.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

@NgModule({
    declarations: [
        AdgoSearchBarComponent
    ],
    imports: [
        CommonModule,
        RouterModule,
        MatFormFieldModule,
        MatButtonModule,
        MatIconModule,
        MatInputModule 
    ],
    exports: [
        AdgoSearchBarComponent
    ]
})
export class AdgoSearchBarModule {
}
