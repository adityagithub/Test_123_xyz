import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';

import { AdgoConfirmDialogComponent } from 'app/core/components/confirm-dialog/confirm-dialog.component';

@NgModule({
    declarations: [
        AdgoConfirmDialogComponent
    ],
    imports: [
        MatDialogModule,
        MatButtonModule
    ],
    entryComponents: [
        AdgoConfirmDialogComponent
    ],
})
export class AdgoConfirmDialogModule
{
}
