import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA, MatDialogModule } from '@angular/material/dialog';
import { ConfirmDialogComponentData } from './confirm.dialog.models';
import { MatButtonModule } from '@angular/material/button';
import { FwCoreModule } from '../../fw.core.module';

@Component({
  selector: 'fw-confirm-dialog',
  templateUrl: './confirm-dialog.component.html',
  styleUrls: ['./confirm-dialog.component.scss'],
  standalone: true,
  imports: [
    MatDialogModule,
    MatButtonModule,
    FwCoreModule
  ]
})
export class ConfirmDialogComponent {
  public data: ConfirmDialogComponentData

  constructor(
    public dialogRef: MatDialogRef<ConfirmDialogComponent>,
    @Inject(MAT_DIALOG_DATA) _data: ConfirmDialogComponentData
  ) {
    this.data = _data;
  }
}
