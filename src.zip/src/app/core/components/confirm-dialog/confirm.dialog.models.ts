
export class ConfirmDialogComponentData {
  Title: string = 'Please confirm'
  Message: string
  OkText: string = 'Ok'
  CancelText: string = 'Canel'
  CustomAction: string = '';
}
