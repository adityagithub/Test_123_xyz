import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnInit, ViewEncapsulation } from '@angular/core';
import { merge, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { FwNavigationService } from 'src/app/core/components/navigation/navigation.service';

@Component({
  selector: 'fw-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.scss'],
  encapsulation: ViewEncapsulation.None,
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class FwNavigationComponent implements OnInit {
  @Input() layout = 'vertical';

  @Input() navigation: any;

  private _unsubscribeAll: Subject<any>;

  constructor(
    private _changeDetectorRef: ChangeDetectorRef,
    private _navigationService: FwNavigationService
  ) {
    this._unsubscribeAll = new Subject();
  }

  ngOnInit(): void {
    this.navigation = this.navigation || this._navigationService.getCurrentNavigation();

    this._navigationService.onNavigationChanged
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe(() => {
        this.navigation = this._navigationService.getCurrentNavigation();

        this._changeDetectorRef.markForCheck();
      });

    merge(
      this._navigationService.onNavigationItemAdded,
      this._navigationService.onNavigationItemUpdated,
      this._navigationService.onNavigationItemRemoved
    ).pipe(takeUntil(this._unsubscribeAll))
      .subscribe(() => {
        this._changeDetectorRef.markForCheck();
      });
  }
}
