import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatRippleModule } from '@angular/material/core';
import { MatIconModule } from '@angular/material/icon';

import { TranslateModule } from '@ngx-translate/core';

import { AdgoNavigationComponent } from './navigation.component';
import { AdgoNavVerticalItemComponent } from './vertical/item/item.component';
import { AdgoNavVerticalCollapsableComponent } from './vertical/collapsable/collapsable.component';
import { AdgoNavVerticalGroupComponent } from './vertical/group/group.component';
import { AdgoNavHorizontalItemComponent } from './horizontal/item/item.component';
import { AdgoNavHorizontalCollapsableComponent } from './horizontal/collapsable/collapsable.component';

@NgModule({
    imports     : [
        CommonModule,
        RouterModule,

        MatIconModule,
        MatRippleModule,

        TranslateModule.forChild()
    ],
    exports     : [
        AdgoNavigationComponent
    ],
    declarations: [
        AdgoNavigationComponent,
        AdgoNavVerticalGroupComponent,
        AdgoNavVerticalItemComponent,
        AdgoNavVerticalCollapsableComponent,
        AdgoNavHorizontalItemComponent,
        AdgoNavHorizontalCollapsableComponent
    ]
})
export class AdgoNavigationModule
{
}
