import { ChangeDetectorRef, Component, HostBinding, Input, OnDestroy, OnInit } from '@angular/core';
import { merge, Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { FwNavigationItem } from 'src/app/core/types';
import { FwNavigationService } from 'src/app/core/components/navigation/navigation.service';

@Component({
  selector: 'fw-nav-vertical-group',
  templateUrl: './group.component.html',
  styleUrls: ['./group.component.scss']
})
export class FwNavVerticalGroupComponent implements OnInit, OnDestroy {
    @HostBinding('class')
      classes = 'nav-group nav-item';

    @Input()
      item: FwNavigationItem;

    private _unsubscribeAll: Subject<any>;

    constructor(
        private _changeDetectorRef: ChangeDetectorRef,
        private _ecNavigationService: FwNavigationService
    ) {
      this._unsubscribeAll = new Subject();
    }

    ngOnInit(): void {
      merge(
        this._ecNavigationService.onNavigationItemAdded,
        this._ecNavigationService.onNavigationItemUpdated,
        this._ecNavigationService.onNavigationItemRemoved
      ).pipe(takeUntil(this._unsubscribeAll))
        .subscribe(() => {
          this._changeDetectorRef.markForCheck();
        });
    }

    ngOnDestroy(): void {
      this._unsubscribeAll.next(true);
      this._unsubscribeAll.complete();
    }
}
