import { Directive, Input, OnInit, HostListener, OnDestroy, HostBinding } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

import { FwMatchMediaService } from 'src/app/core/services/match-media.service';
import { FwMatSidenavHelperService } from './fw-mat-sidenav.service';

@Directive({
  selector: '[fwMatSidenavHelper]'
})
export class FwMatSidenavHelperDirective implements OnInit, OnDestroy {
  @HostBinding('class.mat-is-locked-open') isLockedOpen: boolean;

  @Input() fwMatSidenavHelper: string;

  @Input() matIsLockedOpen: string;

  // Private
  private _unsubscribeAll: Subject<any>;

  /**
   * Constructor
   *
   * @param {FwMatchMediaService} _fwMatchMediaService
   * @param {EcMatSidenavHelperService} _matSidenavHelperService
   * @param {MatSidenav} _matSidenav
   * @param {MediaObserver} _mediaObserver
   */
  constructor(
    private _fwMatchMediaService: FwMatchMediaService,
    private _matSidenavHelperService: FwMatSidenavHelperService,
    private _matSidenav: MatSidenav
  ) {
    // Set the defaults
    this.isLockedOpen = true;

    // Set the private defaults
    this._unsubscribeAll = new Subject();
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Lifecycle hooks
  // -----------------------------------------------------------------------------------------------------

  /**
   * On init
   */
  ngOnInit(): void {
    // Register the sidenav to the service
    this._matSidenavHelperService.setSidenav(this.fwMatSidenavHelper, this._matSidenav);

    if (this.matIsLockedOpen && this._fwMatchMediaService.isActive(this.matIsLockedOpen)) {
      this.isLockedOpen = true;
      this._matSidenav.mode = 'side';
      this._matSidenav.toggle(true);
    } else {
      this.isLockedOpen = false;
      this._matSidenav.mode = 'over';
      this._matSidenav.toggle(false);
    }

    this._fwMatchMediaService.onMediaChange
      .pipe(takeUntil(this._unsubscribeAll))
      .subscribe(() => {
        if (this.matIsLockedOpen && this._fwMatchMediaService.isActive(this.matIsLockedOpen)) {
          this.isLockedOpen = true;
          this._matSidenav.mode = 'side';
          this._matSidenav.toggle(true);
        } else {
          this.isLockedOpen = false;
          this._matSidenav.mode = 'over';
          this._matSidenav.toggle(false);
        }
      });
  }

  /**
   * On destroy
   */
  ngOnDestroy(): void {
    // Unsubscribe from all subscriptions
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }
}

@Directive({
  selector: '[fwMatSidenavToggler]'
})
export class FwMatSidenavTogglerDirective {
  @Input() fwMatSidenavToggler: string;

  /**
   * Constructor
   *
   * @param {EcMatSidenavHelperService} _ecMatSidenavHelperService
   */
  constructor(
    private _ecMatSidenavHelperService: FwMatSidenavHelperService) {
  }

  // -----------------------------------------------------------------------------------------------------
  // @ Public methods
  // -----------------------------------------------------------------------------------------------------

  /**
   * On click
   */
  @HostListener('click')
  onClick(): void {
    this._ecMatSidenavHelperService.getSidenav(this.fwMatSidenavToggler).toggle();
  }
}
