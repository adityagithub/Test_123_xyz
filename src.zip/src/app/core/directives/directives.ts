import { NgModule } from '@angular/core';
import { AdgoIfOnDomDirective } from './adgo-if-on-dom/adgo-if-on-dom.directive';
import { AdgoInnerScrollDirective } from './adgo-inner-scroll/adgo-inner-scroll.directive';
import { AdgoMatSidenavHelperDirective, AdgoMatSidenavTogglerDirective } from './adgo-mat-sidenav/adgo-mat-sidenav.directive';
import { AdgoPerfectScrollbarDirective } from './adgo-perfect-scrollbar/adgo-perfect-scrollbar.directive';

@NgModule({
    declarations: [
        AdgoIfOnDomDirective,
        AdgoInnerScrollDirective,
        AdgoMatSidenavHelperDirective,
        AdgoMatSidenavTogglerDirective,
        AdgoPerfectScrollbarDirective
    ],
    imports     : [],
    exports     : [
        AdgoIfOnDomDirective,
        AdgoInnerScrollDirective,
        AdgoMatSidenavHelperDirective,
        AdgoMatSidenavTogglerDirective,
        AdgoPerfectScrollbarDirective
    ]
})
export class AdgoDirectivesModule
{
}
