import { NgModule } from '@angular/core';
import { FwIfOnDomDirective } from './fw-if-on-dom/fw-if-on-dom.directive';
import { FwInnerScrollDirective } from './fw-inner-scroll/fw-inner-scroll.directive';
import { FwMatSidenavHelperDirective, FwMatSidenavTogglerDirective } from './fw-mat-sidenav/fw-mat-sidenav.directive';
import { FwPerfectScrollbarDirective } from './fw-perfect-scrollbar/fw-perfect-scrollbar.directive';
import { FwInputRestrictionDirective } from './fw-input-restriction';

@NgModule({
  declarations: [
    FwIfOnDomDirective,
    FwInnerScrollDirective,
    FwMatSidenavHelperDirective,
    FwMatSidenavTogglerDirective,
    FwPerfectScrollbarDirective,
    FwInputRestrictionDirective
  ],
  imports: [],
  exports: [
    FwIfOnDomDirective,
    FwInnerScrollDirective,
    FwMatSidenavHelperDirective,
    FwMatSidenavTogglerDirective,
    FwPerfectScrollbarDirective,
    FwInputRestrictionDirective
  ]
})
export class FwDirectivesModule {
}
