import { NgModule } from '@angular/core';
import { HtmlToPlaintextPipe } from './htmlToPlaintext.pipe';
import { FilterByPropertyPipe, FilterPipe } from './filter.pipe';
import { UtcDateToLocalPipe } from './date.pipe';
import { UrlSafePipe } from './urlSafe.pipe';
import { KeysPipe } from './keys.pipe';

@NgModule({
  declarations: [
    HtmlToPlaintextPipe,
    FilterPipe,
    UtcDateToLocalPipe,
    FilterByPropertyPipe,
    UrlSafePipe,
    KeysPipe
  ],
  imports: [],
  exports: [
    HtmlToPlaintextPipe,
    FilterPipe,
    UtcDateToLocalPipe,
    FilterByPropertyPipe,
    UrlSafePipe,
    KeysPipe
  ]
})
export class FwPipesModule {
}
