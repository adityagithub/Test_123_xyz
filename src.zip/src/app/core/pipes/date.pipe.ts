
import { Pipe, PipeTransform } from '@angular/core';
import * as moment from 'moment';

@Pipe({
  name: 'utcToLocal'
})
export class UtcDateToLocalPipe implements PipeTransform {
  transform(date: Date): string {
    return moment.utc(date).local().format('lll');
  }
}
