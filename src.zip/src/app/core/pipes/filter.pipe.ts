import { Pipe, PipeTransform } from '@angular/core';
import { FwUtils } from 'src/app/core/utils';

@Pipe({ name: 'filter' })
export class FilterPipe implements PipeTransform {
  transform(mainArr: any[], searchText: string, property: string): any {
    return FwUtils.filterArrayByString(mainArr, searchText);
  }
}

@Pipe({
  name: 'filterByProperty'
})
export class FilterByPropertyPipe implements PipeTransform {
  transform(items: any[], field: string, value: boolean): any[] {
    if (!items) return [];
    const fItems = items.filter(it => it[field] === value);
    return fItems;
  }
}
