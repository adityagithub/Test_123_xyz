
export interface LayoutConfig {
  colorTheme: string;
  colorCode: string;
  customScrollbars: boolean;
  layout: {
    style: string,
    navbar: {
      hidden: boolean,
      folded: boolean,
      position: 'left' | 'right' | 'top',
      variant: string
    },
    toolbar: {
      hidden: boolean,
      position: 'above' | 'above-static' | 'above-fixed' | 'below' | 'below-static' | 'below-fixed'
    }
    footer: {
      hidden: boolean,
      position: 'above' | 'above-static' | 'above-fixed' | 'below' | 'below-static' | 'below-fixed'
    },
    sidepanel: {
      hidden: boolean,
      position: 'left' | 'right'
    }
  };
}

export const appConfig: LayoutConfig = {
  colorTheme: 'islighttheme',
  colorCode: '#ec1560',
  customScrollbars: true,
  layout: {
    style: 'vertical-layout',
    navbar: {
      folded: true,
      hidden: false,
      position: 'left',
      variant: 'vertical-style'
    },
    toolbar: {
      hidden: false,
      position: 'below-fixed'
    },
    footer: {
      hidden: false,
      position: 'below-fixed'
    },
    sidepanel: {
      hidden: false,
      position: 'right'
    }
  }
}
