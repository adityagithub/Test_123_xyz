import { UserModel } from './shared/models/user.model'
import { EventModel } from './shared/models/event.model'

export interface InitialData {
  user: UserModel;
  event: EventModel;
}
