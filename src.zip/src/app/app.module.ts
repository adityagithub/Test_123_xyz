import { HttpClientModule } from '@angular/common/http'
import { APP_INITIALIZER, ErrorHandler, NgModule } from '@angular/core'
import { BrowserModule } from '@angular/platform-browser'
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'
import { RouterModule } from '@angular/router'
import { GuidedTourService } from 'ngx-guided-tour'
import { AppComponent } from './app.component'
import { routes } from './app.routing'
import { appConfig } from './core/layoutConfig'
import { LayoutModule } from './layout/layout.module'
import { AuthModule } from './modules/auth/auth.module'
import { HelpModule } from './modules/pages/help/help.module'
import { ErrorHandlerService } from './shared/services/error.service'
import { MessageService } from './shared/services/message.service';
import { MaterialCssVarsModule } from 'angular-material-css-vars';
import { AppSettingService } from './shared/services/appsetting.service';
import { APP_CONFIG } from './core/services/config.service';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    RouterModule.forRoot(routes, { paramsInheritanceStrategy: 'always' }),
    LayoutModule,
    AuthModule,
    HelpModule,
    MaterialCssVarsModule.forRoot({
      isAutoContrast: false
    })
  ],
  bootstrap: [
    AppComponent
  ],
  providers: [
    GuidedTourService,
    MessageService,
    { provide: ErrorHandler, useClass: ErrorHandlerService },
    AppSettingService,
    {
      provide: APP_INITIALIZER,
      useFactory: (appInitService: AppSettingService) => {
        return (): Promise<any> => {
          return appInitService.init();
        }
      },
      deps: [AppSettingService],
      multi: true
    },
    {
      provide: APP_CONFIG,
      useValue: appConfig
    }
  ]
})
export class AppModule {
}
