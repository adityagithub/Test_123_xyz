import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule, Routes } from '@angular/router';
import { MatMomentDateModule } from '@angular/material-moment-adapter';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { TranslateModule } from '@ngx-translate/core';
import 'hammerjs';

import { AdgoModule } from 'app/core/adgo.module';
import { AdgoSharedModule } from 'app/shared/shared.module';
import { AdgoProgressBarModule, AdgoSidebarModule, AdgoThemeOptionsModule } from 'app/core/components';

import { adgoConfig } from 'app/core/config';

import { MockDataService } from 'app/mock-data/mock-data.service';
import { AppComponent } from 'app/app.component';
import { LayoutModule } from 'app/layout/layout.module';
import { AdgoDirectivesModule } from './core/directives/directives';
import { AdgoPipesModule } from './core/pipes/pipes.module';

const appRoutes: Routes = [
    {
        path: 'admin',
        loadChildren: () => import('./modules/admin/admin.module').then(m => m.AdminModule)
    },
    {
        path: 'pages',
        loadChildren: () => import('./modules/pages/pages.module').then(m => m.PagesModule)
    },
    {
        path: '**', pathMatch: 'full',
        loadChildren: () => import('./modules/pages/errors/404/error-404.module').then(m => m.Error404Module)
    }
];

@NgModule({
    declarations: [
        AppComponent
    ],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        HttpClientModule,
        RouterModule.forRoot(appRoutes),

        TranslateModule.forRoot(),
        InMemoryWebApiModule.forRoot(MockDataService, {
            delay: 0,
            passThruUnknownUrl: true
        }),

        MatMomentDateModule,
        MatButtonModule,
        MatIconModule,

        AdgoModule.forRoot(adgoConfig),
        AdgoProgressBarModule,
        AdgoSharedModule,
        AdgoSidebarModule,
        AdgoThemeOptionsModule,
        LayoutModule
    ],
    bootstrap: [
        AppComponent
    ]
})
export class AppModule {
}
