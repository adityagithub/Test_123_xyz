import { ErrorHandler, Injectable } from '@angular/core'
import { MessageService } from './message.service';
import { NGXLoggerWriterService, INGXLoggerMetadata, INGXLoggerConfig } from 'ngx-logger'
import { NgxSpinnerService } from 'ngx-spinner';

@Injectable()
export class ErrorHandlerService implements ErrorHandler {
  constructor(
    private _messageService: MessageService,
    private _spinnerService: NgxSpinnerService) {
  }

  handleError(error: any) {
    console.error(error);
    let errorMsg = error?.toString().substring(0, 150) + '...';
    if (errorMsg.includes('Cannot send data if the connection is not in the')) {
      errorMsg = 'Your session has timeout, please refresh the page before proceding' + '\n' + 'Reaload?';
      if (confirm(errorMsg)) {
        location.reload();
      }
    }
    else if (errorMsg.includes('AgoraRTCException')) {
      // error = "Sorry! An error occurred while processing you request";
      error = '';
    }
    else {
      error = '';
    }

    if (error?.toString()) {
      this._messageService.showErrorMessage(error?.toString().substring(0, 150) + '...');
      this._spinnerService.hide();
    }
  }
}

@Injectable()
export class WriterCustomisedService extends NGXLoggerWriterService {
  public writeMessage(metadata: INGXLoggerMetadata, config: INGXLoggerConfig): void {
    console.warn('ngx-logger: ', metadata);
  }
}
