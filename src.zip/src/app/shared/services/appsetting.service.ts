import { HttpBackend, HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

export interface AppSettings {
    maxPresenter: number;
    baseUrl: string;
    resourceBaseUrl: string;
    appId: string;
    whiteboard: WhiteboardAppSettings
}

export interface WhiteboardAppSettings{
    baseUrl: string;
    appId: string;
    ak : string;
    sk: string;
    token: string;
}

@Injectable({ providedIn: 'root' })
export class AppSettingService {
    settings: AppSettings;
    private http: HttpClient;

    constructor(private readonly httpHandler: HttpBackend) {
        this.http = new HttpClient(httpHandler);
    }

    async init(): Promise<void> {
        let now = new Date().toString();
        let d = await this.http.get('appsettings.json?dt=' + now).toPromise();
        this.settings = d as AppSettings;
    }

    getSettings(key?: string | Array<string>): any {
        if (!key || (Array.isArray(key) && !key[0])) {
            return this.settings;
        }

        if (!Array.isArray(key)) {
            key = key.split('.');
        }

        let result = key.reduce((account: any, current: string) => account && account[current], this.settings);

        return result;
    }
}