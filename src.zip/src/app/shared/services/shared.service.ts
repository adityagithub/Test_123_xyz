import { HttpParams } from '@angular/common/http'
import { Injectable } from '@angular/core'
import { GuidedTour, Orientation } from 'ngx-guided-tour'
import { DonotShowNickNameSyncDataModel, Entry, TimeSpan } from '../models/shared.model'
import { FwConfigService } from 'src/app/core/services/config.service';
import { MaterialCssVarsService } from 'angular-material-css-vars';
import { AppSettingService } from './appsetting.service';
import { ScriptInjectorService } from './script.service';

@Injectable({
  providedIn: 'root'
})
export class SharedService {
  paramToken: string;
  isMobileLayout: boolean = false;
  private _moveToAnotherRoomWithouConfirmation: boolean;
  roomCloseTimerStartBefore: number = 90; // Seconds
  static originalToken: string;
  static encriptedToken: string;

  constructor(
    private _fwConfigService: FwConfigService,
    private _materialCssVarsService: MaterialCssVarsService,
    private _settingService: AppSettingService,
    private _scriptService: ScriptInjectorService) {

  }

  getElapsedTime(entry: Entry): TimeSpan {
    let totalSeconds = Math.floor((entry.end.getTime() - entry.created.getTime()) / 1000)
    let days = 0
    let hours = 0
    let minutes = 0
    let seconds = 0
    if (totalSeconds >= 86400) {
      days = Math.floor(totalSeconds / 86400)
      totalSeconds -= 86400 * days
    }
    if (totalSeconds >= 3600) {
      hours = Math.floor(totalSeconds / 3600)
      totalSeconds -= 3600 * hours
    }
    if (totalSeconds >= 60) {
      minutes = Math.floor(totalSeconds / 60)
      totalSeconds -= 60 * minutes
    }
    seconds = totalSeconds
    return {
      days,
      hours,
      minutes,
      seconds
    }
  }

  getParamValueQueryString(url: string, paramName: string): any {
    let paramValue
    if (url.includes('?')) {
      const httpParams = new HttpParams({ fromString: url.split('?')[1] })
      paramValue = httpParams.get(paramName)
    }
    return paramValue
  }

  getCountdownFormat(difference: number): string {
    if (difference > (24 * 60 * 60 * 1000)) { // Greater than a day
      return 'd\'d\':h\'h\':m\'m\':s\'s\''
    } else if (difference > (60 * 60 * 1000)) { // Greater than an hour
      return 'h\'h\':m\'m\':s\'s\''
    } else if (difference > 60 * 1000) { // Greater than a minute
      return 'm\'m\':s\'s\''
    }
    return 'm\'m\':s\'s\''
  }

  setDataInLocalStorage(key: string, data: any) {
    localStorage.setItem(key, JSON.stringify(data));
  }

  getDataFromLocalStorage(key: string): any {
    const data = {};
    try {
      const storedSettings = localStorage.getItem(key);
      if (!storedSettings) {
        return data
      }
      return JSON.parse(storedSettings);
    } catch {
      this.clearDataFromLocalStorage(key);
      return data;
    }
  }

  clearDataFromLocalStorage(key: string) {
    localStorage.removeItem(key);
  }

  enableAutoJoinRoom(enable: boolean): boolean {
    if (enable) {
      sessionStorage.setItem('autojoin', '1');
    } else {
      sessionStorage.removeItem('autojoin');
    }
    return true;
  }

  isAutoJoinRoomEnabled(): boolean {
    const item = sessionStorage.getItem('autojoin');
    return item === '1';
  }

  enableMoveToAnotherRoomWithoutConfirmation(enable: boolean): void {
    this._moveToAnotherRoomWithouConfirmation = enable;
  }

  isMoveToAnotherRoomWithoutConfirmationEnabled(): boolean {
    return this._moveToAnotherRoomWithouConfirmation;
  }

  getAppTours(useOrb: boolean): GuidedTour {
    const appTour: GuidedTour = {
      tourId: 'fireworks-tour',
      useOrb,
      steps: [
        {
          title: 'Welcome to Fireworks™',
          selector: '.left-navbar',
          content: 'The collapsible left menu showcases all of the enabled rooms.',
          orientation: Orientation.Right
        },
        {
          title: 'Toolbar Overview',
          selector: '.guided-top-toolbar',
          content: 'Above, you can manage your audio/video settings, full screen, see where you are and more.',
          orientation: Orientation.Bottom
        },
        {
          title: 'Right Menu List',
          selector: '.menu-list-right',
          content: 'The collapsible right menu shows chat, attendees, speakers, brands, agenda, games and more, if enabled.',
          orientation: Orientation.Left
        },
        {
          title: 'Join Button',
          selector: '.join-button',
          content: 'Use this button to join a session.',
          orientation: Orientation.Bottom
        }
      ]
    }
    return appTour
  }

  getAppToursMobile(useOrb: boolean): GuidedTour {
    const appTour: GuidedTour = {
      tourId: 'fireworks-tour',
      useOrb,
      steps: [
        {
          title: 'Welcome to Fireworks™',
          selector: '.navbar-toggle-button',
          content: 'The collapsible left menu showcases all of the enabled rooms.',
          orientation: Orientation.Right
        },
        {
          title: 'Toolbar Overview',
          selector: '.toolbar-setting-button',
          content: 'Above, you can manage your audio/video settings and more.',
          orientation: Orientation.Bottom
        },
        {
          title: 'Right Menu List',
          selector: '.right-panel-toggle-button-mobile',
          content: 'The collapsible right menu shows chat, attendees, speakers, brands, agenda, games and more, if enabled.',
          orientation: Orientation.Left
        },
        {
          title: 'Join Button',
          selector: '.join-button',
          content: 'Use this button to join a session.',
          orientation: Orientation.Bottom
        }
      ]
    }
    return appTour
  }


  setStypeVariableInDocumentNode(dark: boolean, docStyle: any) {
    if (dark) {
      const bg = '#1f262d'; //'rgb(31 41 55)'; 
      docStyle.setProperty('--app-bg', bg);
      docStyle.setProperty('--app-bg-100', this.adjustColor(bg, 36));
      docStyle.setProperty('--app-bg-200', this.adjustColor(bg, 32));
      docStyle.setProperty('--app-bg-300', this.adjustColor(bg, 28));
      docStyle.setProperty('--app-bg-400', this.adjustColor(bg, 24));
      docStyle.setProperty('--app-bg-500', this.adjustColor(bg, 20));
      docStyle.setProperty('--app-bg-600', this.adjustColor(bg, 16));
      docStyle.setProperty('--app-bg-700', this.adjustColor(bg, 12));
      docStyle.setProperty('--app-bg-800', this.adjustColor(bg, 8));
      docStyle.setProperty('--app-bg-900', this.adjustColor(bg, 4));
      document.body.classList.remove('light');
      document.body.classList.add('dark');

    } else {
      const bg = '#ffffff';
      docStyle.setProperty('--app-bg', bg);
      docStyle.setProperty('--app-bg-100', this.adjustColor(bg, -36));
      docStyle.setProperty('--app-bg-200', this.adjustColor(bg, -32));
      docStyle.setProperty('--app-bg-300', this.adjustColor(bg, -28));
      docStyle.setProperty('--app-bg-400', this.adjustColor(bg, -24));
      docStyle.setProperty('--app-bg-500', this.adjustColor(bg, -20));
      docStyle.setProperty('--app-bg-600', this.adjustColor(bg, -16));
      docStyle.setProperty('--app-bg-700', this.adjustColor(bg, -12));
      docStyle.setProperty('--app-bg-800', this.adjustColor(bg, -8));
      docStyle.setProperty('--app-bg-900', this.adjustColor(bg, -4));
      document.body.classList.remove('dark');
      document.body.classList.add('light');
    }
  }

  private adjustColor(color: string, amount: number) {
    return '#' + color.replace(/^#/, '').replace(/../g, (color: string) => ('0' + Math.min(255, Math.max(0, parseInt(color, 16) + amount)).toString(16)).substr(-2));
  }

  setThemeColor(colorCode: string) {
    if (!colorCode) { colorCode = '#ff2567' };
    this._materialCssVarsService.setPrimaryColor(colorCode);
    //this._materialCssVarsService.setAccentColor(this.adjust(colorCode, 24));
    this._fwConfigService.config.colorCode = colorCode;
  }

  set donotShowNicknamePopup(item: DonotShowNickNameSyncDataModel) {
    if (!item) { localStorage.removeItem(DonotShowNickNameSyncDataModel.key); return; }
    localStorage.setItem(DonotShowNickNameSyncDataModel.key, JSON.stringify(item));
  }

  get donotShowNicknamePopup$(): any {
    const item = localStorage.getItem(DonotShowNickNameSyncDataModel.key);
    return item;
  }

  syncNicknameDoNotShowStatus(): void {
    let key = DonotShowNickNameSyncDataModel.key;
    let item = localStorage.getItem(key);
    if (item) {
      let data = JSON.parse(localStorage.getItem(key)) as DonotShowNickNameSyncDataModel;
      var currentTime = new Date().getTime();
      if (data.expiry <= currentTime) {
        localStorage.removeItem(DonotShowNickNameSyncDataModel.key);
      }
    }
  }
}
