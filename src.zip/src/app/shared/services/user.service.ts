import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ReplaySubject, Observable, firstValueFrom } from 'rxjs';
import { map } from 'rxjs/operators';
import { ApiResponse } from 'src/app/shared/models/shared.model';
import { ChangeRoleRequest, ChangeRoleResponse, UserModel, UserStatusEnum, ValidateNickNameResponse } from '../models/user.model';
import { UserSettings } from 'src/app/layout/components/right-panel/settings/settings.models';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private _currentUser: UserModel;
  private _user: ReplaySubject<UserModel> = new ReplaySubject<UserModel>(null);
  private _userSettings: ReplaySubject<UserSettings[]> = new ReplaySubject<UserSettings[]>(null);

  constructor(private _httpClient: HttpClient) {
  }

  getCurrentUser(): UserModel {
    return this._currentUser;
  }

  setCurrentUser(user: UserModel): void {
    this._currentUser = user;
    this._user.next(this._currentUser);
  }

  get user$(): Observable<UserModel> {
    return this._user.asObservable();
  }

  get userSettings$(): Observable<UserSettings[]> {
    return this._userSettings.asObservable();
  }

  getUserDetail(): Observable<UserModel> {
    return this._httpClient.get<ApiResponse<UserModel>>('api/user/details')
      .pipe(map((user: ApiResponse<UserModel>) => {
        if (user.data && !user.data.status) {
          user.data.status = UserStatusEnum.online;
        }
        this._currentUser = new UserModel(user.data);
        this._user.next(this._currentUser);
        return this._currentUser;
      }));
  }

  getUserSettings(): Observable<UserSettings[]> {
    return this._httpClient.get<ApiResponse<UserSettings[]>>('api/user/settings')
      .pipe(map((res: ApiResponse<UserSettings[]>) => {
        this._userSettings.next(res.data);
        return res.data;
      }));
  }

  addUpdateUserSetting(model: UserSettings): Promise<UserSettings> {


    return new Promise((resolve, reject) => {

      if(!model.group) { reject('group is required'); return; };

      this._httpClient.post<ApiResponse<UserSettings>>('api/user/settings/update', model)
        .subscribe({
          next: async (res) => {
            if (res.data) {
              let defaultSettings = await firstValueFrom(this._userSettings);
              if (defaultSettings) {
                let setting = defaultSettings.find(s => s.key == res.data.key);
                if (setting) {
                  setting.value = res.data.value;
                } else {
                  defaultSettings.push(res.data);
                }
                this._userSettings.next(defaultSettings);
              }             
              resolve(res.data);
            }
          },
          error: (err) => {
            reject(err);
          }
        })
    })
  }

  linkedInCall() {
    return this._httpClient.get<ApiResponse<any>>('api/user/linkedInProfile')
      .pipe(map((res: ApiResponse<any>) => {
        return res.data;
      }));
  }

  async isHost(user: UserModel): Promise<boolean> {
    if (!user || !user.userRoles || !user.userRoles.length) {
      return false;
    }
    const roles = ['host'];
    return user.userRoles.some((role) => {
      return role.isEnabled && roles.includes(role.systemName.toLocaleLowerCase());
    });
  }

  isCoHost(user: UserModel): boolean {
    if (!user || !user.userRoles || !user.userRoles.length) {
      return false;
    }
    const roles = ['co_host'];
    return user.userRoles.some((role) => {
      return role.isEnabled && roles.includes(role.systemName.toLocaleLowerCase());
    });
  }

  isHostOrCoHost(user: UserModel): boolean {
    if (!user || !user.userRoles || !user.userRoles.length) {
      return false;
    }
    const roles = ['host', 'co_host'];
    return user.userRoles.some((role) => {
      return role.isEnabled && roles.includes(role.systemName.toLocaleLowerCase());
    });
  }

  isPresenter(user: UserModel): boolean {
    if (!user || !user.userRoles || !user.userRoles.length) {
      return false;
    }
    const roles = ['presenter'];
    return user.userRoles.some((role) => {
      return role.isEnabled && roles.includes(role.systemName.toLocaleLowerCase());
    });
  }

  isAttendee(user: UserModel): boolean {
    if (!user || !user.userRoles || !user.userRoles.length) {
      return false;
    }
    const roles = ['attendee'];
    const excludedRoles = ['host', 'co_host', 'presenter']
    return user.userRoles.some((role) => {
      return role.isEnabled && roles.includes(role.systemName.toLocaleLowerCase()) &&
        !excludedRoles.includes(role.systemName.toLocaleLowerCase());
    });
  }

  static getShortName(name: string): string {
    const fullname = name.split(' ');
    return fullname.map((n, i) => (i === 0 || i === fullname.length - 1) && n[0]).filter(n => n).join('');
  }

  async getChannelRole(user: UserModel): Promise<string> {
    if (!user) {
      return '';
    }

    if (!user.userRoles || !user.userRoles.length) {
      return '';
    }

    // TODO
    if (user.userRoles.findIndex((x) => x.systemName === 'attendee')) {
      return 'attendee';
    }

    return '';
  }

  // Change Other user's role by host/cohost
  changeUserRole(req: ChangeRoleRequest): Observable<ChangeRoleResponse> {
    return this._httpClient.post<ApiResponse<ChangeRoleResponse>>('api/user/change-role', req)
      .pipe(map((res: ApiResponse<ChangeRoleResponse>) => {
        return res.data;
      }));
  }

  updateUserDetail(model: UserModel): Promise<any> {
    return new Promise((resolve, reject) => {
      this._httpClient.post<ApiResponse<any>>('api/user/update-user', model)
        .subscribe({
          next: (res) => {
            if (res.data && res.data.status) {
              this._currentUser.firstName = model.firstName;
              this._currentUser.lastName = model.lastName;
              this._currentUser.phone = model.phone;
              this._currentUser.title = model.title;
              this._currentUser.about = model.about;
              this._currentUser.fullName = this._currentUser.getFullName();
              this._user.next(this._currentUser);
              resolve(res.data);
            }
          },
          error: (err) => {
            reject(err);
          }
        })
    })
  }

  validateNickName(nickName: string): Observable<ValidateNickNameResponse> {
    return this._httpClient.post<ApiResponse<ValidateNickNameResponse>>('api/user/validate-nickname', { nickName })
      .pipe(map((res: ApiResponse<ValidateNickNameResponse>) => {
        return res.data;
      }))
  }

  saveNickName(nickName: string): Observable<ValidateNickNameResponse> {
    return this._httpClient.post<ApiResponse<ValidateNickNameResponse>>('api/user/save-nickname', { nickName })
      .pipe(map((res: ApiResponse<ValidateNickNameResponse>) => {
        return res.data;
      }))
  }
}
