import { Component, Inject, Injectable, OnDestroy, inject } from '@angular/core'
import { MatButtonModule } from '@angular/material/button'
import { MatIconModule } from '@angular/material/icon'
import { MAT_SNACK_BAR_DATA, MatSnackBar, MatSnackBarModule, MatSnackBarRef } from '@angular/material/snack-bar'
import { MatTooltipModule } from '@angular/material/tooltip'
import { CountdownModule } from 'ngx-countdown'
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { FwCoreModule } from 'src/app/core/fw.core.module'
import { UserSettings, UserSettingsKeys } from 'src/app/layout/components/right-panel/settings/settings.models'
import { UserService } from 'src/app/shared/services/user.service'

@Injectable({
  providedIn: 'root'
})
export class MessageService {
  constructor(private snackBar: MatSnackBar) {

  }

  showSuccessMessage(message: string, autoHide: boolean = true, timeInSeconds?: number) {
    if (message) {
      this.openSnackBar(message, autoHide, 'success-message', timeInSeconds)
    }
  }

  showInfoMessage(message: string, autoHide: boolean = true, timeInSeconds?: number) {
    if (message) {
      this.openSnackBar(message, autoHide, 'info-message', timeInSeconds)
    }
  }

  showErrorMessage(message: string, autoHide: boolean = true, timeInSeconds?: number) {
    this.openSnackBar(message, autoHide, 'error-message', timeInSeconds)
  }

  showBroadcastMessageNotification(message: string, autoHide?: boolean, timeInSeconds?: number) {

    let duration = undefined;
    if(autoHide) duration = 10000;
    if(timeInSeconds){
      duration = timeInSeconds * 1000;
    }

    this.snackBar.openFromComponent(BroadcastMessageAnnotatedComponent, {
      duration: duration,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      politeness: 'polite',
      panelClass: ['info-message'],
      data: message
    })
  }

  private openSnackBar(message: string, autoHide?: boolean, panelClass?: string, timeInSeconds?: number) {

    let duration = 120000;
    if(timeInSeconds){
      duration = timeInSeconds * 1000;
    }
    if(panelClass == 'error-message') {
      autoHide = true;
    }    
    if(autoHide) { duration = 10000; } else { duration = undefined }

    this.snackBar.openFromComponent(CustomToastAnnotatedComponent, {
      duration: duration,
      horizontalPosition: 'center',
      verticalPosition: 'top',
      politeness: 'polite',
      panelClass: [panelClass],
      data: { message },
    })
  }

  public playUserJoinEventTone() {
    const audio = new Audio()
    audio.src = './assets/audio/user-joined.mp3'
    audio.load()
    audio.play()
  }

  async getSampleAudioPlayer(): Promise<HTMLAudioElement> {
    const audio = new Audio()
    audio.src = './assets/audio/sample.mp3'
    audio.load()
    return audio
  }
}

@Component({
  template: `
  <span matSnackBarLabel [innerHtml]="data.message">
  </span>
  <span matSnackBarActions>
    <button mat-button matSnackBarAction (click)="snackBarRef.dismissWithAction()">x</button>
  </span>`,
  styles: [
    `
    :host {
      display: flex;
    }
  `,
  ],
  standalone: true,
  imports: [FwCoreModule, MatButtonModule, MatSnackBarModule],
})
export class CustomToastAnnotatedComponent {
  snackBarRef = inject(MatSnackBarRef);
  constructor(@Inject(MAT_SNACK_BAR_DATA) public data: any) {   
  }
}

@Component({
  template: `
  <span matSnackBarLabel [innerHtml]="data">
  </span>
  <span matSnackBarActions>
    <countdown class="mr-4" *ngIf="isDurationAvaialble" #countdwn [config]="{leftTime: duration, notify: 0, format: countdownFormat }"></countdown>
    <button mat-icon-button [matTooltip]="notificationEnabled ? 'Disable Alerts' : 'Enable Alerts'" (click)="updateNotificationAlertsSetting(notificationEnabled)" matSnackBarAction>
      <mat-icon *ngIf="notificationEnabled">notifications</mat-icon>
      <mat-icon *ngIf="!notificationEnabled">notifications_off</mat-icon>
    </button>    
    <button mat-icon-button matSnackBarAction (click)="snackBarRef.dismissWithAction()"><mat-icon>close</mat-icon></button>
  </span>`,
  styles: [
    `
    :host {
      display: flex;
      padding:2px;
    }
  `,
  ],
  standalone: true,
  imports: [FwCoreModule, MatButtonModule, MatIconModule, MatSnackBarModule, MatTooltipModule, CountdownModule],
})
export class BroadcastMessageAnnotatedComponent implements OnDestroy {
  private _unsubscribeAll: Subject<any> = new Subject<any>();
  isDurationAvaialble: boolean;
  countdownFormat = 'mm:ss';
  duration: number;
  snackBarRef = inject(MatSnackBarRef);
  userSettings: UserSettings[];
  notificationEnabled: boolean = true;

  constructor(
    @Inject(MAT_SNACK_BAR_DATA) public data: any,
    private _userService: UserService) {

    let config = this.snackBarRef.containerInstance.snackBarConfig;
    this.isDurationAvaialble = config.duration != null || config.duration != undefined;
    this.duration = config.duration / 1000;

    this._userService.userSettings$.pipe(takeUntil(this._unsubscribeAll)).subscribe(settings => {
      this.userSettings = settings;
    });
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next(true);
    this._unsubscribeAll.complete();
  }

  async updateNotificationAlertsSetting(value: boolean): Promise<void> {
    let setting = this.userSettings.find(s => s.key == UserSettingsKeys.disableAlert);
    if (setting == null) {
      setting = new UserSettings();
      setting.key = UserSettingsKeys.disableAlert;
    }
    this.notificationEnabled = !value;
    setting.value = this.notificationEnabled;    
    await this._userService.addUpdateUserSetting(setting);
  }

}
