import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, ReplaySubject } from 'rxjs';
import { map, switchMap, take } from 'rxjs/operators';
import { AddNotificationResponse, NotificationListModel, NotificationModel } from '../models/notifications.models';
import { ApiResponse } from 'src/app/shared/models/shared.model';

@Injectable({
  providedIn: 'root'
})
export class NotificationsService {
  private _unreadNotifications: BehaviorSubject<NotificationListModel> = new BehaviorSubject<NotificationListModel>({ notifications: [], meta: { totalCount: 0, pageIndex: 0, pageSize: 10 } });
  private _notifications: ReplaySubject<NotificationListModel> = new ReplaySubject<NotificationListModel>(1);

  constructor(private _httpClient: HttpClient) {
  }

  get unreadNotifications$(): Observable<NotificationListModel> {
    return this._unreadNotifications.asObservable();
  }

  get notifications$(): Observable<NotificationListModel> {
    return this._notifications.asObservable();
  }

  getUnreadNotifications(): Observable<NotificationListModel> {
    const loadUnreadParam = { onlyUnread: true };
    return this._httpClient.get<ApiResponse<NotificationListModel>>('api/user/notifications', { params: loadUnreadParam })
      .pipe(map((notifications) => {
        this._unreadNotifications.next(notifications.data);
        return notifications.data;
      }))
  }

  getNotifications(params: any): Observable<NotificationListModel> {
    return this._httpClient.get<ApiResponse<NotificationListModel>>('api/user/notifications', { params })
      .pipe(map((notifications) => {
        this._notifications.next(notifications.data);
        return notifications.data;
      }))
  }

  deleteNotification(id: number): Observable<boolean> {
    return this.notifications$.pipe(
      take(1),
      switchMap(notifications => this._httpClient.delete<boolean>('api/user/delete-notification', { params: { id } }).pipe(
        map((isDeleted: boolean) => {
          const index = notifications.notifications.findIndex(item => item.notificationId === id);
          notifications.notifications.splice(index, 1);
          this._notifications.next(notifications);
          this.getUnreadNotifications().subscribe();
          return isDeleted;
        })
      ))
    );
  }

  updateNotifications(model: { notificationIds: number[], isMarkedAsRead: boolean }): Observable<boolean> {
    return this.notifications$.pipe(
      take(1),
      switchMap(list => this._httpClient.post<boolean>('api/user/update-notifications', model).pipe(
        map((isUpdated: boolean) => {
          list.notifications.forEach((notification, index) => {
            if (model.notificationIds.includes(notification.notificationId)) {
              notification.isMarkedAsRead = true;
            }
          });
          this._notifications.next(list);
          this.getUnreadNotifications().subscribe();
          return isUpdated;
        })
      ))
    );
  }

  addUserNotification(model: NotificationModel): Observable<AddNotificationResponse> {
    return this._httpClient
      .post<ApiResponse<AddNotificationResponse>>('api/user/add-notification', model)
      .pipe(map(resp => resp.data));
  }
}
