import { HttpClient } from '@angular/common/http'
import { Inject, Injectable } from '@angular/core'
import { BehaviorSubject, firstValueFrom, interval, Observable, of, ReplaySubject } from 'rxjs'
import { map, switchMap } from 'rxjs/operators'
import { RoomModel } from 'src/app/modules/rooms/room/room.models'
import { UserModel } from 'src/app/shared/models/user.model'
import { UserService } from 'src/app/shared/services/user.service'
import {
  EventHandoutsModel,
  EventModel,
  EventScheduleModel,
  EventSpeakerModel, EventSponsorModel, RoomNavigationModel
} from '../models/event.model'
import { ApiResponse } from '../models/shared.model';
import { AppSettingService } from 'src/app/shared/services/appsetting.service'

@Injectable({
  providedIn: 'root'
})
export class EventService {

  static instance: EventService;
  private _event: BehaviorSubject<EventModel | null> = new BehaviorSubject(null);
  private _rooms: BehaviorSubject<RoomModel[] | null> = new BehaviorSubject(null);
  private _schedules: BehaviorSubject<EventScheduleModel[] | null> = new BehaviorSubject(null);
  private _speakers: BehaviorSubject<EventSpeakerModel[] | null> = new BehaviorSubject(null);
  private _sponsors: BehaviorSubject<EventSponsorModel[] | null> = new BehaviorSubject(null);
  private _handouts: BehaviorSubject<EventHandoutsModel[] | null> = new BehaviorSubject(null);
  private _attendees: BehaviorSubject<UserModel[] | null> = new BehaviorSubject(null);
  private _navigations: ReplaySubject<RoomNavigationModel[]> = new ReplaySubject<RoomNavigationModel[]>(1);
  
  constructor(
    private _appConfig: AppSettingService,
    private _httpClient: HttpClient,
    private _userService: UserService) {
    EventService.instance = this;
  }

  get navigations$(): Observable<RoomNavigationModel[]> {
    return this._navigations.asObservable()
  }

  get event$(): Observable<EventModel> {
    return this._event.asObservable()
  }

  get rooms$(): Observable<RoomModel[]> {
    return this._rooms.asObservable()
  }

  get schedules$(): Observable<EventScheduleModel[]> {
    return this._schedules.asObservable()
  }

  get speakers$(): Observable<EventSpeakerModel[]> {
    return this._speakers.asObservable()
  }

  get sponsors$(): Observable<EventSponsorModel[]> {
    return this._sponsors.asObservable()
  }

  get handouts$(): Observable<EventHandoutsModel[]> {
    return this._handouts.asObservable()
  }

  get attendees$(): Observable<UserModel[]> {
    return this._attendees.asObservable()
  }

  clearCache(): Observable<any> {
    return this._httpClient.get<ApiResponse<any>>('api/event/clear-cache', {
      params: {}
    }).pipe(map((res) => {
      return res.data;
    })
    )
  }

  getEvent(): Observable<EventModel> {
    return this._httpClient.get<ApiResponse<EventModel>>('api/event/details', {
      params: {}
    }).pipe(map((res: ApiResponse<EventModel>) => {
      this._event.next(res.data);
      return res?.data
    }))
  }

  getRooms(): Observable<RoomModel[]> {
    return this._httpClient.get<ApiResponse<RoomModel[]>>('api/event/rooms', {
      params: {}
    }).pipe(map((res) => {
      if (res && res.data) {
        firstValueFrom(this._userService.user$).then(user => {
          if (user) {
            const isHostOrCoHost = this._userService.isHostOrCoHost(user);
            if (isHostOrCoHost || user.isSystemUser()) {
              res.data?.forEach(r => { r.settings.isRoomAccessible = true });
            }
            this._prepareNavigations(res.data);
            this._rooms.next(res.data);
          }
        });
      }
      return res.data;
    }))
  }

  getSchedules(): Observable<EventScheduleModel[]> {
    return this._httpClient.get<ApiResponse<EventScheduleModel[]>>('api/event/schedules', {
      params: {}
    }).pipe(map((res) => {
      this._schedules.next(res.data);
      return res.data;
    })
    )
  }

  getSpeakers(): Observable<EventSpeakerModel[]> {
    return this._httpClient.get<ApiResponse<EventSpeakerModel[]>>('api/event/speakers', {
      params: {}
    }).pipe(map((res) => {
      res?.data?.forEach(d => {
        if (d.imagePath) { d.imagePath = this._appConfig.settings.resourceBaseUrl + d.imagePath; }
      });
      this._speakers.next(res.data);
      return res.data;
    })
    )
  }

  getSponsors(): Observable<EventSponsorModel[]> {
    return this._httpClient.get<ApiResponse<EventSponsorModel[]>>('api/event/sponsors', {
      params: {}
    }).pipe(map((res) => {
      res?.data?.forEach(d => {
        if (d.imagePath) { d.imagePath = this._appConfig.settings.resourceBaseUrl + d.imagePath; }
      });
      this._sponsors.next(res.data);
      return res.data;
    })
    )
  }

  getHandouts(): Observable<EventHandoutsModel[]> {
    return this._httpClient.get<ApiResponse<EventHandoutsModel[]>>('api/event/handouts', {
      params: {}
    }).pipe(
      map((handouts: ApiResponse<EventHandoutsModel[]>) => {
        this._handouts.next(handouts.data);
        return handouts.data;
      })
    )
  }

  getAttendees(): Observable<UserModel[]> {
    return this._httpClient.get<ApiResponse<UserModel[]>>('api/event/attendees', {
      params: {}
    }).pipe(
      map((attendess: ApiResponse<UserModel[]>) => {
        this._attendees.next(attendess.data?.map(u => new UserModel(u)));
        return attendess.data;
      })
    )
  }

  getEventId(): number {
    return this._event.getValue()?.eventId;
  }

  getRoomId(roomType: string): number {
    return this._rooms.getValue()?.find(x => x.roomType === roomType)?.roomId;
  }

  getSchedulesFromObserver(): EventScheduleModel[] {
    return this._schedules.value;
  }

  findAttendee(userId: number): UserModel {
    const att = this._attendees.value?.find(a => a.userId === userId);
    return att;
  }

  findRoom(roomId: number): RoomModel {
    if (!roomId || roomId <= 0) {
      return undefined;
    }
    let room = this._rooms.value?.find(a => a.roomId === roomId);
    if (!room) {
      const booths = this._rooms.value?.flatMap(r => { return r.booths });
      room = booths.find(r => r.roomId === roomId);
    }
    return room;
  }

  getHostOrCohostIds(): number[] {
    return this._attendees.value?.filter(x => x.isHostOrCoHost()).map(u => u.userId);
  }

  private _prepareNavigations(rooms: RoomModel[]) {
    let hostCoHost = this.isCurrentUserHostOrCohost();
    const navigations = rooms?.filter(r => r.settings.isRoomAccessible && (hostCoHost || r.settings.isEnabled))?.map(m => {
      return {
        roomId: m.roomId,
        isEnabled: true,
        roomName: m.roomName,
        roomType: m.roomType,
        children: m.booths.filter(r => r.settings.isRoomAccessible)?.map(b => {
          return {
            roomId: b.roomId,
            roomName: b.roomName,
            roomType: b.roomType,
            isEnabled: true
          } as RoomNavigationModel
        })
      } as RoomNavigationModel
    });
    this._navigations.next(navigations);
  }

  updateRoomNavigationOnRoleChange(): void {
    if (this._rooms.value) {
      this._prepareNavigations(this._rooms.value);
    }
  }

  updateEventData(model: EventModel): Observable<boolean> {
    return this._httpClient
      .post<ApiResponse<boolean>>('api/event/update', model)
      .pipe(map((res: ApiResponse<boolean>) => {
        return res.data;
      }), switchMap((room) => {
        return of(room);
      }));
  }

  isNicknameEnabled(): boolean {
    return this._event.getValue()?.settings?.nicknameEnabled;
  }

  isCurrentUserHostOrCohost(): boolean {
    let hostOrCoHost = this._userService.getCurrentUser()?.isHostOrCoHost();
    return hostOrCoHost;
  }
}
