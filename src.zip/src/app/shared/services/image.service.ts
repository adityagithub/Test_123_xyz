import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { ImageViewModel } from "../models/event.model";
import { ApiResponse } from "../models/shared.model";

@Injectable({
    providedIn: 'root'
})
export class ImageService {

    constructor(private _httpClient: HttpClient) {
    }

    uploadImage(image: File): Promise<ImageViewModel> {
        return new Promise<ImageViewModel>((resolve, reject) => {
            var param = new FormData();
            param.append("file", image);
            this._httpClient.post<ApiResponse<ImageViewModel>>('api/image/upload', param)
                .subscribe({
                    next: (res) => {
                        resolve(res.data);
                    },
                    error: (err) => {
                        reject(err);
                    }
                })
        })
    }

    deleteImage(imageId: number): Promise<boolean> {
        return new Promise<boolean>((resolve, reject) => {
            this._httpClient.post<ApiResponse<boolean>>('api/image/delete', { imageId })
                .subscribe({
                    next: (res) => {
                        resolve(res.data);
                    },
                    error: (err) => {
                        reject(err);
                    }
                })
        })
    }

    getImage(url: string): Promise<File> {
        return new Promise<File>((resolve, reject) => {
            fetch(url).then(async (res) => {
                if(!res){ reject('res null') }
                if (res) {
                  const blob = await res.blob();
                  if (blob.size) {
                    resolve(blob as File);
                  }
                }
              }).catch(err => reject(err));
        })
    }
}
