import { Inject, Injectable } from '@angular/core'
import { HubConnection, HubConnectionBuilder, LogLevel } from '@microsoft/signalr'
import { Subject, from, Observable, throwError } from 'rxjs'
import { AuthService } from 'src/app/modules/auth/auth.service';
import { UserModel } from 'src/app/shared/models/user.model';
import { UserService } from 'src/app/shared/services/user.service';
import {
  ChatDataModel, CommandType, SignalDataContent, JoinEventModel, JoinRoomModel,
  LeaveRoomModel, SignalDataModel, SignalLevel, SignalrDefaults, LiveRoomProperties
} from '../models/signalr.models';
import { AppSettingService } from 'src/app/shared/services/appsetting.service';

@Injectable({
  providedIn: 'root'
})
export class SignalrService {
  private _onNewMessage: Subject<ChatDataModel> = new Subject();
  private _onNewSignal: Subject<SignalDataModel> = new Subject();
  private _onBackendUpdated: Subject<SignalDataModel> = new Subject();
  private _onClientReconnected: Subject<SignalDataModel> = new Subject();

  private _hubConnection: HubConnection;

  constructor(
    private _appSetting: AppSettingService,
    private _authService: AuthService,
    private _userService: UserService) {

  }

  _init(): Observable<void> {
    this._hubConnection = this.createConnection();
    if (!this._hubConnection) { return throwError(() => new Error('Failed to create Web Socket Connection')) }
    const observable = from(this._hubConnection.start());
    this.registerHandlers();
    return observable;
  }

  startSignalR(p: any): void {
    this._init().subscribe(res => p(res));
  }

  stopSignalR(p: any): void {
    this._hubConnection.stop().then(res => p(res));
  }

  private registerHandlers(): Observable<any> {
    if (!this._hubConnection) { return throwError(() => new Error('Failed to create Web Socket Connection')) }
    this._hubConnection.on(SignalrDefaults.onNewMessage, (args: any) => this.handleNewMessage(args));
    this._hubConnection.on(SignalrDefaults.onNewSignal, (args: any) => this.handleNewSignal(args));
    this._hubConnection.on(SignalrDefaults.onBackendUpdated, (args: any) => this.handleBackendUpdated(args));
    this._hubConnection.on(SignalrDefaults.onError, (args: any) => this.handleError(args));
    this._hubConnection.onreconnected((args: any) => this.handleClientReconnected(args));
    this._hubConnection.onclose((args: any) => this.handleClientReconnected(args));
  }

  private createConnection(): HubConnection {
    return new HubConnectionBuilder()
      .withUrl(`${this._appSetting.settings.baseUrl}/clientHub`, { accessTokenFactory: () => this._authService.accessToken })
      .withAutomaticReconnect()
      .configureLogging(LogLevel.Debug)
      .build();
  }

  private async handleNewMessage(args: any): Promise<void> {
    this._onNewMessage.next(args);
  }

  private async handleNewSignal(args: any): Promise<void> {
    this._onNewSignal.next(args);
  }

  private async handleError(args: any): Promise<void> {
    console.error('SIGNALR ERROR', args)
  }

  private async handleClientReconnected(args: any): Promise<void> {
    this._init().subscribe(async s => { 
      this._onClientReconnected.next(args);
      await this.sendReconnectedSignal();
    });    
  }

  private async handleBackendUpdated(args: any): Promise<void> {
    this._onBackendUpdated.next(args);
  }

  get onClientReconnected$(): Observable<any> {
    return this._onClientReconnected.asObservable();
  }

  get onNewMessage$(): Observable<ChatDataModel> {
    return this._onNewMessage.asObservable();
  }

  get onNewSignal$(): Observable<SignalDataModel> {
    return this._onNewSignal.asObservable();
  }

  get onBackendUpdated$(): Observable<SignalDataModel> {
    return this._onBackendUpdated.asObservable();
  }

  async sendSignal(data: SignalDataModel): Promise<any> {
    return await this._hubConnection.invoke(SignalrDefaults.sendSignal, data).catch((res) => {
      console.log(res, '_hubConnection.invoke(SignalrDefaults.sendSignal');
    });
  }

  async sendMessage(msg: ChatDataModel): Promise<any> {
    return await this._hubConnection.invoke(SignalrDefaults.sendMessage, msg).catch((res) => {
      console.log(res, '_hubConnection.invoke(SignalrDefaults.sendMessage');
    });
  }

  async joinEvent(data?: JoinEventModel): Promise<any> {
    return await this._hubConnection.invoke(SignalrDefaults.joinEvent, data).catch((res) => {
      console.log(res, '_hubConnection.invoke(SignalrDefaults.joinEvent');
    });
  }

  async joinRoom(data: JoinRoomModel): Promise<SignalDataContent[]> {
    return await this._hubConnection.invoke(SignalrDefaults.joinRoom, data).catch((res) => {
      console.log(res, '_hubConnection.invoke(SignalrDefaults.joinRoom');
    });
  }

  async leaveRoom(data: LeaveRoomModel): Promise<any> {
    return await this._hubConnection.invoke(SignalrDefaults.leaveRoom, data).catch((res) => {
      console.log(res, '_hubConnection.invoke(SignalrDefaults.leaveRoom');
    });
  }

  async getEventAttendees(eventId: number): Promise<SignalDataContent[]> {
    return await this._hubConnection.invoke<SignalDataContent[]>(SignalrDefaults.getEventUserStatus, { eventId });
  }

  async getRaisedHandAttendees(eventId: number): Promise<SignalDataContent[]> {
    return await this._hubConnection.invoke<SignalDataContent[]>(SignalrDefaults.getRaisedHandAttendees, { eventId });
  }

  async getRoomAttendees(roomId: number): Promise<SignalDataContent[]> {
    return await this._hubConnection.invoke<SignalDataContent[]>(SignalrDefaults.getRoomAttendees, { roomId });
  }

  async sendMuteUnmuteSignal(mute: boolean, targetUser: UserModel): Promise<any> {
    return new Promise((resolve, reject) => {
      const currentUser = this._userService.getCurrentUser();
      if (!currentUser.isHostOrCoHost()) {
        reject(new Error('You are not authorized to perform this action!'));
      }
      if (targetUser.isHostOrCoHost()) {
        reject(new Error('Host or Co-Host can not be muted!'));
      }
      const signalDataModel = {
        receiverId: targetUser.userId,
        command: mute ? CommandType.muteAttendee : CommandType.unmuteAttendee,
        signalLevel: SignalLevel.person,
        data: {}
      } as SignalDataModel;
      this.sendSignal(signalDataModel).then(res => {
        resolve(true);
      }, () => resolve(false));
    });
  }

  async sendKickoutSignal(targetUser: UserModel): Promise<any> {
    return new Promise((resolve, reject) => {
      const currentUser = this._userService.getCurrentUser();
      if (!currentUser.isHostOrCoHost()) {
        reject(new Error('You are not authorized to send this command!'));
      }
      if (targetUser.isHostOrCoHost()) {
        reject(new Error('Host or Co-Host can not be muted!'));
      }
      const signalDataModel = {
        receiverId: targetUser.userId,
        command: CommandType.kickoutAttendee,
        signalLevel: SignalLevel.person,
        data: {}
      } as SignalDataModel;
      this.sendSignal(signalDataModel).then(res => {
        resolve(true);
      }, () => resolve(false));
    });
  }

  async sendSignalToUsers(model: SignalDataModel): Promise<any> {
    return new Promise((resolve, reject) => {
      const currentUser = this._userService.getCurrentUser();
      if (!currentUser.isHostOrCoHost()) {
        reject(new Error('You are not authorized to send this command!'));
      }
      const signalDataModel = {
        receiverIds: model.receiverIds,
        receiverType: model.receiverType,
        command: model.command,
        signalLevel: SignalLevel.persons,
        data: model.data
      } as SignalDataModel;
      this.sendSignal(signalDataModel).then(res => {
        resolve(true);
      }, () => resolve(false));
    });
  }

  async sendReconnectedSignal(): Promise<any> {
    return new Promise((resolve, reject) => {     
      const signalDataModel = {
        command: CommandType.remoteClientReconnected,
        signalLevel: SignalLevel.event,
        data: {}
      } as SignalDataModel;
      this.sendSignal(signalDataModel).then(res => {
        resolve(true);
      }, () => reject(true));
    });
  }
}
