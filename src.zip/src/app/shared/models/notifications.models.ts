import { PagingDataModel } from 'src/app/shared/models/shared.model';
import { UserModel } from './user.model';

export interface NotificationModel {
    notificationId: number;
    notificationSentBy: number;
    notificationSentFor: string;
    sender: UserModel;
    eventId: number;
    virtualEventId: number;
    notificationDate: Date;
    notificationMessage: string;
    /// <summary>
    /// Alert | Invite | CallMissed | Blocked | UnBlocked , Will change to enum
    /// </summary>
    notificationType: string;
    isMarkedAsRead: boolean
}

export interface NotificationListModel {
    notifications: NotificationModel[];
    meta: PagingDataModel
}

export interface UpdateNotificationModel {
    notificationIds: number[]
}

export interface AddNotificationResponse {
    status: boolean;
}
