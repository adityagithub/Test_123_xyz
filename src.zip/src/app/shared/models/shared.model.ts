
export interface MenuItem {
  id: number,
  name: string,
  icon: string,
  systemName: string,
  active: boolean
}

export enum StatusCode {
  'ok' = 200,
  'badRequest' = 400,
  'error' = 500,
  'unAuthorized' = 401
}

export interface ApiResponse<T> {

  version: string,
  statusCode: StatusCode,
  messages: string[],
  data: T
}

export interface PagingDataModel {
  pageIndex: number;
  pageSize: number;
  totalCount: number;
}

export interface LoginResult {
  token: string,
  sessionId: string;
}

export interface Entry {
  created: Date;
  end: Date;
  id: string;
}

export interface TimeSpan {
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

export interface MetaInfo {
  TotalRecords: number
}

export abstract class BaseSearchModel {
  Search: string;
  PageIndex: number;
  PageSize: number;
}

export abstract class BasePagedListModel<T> {
  Data: T[];
  Meta: MetaInfo;
}

export const AttendeeAction = {
  RoleChange: 'role-change',
  AttendeeInfo: 'attendee-info',
  BlockUser: 'block-user',
  UnBlockUser: 'unblock-user',
  InviteMember: 'invite-user',
  OpenChat: 'open-chat'
}

export class DonotShowNickNameSyncDataModel {
  static key: string = 'fw.nickname.show.again'
  expiry: number;
}