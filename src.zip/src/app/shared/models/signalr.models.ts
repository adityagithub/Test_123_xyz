import { UserRoleModel, UserStatusEnum } from "src/app/shared/models/user.model";
import { PagingDataModel } from "./shared.model";
import { RecordingInfoPayload } from "src/app/modules/rooms/room/conference/conference.model";

interface BaseSignalrRequestModel {

}

export enum CommandType {
  eventDataUpdated = 1,
  roomDataUpdated = 2,
  attendeeDataUpdated = 3,
  speakerDataUpdated = 4,
  scheduleDataUpdated = 5,
  handoutsDataUpdated = 6,
  sponsorsDataUpdated = 7,
  pollsDataUpdated = 8,
  pushPollResult = 9,
  memberRoleChange = 10,
  muteAttendee = 11,
  unmuteAttendee = 12,
  kickoutAttendee = 13,
  moveToAnotherRoom = 14,
  attendeeJoined = 15,
  attendeeLeft = 16,
  newNotification = 17,
  raiseHand = 18,
  lowerHand = 19,
  raiseHandApproved = 20,
  raiseHandRejected = 21,
  allRaisedHandApproved = 22,
  allRaisedHandRejected = 23,
  userStatusChanged = 24,
  openBreakoutRooms = 25,
  closeBreakoutRooms = 26,
  messageToBreakoutRooms = 27,
  removeBreakoutAttendee = 28,
  deleteBreakoutRooms = 29,
  breakoutRoomsUpdated = 30,
  profileUpdated = 31,
  messageToEvent = 32,
  messageToRooms = 33,
  recordingStateChange = 34,
  recordingTimerChange = 35,
  hideFromScreen = 36,
  customizationByHostCohost = 37,
  remoteClientReconnected = 38
}

export class SignalrDefaults {
  static onError = 'error';

  static onUserStatusChanged = 'on_user_status_changed';

  static addUserInEvent = 'add_user_in_event';
  static addUserInRoom = 'add_user_in_room';

  static removeUserFromEvent = 'remove_user_from_event';
  static removeUserFromRoom = 'remove_user_from_room';

  static joinEvent = 'join_event';
  static joinRoom = 'join_room';
  static joinRoomGroup = 'join_room_group';

  static onNewMessage = 'on_new_message';
  static onNewSignal = 'on_new_signal';

  static onBackendUpdated = 'on_data_updated'

  static sendMessage = 'send_message';
  static sendSignal = 'send_signal';

  static leaveEvent = 'leave_event';
  static leaveRoom = 'leave_room';
  static leaveRoomGroup = 'leave_room_group';

  static getRoomAttendees = 'get_room_attendees';
  static getEventUserStatus = 'get_event_attendees';
  static getRaisedHandAttendees = "get_raised_hand_attendees";
  static getLiveRoomProperties = "get_live_room_properties";
}

export interface SignalDataContent {
  userId: number;
  eventId: number;
  roomId?: number;
  roomName: string;
  pollId?: number;
  handRaised: boolean;
  status: UserStatusEnum;
  userRoles: UserRoleModel[];
  extra: any;
}

export enum SignalLevel {
  person = 0,
  room = 1,
  event = 2,
  persons = 3,
  rooms = 4
}

export interface SignalDataModel {
  receiverIds: number[];
  receiverId: number;
  receiverType: string;
  command: CommandType;
  signalLevel: SignalLevel;
  data: SignalDataContent;
}

export enum ChatSectionType {
  'private' = 0,
  'room' = 1,
  'event' = 2,
}

export interface ChatDataModel {
  messageId: string;
  senderId: number;
  senderName: string;
  avatarUrl: string;
  alt: string;
  receiverId: number;
  receiverName: string;
  message: string;
  createdDateUtc: Date;
  messageType: 'text' | 'emoji' | 'raw' | 'img' | 'attachment';
  chatSection: ChatSectionType,
  isHost: boolean
}

export interface ChatsDataModel {
  senderId: number;
  senderName: string;
  receiverId: number;
  receiverName: string;
  receiverType: ChatSectionType;
  chats: ChatDataModel[];
}

export interface ChatPagedDataModel {
  chats: ChatDataModel[],
  meta: PagingDataModel
}

export interface JoinEventModel extends BaseSignalrRequestModel {
  eventId: number;
}

export interface JoinRoomModel extends BaseSignalrRequestModel {
  roomId: number;
  roomType: string;
}

export interface LeaveRoomModel extends BaseSignalrRequestModel {
  roomId: number;
  roomType: string;
}

export interface UserStatusRequstModel {

}

export interface LiveRoomProperties {
  roomId: number;
  isLive: boolean; 
  recordingInfo: RecordingInfoPayload;
}
