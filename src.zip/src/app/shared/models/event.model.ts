import { RoomModel, RoomType } from 'src/app/modules/rooms/room/room.models';

export class ImageViewModel {
  constructor() {
    this.imageId = 0;
    this.file = null;
    this.isModified = false;
    this.imageType = 0;
    this.imagePath = "";
  }
  imageId: number
  origionalFilename: string
  fileName: string
  imagePath: string
  filePath: string
  roomId: number
  imageType: number
  file: File;
  isModified: boolean;
}

export interface EventSettingsModel {
  scheduleLabel: string;
  speakerLabel: string;
  sponsorLabel: string;
  attendeeLabel: string;
  chatBlockingWords: string;
  breakoutRoomsEnabled: boolean;
  roomJumpingEnabled: boolean;
  silentAuctionEnabled: boolean;
  donationButtonEnabled: boolean;
  speakersEnabled: boolean;
  sponsorsEnabled: boolean;
  schedulesEnabled: boolean;
  backgroundImageEnabled: boolean;
  fireworksActivityEnabled: boolean;
  attendeesCountEnabled: boolean;
  peopleSectionEnabled: boolean;
  nicknameEnabled: boolean;
  downloadChatsForAttendeeEnabled: boolean;
}

export interface EventSponsorModel {
  sponsorId: number;
  sponsorName: string;
  sponsorUrl: string;
  imagePath: string;
}

export interface EventSpeakerModel {
  speakerId: number;
  speakerName: string;
  description: string;
  imagePath: string;
  title: string;
  companyName: string
}

export interface EventScheduleModel {
  scheduleId: number;
  roomType: string;
  roomName: string;
  roomId: number;
  parentRoomId?: number;
  title: string;
  description: string;
  startDate: Date;
  endDate: Date;
  startDateUtc: Date;
  endDateUtc: Date;
  duration: string;
  eventId: number;
  scheduleStatus: string;
  roomUrl: string;
}

export interface EventHandoutsModel {
  handoutsId: number;
  extension: string;
  fileName: string;
  description: string;
  contentType: string;
  roomType: string;
  filePath: string;
  fileGuid: string;
  roomName: string;
  isAccessible: boolean;
  roomNames: string[];
  roomIds: number[];
}

export interface EventTicketModel {
  ticketId: number;
  ticketEventId: number;
  ticketName: string;
}

export interface EventModel {
  eventId: number;
  virtualEventId: number;
  eventTitle: string;
  eventDescription?: string;
  category?: string;
  duration?: number;
  organizerId: number;
  organizerName: string;
  eventUrl: string;
  eventStartDateUtc: Date;
  eventEndDateUtc: Date;
  backgroundImagePath: string;
  eventImageUrl: string;
  donationButtonText: string;
  donationButtonLink: string;
  settings: EventSettingsModel;
}

export enum EnumScheduleStatus {
  'inProgress' = 'In progress',
  'upcoming' = 'Upcoming',
  'closed' = 'Closed'
}

export interface RoomNavigationModel {
  roomId: number;
  roomName: string;
  roomType: RoomType;
  displayOrder: number | null;
  isEnabled: boolean;
  children: RoomNavigationModel[];
}

export interface EventPollModel {
  roomId: number;
  eventId: number;
  pollId: number;
  userId: number;
  userAnwerId: number;
  question: string;
  isRequired: boolean;
  displayNow: boolean;
  displayResultToAttendees: boolean;
  displayTimeRemaining: boolean;
  startDateUtc: Date;
  expiryDateUtc: Date;
  updatedDateUtc: Date;
  answerOptions: PollAnswer[];
  pushResult: boolean;
}

export interface PollUserAnswer {
  pollId: number;
  roomId: number;
  userAnswerId: number;
  updatedDateUtc: Date;
}

export interface PollAnswerReport {
  pollAnswer: string;
  percentage: number;
}

export interface PollAnswer {
  answerId: number;
  answer: string;
}

export class CustomizationInfo { 
   faviconUrl: string
   logoImageUrl: string
   roomBackgroundImageUrl: string
   standbyBackgroundImageUrl: string
   trademarkText: string
}