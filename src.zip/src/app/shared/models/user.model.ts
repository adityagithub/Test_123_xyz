import {
  IAgoraRTCRemoteUser,
  ICameraVideoTrack,
  ILocalVideoTrack,
  IMicrophoneAudioTrack,
  IRemoteAudioTrack,
  IRemoteVideoTrack,
  UID
} from 'agora-rtc-sdk-ng';
import { EventService } from 'src/app/shared/services/event.service';
import { SharedService } from '../services/shared.service';
const BOT_USER_NAME = "FW.BOT.USERNAME.FIRSTNAME";

export type UserRoleType = 'host' | 'co_host' | 'presenter' | 'attendee';
export enum UserRoleAction {
  'none' = 0,
  'make_attendee' = 1,
  'make_presenter' = 2,
  'make_cohost' = 3,
  'remove_cohost' = 4
}

export enum UserStatusEnum {
  'none' = -1,
  'offline' = 0,
  'online' = 1,
  'away' = 2,
  'presenting' = 3,
  'busy' = 4,
  'inacall' = 5
}

export interface UserRoleModel {
  userId: number;
  userRoleId: number,
  systemName: UserRoleType,
  isEnabled: boolean
}

export class UserModel implements IAgoraRTCRemoteUser {

  constructor(p: UserModel) {
    this.userId = p.userId;
    this.title = p.title;
    this.firstName = p.firstName;
    this.lastName = p.lastName;
    this.fullName = p.fullName;
    this.avatar = p.avatar;
    this.userRoles = p.userRoles;
    this.about = p.about;
    this.email = p.email;
    this.status = p.status;
    this.phone = p.phone;
    this.unread = p.unread;
    this.currentRole = p.currentRole;
    this.pinned = p.pinned ?? false;
    this.roomId = p.roomId
    this.roomName = p.roomName;
    this.raisedHand = p.raisedHand;
    this.nickName = p.nickName;
    this.profileImageName = p.profileImageName;
    this.token = p.token;
    this.uniqueUrl = p.uniqueUrl;

    this.uid = p.uid;
    this.audioTrack = p.audioTrack;
    this.videoTrack = p.videoTrack;
    this.localAudioTrack = p.localAudioTrack;
    this.localVideoTrack = p.localVideoTrack;
    this.localScreenTrack = p.localScreenTrack;
    this.hideFromScreen = p.hideFromScreen ?? false;

    this.hasAudio = p.hasAudio ?? false;
    this.hasVideo = p.hasVideo ?? false;
    this.hasScreen = p.hasScreen ?? false;
    this.volumeLevel = p.volumeLevel;
    this.ticketOrderId = p.ticketOrderId;
  }

  uid: UID;
  audioTrack?: IRemoteAudioTrack;
  videoTrack?: IRemoteVideoTrack;

  localAudioTrack: IMicrophoneAudioTrack;
  localVideoTrack: ICameraVideoTrack;
  localScreenTrack: ILocalVideoTrack;
  volumeLevel: number;

  hasAudio: boolean;
  hasVideo: boolean;
  hasScreen: boolean;

  userId: number;
  title: string;
  firstName: string;
  lastName: string;
  fullName: string;
  avatar: string;
  email: string;
  phone: string;
  about: string;
  nickName: string;
  profileImageName: string;

  status: UserStatusEnum;
  userRoles: UserRoleModel[];
  unread: number;
  currentRole: UserRoleType;
  pinned: boolean;
  roomId: number;
  roomName: string;
  raisedHand: boolean;
  hideFromScreen: boolean;
  uniqueUrl: string;
  token: string;
  ticketOrderId: string;

  getFullName(excludeNickname: boolean = false): string {
    let fName = this.firstName + ' ' + this.lastName;

    if (!excludeNickname) {
      if (EventService.instance?.isNicknameEnabled()) {
        if (EventService.instance.isCurrentUserHostOrCohost()) {
          if (this.nickName) {
            fName = fName + ` (${this.nickName})`;
          }
          return fName;
        }
        fName = this.nickName ?? fName;
      }
    }

    return fName;
  }

  getNickname(): string {
    let name = '';
    if (EventService.instance?.isNicknameEnabled()) {
      name = this.nickName;
    }
    return name;
  }

  get alt(): string {
    let fName = this.firstName + ' ' + this.lastName;
    if (EventService.instance?.isNicknameEnabled()) {
      if (!EventService.instance.isCurrentUserHostOrCohost()) {
        fName = this.nickName ?? fName;
      }
    }
    return fName.match(/(\b\S)?/g).join("").match(/(^\S|\S$)?/g).join("").toUpperCase();
  }

  isHost(): boolean {
    const roleType: UserRoleType = 'host'
    return this.userRoles.some((role) => {
      return role.isEnabled && role.systemName === roleType;
    });
  }

  isCohost(): boolean {
    const roleType: UserRoleType = 'co_host'
    return this.userRoles.some((role) => {
      return role.isEnabled && role.systemName === roleType;
    });
  }

  isHostOrCoHost(): boolean {
    const roles: UserRoleType[] = ['host', 'co_host'];
    return this.userRoles.some((role) => {
      return role.isEnabled && roles.includes(role.systemName);
    });
  }

  isPresenter(): boolean {
    const roleType: UserRoleType = 'presenter'
    return this.userRoles.some((role) => {
      return role.isEnabled && role.systemName === roleType;
    });
  }

  isAttendee(): boolean {
    const roleType: UserRoleType = 'attendee'
    return this.userRoles.some((role) => {
      return role.isEnabled && role.systemName === roleType;
    });
  }

  isOnline(): boolean {
    return this.status == UserStatusEnum.online || this.status == UserStatusEnum.inacall ||
      this.status == UserStatusEnum.busy || this.status == UserStatusEnum.presenting;
  }

  isSystemUser(): boolean {
    return this.firstName == BOT_USER_NAME
  }

  get playerId(): string {
    return 'stream_' + this.userId.toString()
  }

  getAvatarUrl(resourceBaseUrl: string): string {
    if (!this.avatar) { return undefined; }
    return resourceBaseUrl + '/Images/ECImages/' + this.avatar;
  }

  get roleName(): UserRoleType {
    if (this.isHost()) { return 'host'; }
    if (this.isCohost()) { return 'co_host'; }
    if (this.isPresenter()) { return 'presenter'; }
    if (this.isAttendee()) { return 'attendee'; }
  }

  isJoinFromGenericLink(): boolean {
    return !this.ticketOrderId && !this.isHost();
  }
}

export interface UserConnectionInfo {
  userId: string;
  isConnected: boolean;
  ipAddress?: any;
}


export interface ChangeRoleRequest extends UserRoleModel {
  action: UserRoleAction
}

export interface ChangeRoleResponse {
  status: boolean;
  updatedRoles: UserRoleModel[];
}

export interface MuteAttendeeRequest {
  attendeeId: number;
  mute: boolean
}

export interface MuteAttendeeResponse {
  status: boolean;
}

export interface ValidateNickNameResponse {
  available: boolean;
  suggestions: string[];
  status: boolean;
}
