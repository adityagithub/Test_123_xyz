import { InMemoryDbService } from 'angular-in-memory-web-api';

import { ProjectDashboardDb } from 'app/mock-data/dashboard-project';
import { AnalyticsDashboardDb } from 'app/mock-data/dashboard-analytics';
import { ECommerceMockData } from 'app/mock-data/e-commerce';
import { TodoMockData } from 'app/mock-data/todo';
import { SearchMockData } from 'app/mock-data/search';
import { IconsMockData } from 'app/mock-data/icons';
import { QuickPanelMockData } from 'app/mock-data/quick-panel';

export class MockDataService implements InMemoryDbService
{
    createDb(): any
    {
        return {
            'project-dashboard-projects' : ProjectDashboardDb.projects,
            'project-dashboard-widgets'  : ProjectDashboardDb.widgets,
            'analytics-dashboard-widgets': AnalyticsDashboardDb.widgets,
            'e-commerce-products' : ECommerceMockData.products,
            'todo-todos'  : TodoMockData.todos,
            'todo-filters': TodoMockData.filters,
            'todo-tags'   : TodoMockData.tags,
            'search': SearchMockData.search,
            'icons': IconsMockData.icons,
            'quick-panel-notes' : QuickPanelMockData.notes,
            'quick-panel-events': QuickPanelMockData.events
        };
    }
}
