import { AdgoNavigation } from 'app/core/types';

export const navigation: AdgoNavigation[] = [

    {
        id: 'main',
        title: 'Main',
        type: 'group',
        icon: '',
        children: [
            {
                id: 'home',
                title: 'Home',
                type: 'item',
                icon: 'home',
                url: '/admin/dashboards/analytics'
            },
            {
                id: 'customerQuote',
                title: 'Customer Quote',
                type: 'item',
                icon: 'dashboard',
                url: '/admin/dashboards/project'
            },
            {
                id: 'billing',
                title: 'Billing and Usage',
                translate: 'NAV.TODO',
                type: 'item',
                icon: 'check_box',
                url: '/admin/todo'
            }
            ,
            {
                id: 'reports',
                title: 'Reports',
                type: 'item',
                icon: 'notes',
                url: '/admin/dashboards/project'
            },
            {
                id: 'products',
                title: 'Products',
                type: 'item',
                icon: 'notes',
                url: '/admin/dashboards/project'
            },
            {
                id: 'companyProfile',
                title: 'Company Profile',
                type: 'item',
                icon: 'notes',
                url: '/admin/dashboards/project'
            },
        ]
    },
    {
        id: 'pages',
        title: 'Utilities',
        type: 'group',
        icon: '',
        children: [
            {
                id: 'help',
                title: 'Help',
                type: 'item',
                icon: 'help',
                url: '/pages/errors/error-404'
            },
            {
                id: 'permission',
                title: 'Permission',
                type: 'item',
                icon: 'settings',
                url: '/admin/dashboards/project'
            },
            {
                id: 'settings',
                title: 'Settings',
                type: 'item',
                icon: 'settings',
                url: '/admin/dashboards/project'
            }
        ]
    }
];
