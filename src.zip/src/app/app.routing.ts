import { Route } from '@angular/router'
import { InitialDataResolver } from './app.resolvers'
import { LayoutComponent } from './layout/layout.component'
import { AuthGuard } from './modules/auth/guards/auth.guards'
import { AuthComponent } from './modules/auth/auth.component'

export const routes: Route[] = [
  {
    path: 'fireworks/:id/:t',
    canActivate: [AuthGuard],
    canActivateChild: [AuthGuard],
    component: LayoutComponent,
    resolve: {
      initialData: InitialDataResolver
    },
    children: [
      {
        path: '',
        pathMatch: 'full',
        loadChildren: () => import('./modules/initial.redirect.module').then(m => m.InitialRedirectModule)
      },
      {
        path: 'customization',
        loadChildren: () =>  import('./modules/warroom/customization/customization.module').then(m => m.CustomizationModule)
      },
      {
        path: 'recordings',
        loadChildren: () => import('./modules/warroom/recordings/recordings.module').then(m => m.RecordingModule)
      },
      {
        path: 'war-room',
        loadChildren: () => import('./modules/warroom/warroom.module').then(m => m.WarroomModule)
      },
      {
        /* Lobby Room Route */
        path: 'lobby',
        loadChildren: () => import('./modules/initial.redirect.module').then(m => m.InitialRedirectModule)
      },
      {
        /* Lobby Room Route */
        path: 'reception',
        loadChildren: () => import('./modules/initial.redirect.module').then(m => m.InitialRedirectModule)
      },
      {
        /* Lobby Room Route */
        path: 'r/:roomId/:room',
        loadChildren: () => import('./modules/rooms/lobby/lobby.module').then(m => m.LobbyModule) 
      },
      {
        /* Stage, Keynote, GreenRoom, CustomRoom Route */
        path: 's/:roomId/:room',
        loadChildren: () => import('./modules/rooms/room/room.module').then(m => m.RoomModule)
      },
      {
        /* Private Room */
        path: 'p/:roomtype/:roomId/:room',
        loadChildren: () => import('./modules/rooms/room/room.module').then(m => m.RoomModule)
      },
      {
        /* Breakout Room */
        path: 'b/:roomtype/:roomId/:room',
        loadChildren: () => import('./modules/rooms/room/room.module').then(m => m.RoomModule) 
      },
      {
        /* Sessions, Networking, Expo Room Route */
        path: 'm/:roomId/:room',
        loadChildren: () => import('./modules/rooms/list-view/list.module').then(m => m.RoomListModule) 
      },
      {
        path: '**',
        loadChildren: () => import('./modules/pages/errors/404/error-404.module').then(m => m.Error404Module) 
      }
    ]
  },
  {
    path: 'account/:id/login',
    component: AuthComponent
  },
  {
    path: ':id/login',
    pathMatch: 'full',
    component: AuthComponent
  },
  {
    path: ':id',
    component: AuthComponent
  },
  {
    path: '**',
    loadChildren: () => import('./modules/pages/errors/404/error-404.module').then(m => m.Error404Module)
  }
]
