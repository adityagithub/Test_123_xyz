import { FwNavigation } from 'src/app/core/types'

export const appNavigation: FwNavigation[] = [
  {
    id: 'admin',
    title: 'For Organizer',
    type: 'group',
    icon: 'apps',
    children: [
      {
        id: 'branding',
        title: 'Customize',
        type: 'item',
        icon: 'branding',
        url: 'customization'
      },
      {
        id: 'recordings',
        title: 'Recordings',
        type: 'item',
        icon: 'recording',
        url: 'recordings'
      },
      {
        id: 'warroom',
        title: 'War Room',
        type: 'item',
        icon: 'warroom',
        url: 'war-room'
      }
    ]
  },

  {
    id: 'rooms',
    title: 'Rooms',
    type: 'group',
    icon: 'apps',
    children: [

    ]
  }
];
