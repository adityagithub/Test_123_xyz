
export default function clsPrefix(classes: string) {
    let modifiedClasses: string[] = [];
    const prefix = 'tw-';
    classes.split(' ').forEach(c => {

        /*  if (c.includes(':')) {
             let first = c.split(':')[0];
             let second = prefix + c.split(':')[1];
             modifiedClasses.push(first + ':' + second);
         } else {
             modifiedClasses.push(prefix + c)
         } */

        modifiedClasses.push(prefix + c)

    });
    return modifiedClasses.join(' ');
}