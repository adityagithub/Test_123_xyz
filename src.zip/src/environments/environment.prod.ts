export const environment = {
  production: true, 
  idleTimeout: 1800, // secconds , 30 min,
};
