import React from 'react';
import { h } from 'preact';
import { createRoot } from 'react-dom/client';
import { IWidgetConfig } from '../widget/widget.config';
import { widgetType } from '../widget/widget.types';
import HtmlWidgetComponent from './html.component';

const widgetDivs = document.querySelectorAll("[data-widget='emf']");
widgetDivs.forEach(div => {
    console.log(div);
    const attr = div.getAttribute('data-type');
    if (attr == widgetType.html) {
        const root = createRoot(div);
        const config = {
            height: div.clientHeight,
            width: div.clientWidth,
            attr: div.getAttribute('data-attr'),
            type: widgetType.html
        } as IWidgetConfig;
        root.render(
            <React.StrictMode>
                <HtmlWidgetComponent config={config} />
            </React.StrictMode>,
        );
    }
});