import { IWidget } from "../widget/widget.config";
import { Listbox } from "@headlessui/react";
import { ChevronUpDownIcon, CheckIcon, ArrowPathIcon } from "@heroicons/react/24/outline";
import WidgetMenu from "../common/widgetMenu";
import { useState } from "react";

const people = [
    { name: 'Wade Cooper' },
    { name: 'Arlene Mccoy' },
    { name: 'Devon Webb' },
    { name: 'Tom Cook' },
    { name: 'Tanya Fox' },
    { name: 'Hellen Schmidt' },
]


const HtmlWidgetComponent = (props: IWidget) => {
    const [openMenu, setOpenMenu] = useState(false);
    const [selected, setSelected] = useState(people[0]);

    return (
        <div key="name" className="adg-group adg-relative adg-shadow adg-rounded adg-p-2">
            <div className="adg-flex adg-items-center adg-place-content-between adg-pb-2">
                <div className="adg-flex adg-justify-start adg-min-w-[180px]">
                    <Listbox value={selected} onChange={setSelected}>
                        <div className="adg-relative adg-w-full">
                            <Listbox.Button className="adg-relative adg-w-full adg-cursor-default adg-rounded-lg adg-bg-white adg-py-2 adg-pl-3 adg-pr-8 adg-text-left  focus:adg-outline-none focus-visible:adg-border-indigo-500 focus-visible:adg-ring-2 focus-visible:adg-ring-white focus-visible:adg-ring-opacity-75 focus-visible:adg-ring-offset-2 focus-visible:adg-ring-offset-orange-300 sm:adg-text-sm">
                                <span className="adg-block adg-truncate">{selected.name}</span>
                                <span className="adg-pointer-events-none adg-absolute adg-inset-y-0 adg-right-0 adg-flex adg-items-center adg-pr-2">
                                    <ChevronUpDownIcon className="adg-h-4 adg-w-4 adg-text-gray-400" aria-hidden="true" />
                                </span>
                            </Listbox.Button>
                            <Listbox.Options className="adg-absolute adg-mt-1 adg-max-h-60 adg-w-full adg-overflow-auto adg-rounded-md adg-bg-white adg-py-1 adg-text-base adg-shadow-lg adg-ring-1 adg-ring-black adg-ring-opacity-5 focus:adg-outline-none sm:adg-text-sm">
                                {people.map((person, personIdx) => (
                                    <Listbox.Option
                                        key={personIdx}
                                        className={({ active }) =>
                                            `adg-relative adg-cursor-default adg-select-none adg-py-2 adg-pl-10 adg-pr-4 ${active ? 'adg-bg-amber-100 adg-text-amber-900' : 'adg-text-gray-900'
                                            }`
                                        }
                                        value={person}
                                    >
                                        {({ selected }) => (
                                            <>
                                                <span
                                                    className={`adg-block adg-truncate ${selected ? 'adg-font-medium' : 'adg-font-normal'
                                                        }`}
                                                >
                                                    {person.name}
                                                </span>
                                                {selected ? (
                                                    <span className="adg-absolute adg-inset-y-0 adg-left-0 adg-flex adg-items-center adg-pl-3 adg-text-amber-600">
                                                        <CheckIcon className="adg-h-5 adg-w-5" aria-hidden="true" />
                                                    </span>
                                                ) : null}
                                            </>
                                        )}
                                    </Listbox.Option>
                                ))}
                            </Listbox.Options>
                        </div>
                    </Listbox>
                </div>
                <div className="adg-flex adg-items-center adg-justify-end adg-w-1/2">
                    <button onClick={() => { setOpenMenu(true) }}
                        type="button" className="adg-p-2 adg-text-gray-500 focus:adg-outline-none focus-visible:adg-border-indigo-500 focus-visible:adg-ring-2 focus-visible:adg-ring-white focus-visible:adg-ring-opacity-75 focus-visible:adg-ring-offset-2 focus-visible:adg-ring-offset-orange-300">
                        <ArrowPathIcon className="adg-h-5 adg-w-5" aria-hidden="true" />
                    </button>
                    <WidgetMenu open={openMenu} />
                </div>
            </div>
            <div className="adg-h-80 adg-w-full adg-overflow-hidden adg-rounded-lg adg-bg-white sm:adg-aspect-w-2 sm:adg-aspect-h-1 lg:adg-aspect-w-1 lg:adg-aspect-h-1">

                <h1>Dnb Widget Component</h1>

            </div>
            <p className="adg-text-base adg-font-semibold adg-text-gray-900 adg-py-4">
                This is a sample powerbi embed example.</p>
        </div>
    )
}

export default HtmlWidgetComponent;