import { Fragment } from 'react'
import { Menu, Transition } from '@headlessui/react'
import { ChevronDownIcon, EllipsisVerticalIcon } from '@heroicons/react/20/solid'
import { AdjustmentsHorizontalIcon } from '@heroicons/react/24/outline'

export interface WidgetMenuProps {
  open: boolean
}

const WidgetMenu = (props: WidgetMenuProps) => {
  return (
    <Menu as="div" className="adg-relative adg-inline-block adg-text-left adg-z-10">
      <Menu.Button className="adg-p-2 adg-text-gray-500 hover:adg-text-gray-800 focus:adg-outline-none focus-visible:adg-border-indigo-500 focus-visible:adg-ring-2 focus-visible:adg-ring-white focus-visible:adg-ring-opacity-75 focus-visible:adg-ring-offset-2 focus-visible:adg-ring-offset-orange-300">
        <AdjustmentsHorizontalIcon className="adg-h-5 adg-w-5" aria-hidden="true" />
      </Menu.Button>
      <Menu.Items className="adg-absolute adg-right-0 adg-z-10 adg-mt-1 adg-w-72 adg-origin-top-right adg-rounded-md adg-bg-white adg-shadow-lg adg-ring-1 adg-ring-black adg-ring-opacity-5 focus:adg-outline-none">
        <div className="md:adg-grid md:adg-grid-cols-1 adg-z-10">
          <div className="adg-space-y-6 adg-bg-white adg-px-4 adg-py-3 sm:adg-p-6 adg-z-10">
            <fieldset>
              <div className="adg-text-base adg-font-medium adg-text-gray-900" aria-hidden="true">
                Settings
              </div>
              <div className="adg-mt-4 adg-space-y-4">
                <div className="adg-flex adg-items-start">
                  <div className="adg-flex adg-h-5 adg-items-center">
                    <input
                      id="comments"
                      name="comments"
                      type="checkbox"
                      className="adg-h-4 adg-w-4 adg-rounded adg-border-gray-300 adg-text-indigo-600 focus:adg-ring-indigo-500"
                    />
                  </div>
                  <div className="adg-ml-3 adg-text-sm">
                    <label htmlFor="comments" className="adg-font-medium adg-text-gray-700 adg-mb-0">
                      Comments
                    </label>
                  </div>
                </div>
              </div>
            </fieldset>
            <fieldset>
              <legend className="adg-contents adg-text-base adg-font-medium adg-text-gray-900">Push Notifications</legend>
              <p className="adg-text-sm adg-text-gray-500">These are delivered via SMS to your mobile phone.</p>
              <div className="adg-mt-4 adg-space-y-4">
                <div className="adg-flex adg-items-center">
                  <input
                    id="push-everything"
                    name="push-notifications"
                    type="radio"
                    className="adg-h-4 adg-w-4 adg-border-gray-300 adg-text-indigo-600 focus:adg-ring-indigo-500"
                  />
                  <label htmlFor="push-everything" className="adg-ml-3 adg-block adg-text-sm adg-font-medium adg-text-gray-700 adg-mb-0">
                    Everything
                  </label>
                </div>
                <div className="adg-flex adg-items-center">
                  <input
                    id="push-email"
                    name="push-notifications"
                    type="radio"
                    className="adg-h-4 adg-w-4 adg-border-gray-300 adg-text-indigo-600 focus:adg-ring-indigo-500"
                  />
                  <label htmlFor="push-email" className="adg-ml-3 adg-block text-sm adg-font-medium adg-text-gray-700 adg-mb-0">
                    Same as email
                  </label>
                </div>
              </div>
            </fieldset>
          </div>
          <div className="adg-bg-gray-50 adg-px-4 adg-py-2 adg-text-right sm:adg-px-6">
            <button
              type="submit"
              className="adg-inline-flex adg-justify-center adg-rounded-md adg-border adg-border-transparent adg-bg-amber-500 adg-py-2 adg-px-4 adg-text-sm adg-font-medium adg-text-white adg-shadow-sm hover:adg-bg-amber-600 focus:adg-outline-none focus:adg-ring-2 focus:adg-ring-indigo-500 focus:adg-ring-offset-2">
              Save
            </button>
          </div>
        </div>
      </Menu.Items>
    </Menu>
  )
}

export default WidgetMenu;
