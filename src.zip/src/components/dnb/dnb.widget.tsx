import React from 'react';
import { createRoot } from 'react-dom/client';
import { IWidgetConfig } from '../widget/widget.config';
import { widgetType } from '../widget/widget.types';
import DnbWidgetComponent from './dnb.component';

const widgetDivs = document.querySelectorAll("[data-widget='emf']");
widgetDivs.forEach(div => {
    const attr = div.getAttribute('data-type');
    if (attr == widgetType.dnb) {
        const root = createRoot(div);
        const config = {
            height: div.clientHeight,
            width: div.clientWidth,
            attr: div.getAttribute('data-attr'),
            type: widgetType.dnb
        } as IWidgetConfig;
        root.render(
            <React.StrictMode>
                <DnbWidgetComponent config={config} />
            </React.StrictMode>,
        );
    }
});