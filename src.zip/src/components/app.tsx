import ChartWidgetComponent from './chart/chart.component';
import DnbWidgetComponent from './dnb/dnb.component';
import HtmlWidgetComponent from './html/html.component';
import PowerbiWidgetComponent from './powerbi/powerbi.component';
import { widgetType } from './widget/widget.types';

const App = (props: any) => {
  return (
    <>
      <div className="container">
        <div className="row my-4">
          <div className="col">
            <PowerbiWidgetComponent config={{ attr: '', height: 0, type: widgetType.powerbi, width: 0 }} />
          </div>
        </div>
        <div className="row my-4">
          <div className="col-5">
            <ChartWidgetComponent config={{ attr: '', height: 0, type: widgetType.chart, width: 0 }} />
          </div>
          <div className="col-7">
            <HtmlWidgetComponent config={{ attr: '', height: 0, type: widgetType.dnb, width: 0 }} />
          </div>
        </div>

        <div className="row my-4">
          <div className="col-7">
            <HtmlWidgetComponent config={{ attr: '', height: 0, type: widgetType.dnb, width: 0 }} />
            <div className="my-4">
              <HtmlWidgetComponent config={{ attr: '', height: 0, type: widgetType.dnb, width: 0 }} />
            </div>
          </div>
          <div className="col-5">
            <DnbWidgetComponent config={{ attr: '', height: 0, type: widgetType.dnb, width: 0 }} />
          </div>
        </div>
      </div>
    </>
  )
}

export default App;
