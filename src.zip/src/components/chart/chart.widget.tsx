import React from 'react';
import { createRoot } from 'react-dom/client';
import { IWidgetConfig } from '../widget/widget.config';
import { widgetType } from '../widget/widget.types';
import ChartWidgetComponent from './chart.component';

const widgetDivs = document.querySelectorAll("[data-widget='emf']");
widgetDivs.forEach(div => {
    const attr = div.getAttribute('data-type');
    if (attr == widgetType.chart) {
        const root = createRoot(div);
        const config = {
            height: div.clientHeight,
            width: div.clientWidth,
            attr: div.getAttribute('data-attr'),
            type: widgetType.chart
        } as IWidgetConfig;
        root.render(
            <React.StrictMode>
                <ChartWidgetComponent config={config} />
            </React.StrictMode>,
        );
    }
});