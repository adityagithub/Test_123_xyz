import * as am5 from "@amcharts/amcharts5";
import am5themes_Animated from "@amcharts/amcharts5/themes/Animated";
import * as am5xy from "@amcharts/amcharts5/xy";
import { Listbox } from "@headlessui/react";
import { ArrowPathIcon, CheckIcon, ChevronUpDownIcon } from "@heroicons/react/24/outline";
import { useLayoutEffect, useState } from "react";
import { IWidget } from "../widget/widget.config";
import WidgetMenu from "../common/widgetMenu";

const people = [
    { name: 'Wade Cooper' },
    { name: 'Arlene Mccoy' },
    { name: 'Devon Webb' },
    { name: 'Tom Cook' },
    { name: 'Tanya Fox' },
    { name: 'Hellen Schmidt' },
]

const products = [
    {
        id: 1,
        name: 'Throwback Hip Bag',
        href: '#',
        color: 'Salmon',
        price: '$90.00',
        quantity: 1,
        imageSrc: 'https://tailwindui.com/img/ecommerce-images/shopping-cart-page-04-product-01.jpg',
        imageAlt: 'Salmon orange fabric pouch with match zipper, gray zipper pull, and adjustable hip belt.',
    },
    {
        id: 2,
        name: 'Medium Stuff Satchel',
        href: '#',
        color: 'Blue',
        price: '$32.00',
        quantity: 1,
        imageSrc: 'https://tailwindui.com/img/ecommerce-images/shopping-cart-page-04-product-02.jpg',
        imageAlt:
            'Front of satchel with blue canvas body, black straps and handle, drawstring top, and front zipper pouch.',
    },
    // More products...
]



const ChartWidgetComponent = (props: IWidget) => {

    const [openMenu, setOpenMenu] = useState(false);
    const [selected, setSelected] = useState(people[0]);
    const [open, setOpen] = useState(true);
    let root: am5.Root;

    useLayoutEffect(() => {

        if (!root) {
            root = am5.Root.new("chartdiv");
            root.setThemes([am5themes_Animated.new(root)]);
        }

        let chart = root.container.children.push(
            am5xy.XYChart.new(root, {
                panY: false,
                layout: root.verticalLayout
            })
        );

        // Define data
        let data = [
            {
                category: "Research",
                value1: 1000,
                value2: 588
            },
            {
                category: "Marketing",
                value1: 1200,
                value2: 1800
            },
            {
                category: "Sales",
                value1: 850,
                value2: 1230
            }
        ];

        // Create Y-axis
        let yAxis = chart.yAxes.push(
            am5xy.ValueAxis.new(root, {
                renderer: am5xy.AxisRendererY.new(root, {})
            })
        );

        // Create X-Axis
        let xAxis = chart.xAxes.push(
            am5xy.CategoryAxis.new(root, {
                renderer: am5xy.AxisRendererX.new(root, {}),
                categoryField: "category"
            })
        );
        xAxis.data.setAll(data);

        // Create series
        let series1 = chart.series.push(
            am5xy.ColumnSeries.new(root, {
                name: "Series",
                xAxis: xAxis,
                yAxis: yAxis,
                valueYField: "value1",
                categoryXField: "category"
            })
        );
        series1.data.setAll(data);

        let series2 = chart.series.push(
            am5xy.ColumnSeries.new(root, {
                name: "Series",
                xAxis: xAxis,
                yAxis: yAxis,
                valueYField: "value2",
                categoryXField: "category"
            })
        );
        series2.data.setAll(data);

        // Add legend
        let legend = chart.children.push(am5.Legend.new(root, {}));
        legend.data.setAll(chart.series.values);

        // Add cursor
        chart.set("cursor", am5xy.XYCursor.new(root, {}));
    }, []);

    return (

        <div key="name" className="adg-group adg-relative adg-shadow adg-rounded adg-p-2" >
            <div className="adg-flex adg-items-center adg-place-content-between adg-pb-2">
                <div className="adg-flex adg-justify-start adg-min-w-[180px]">
                    <Listbox value={selected} onChange={setSelected}>
                        <div className="adg-relative adg-w-full">
                            <Listbox.Button className="adg-relative adg-w-full adg-cursor-default adg-rounded-lg adg-bg-white adg-py-2 adg-pl-3 adg-pr-8 adg-text-left  focus:adg-outline-none focus-visible:adg-border-indigo-500 focus-visible:adg-ring-2 focus-visible:adg-ring-white focus-visible:adg-ring-opacity-75 focus-visible:adg-ring-offset-2 focus-visible:adg-ring-offset-orange-300 sm:adg-text-sm">
                                <span className="adg-block adg-truncate">{selected.name}</span>
                                <span className="adg-pointer-events-none adg-absolute adg-inset-y-0 adg-right-0 adg-flex adg-items-center adg-pr-2">
                                    <ChevronUpDownIcon className="adg-h-4 adg-w-4 adg-text-gray-400" aria-hidden="true" />
                                </span>
                            </Listbox.Button>
                            <Listbox.Options className="adg-absolute adg-mt-1 adg-z-10 adg-max-h-60 adg-w-full adg-overflow-auto adg-rounded-md adg-bg-white adg-py-1 adg-text-base adg-shadow-lg adg-ring-1 adg-ring-black adg-ring-opacity-5 focus:adg-outline-none sm:adg-text-sm">
                                {people.map((person, personIdx) => (
                                    <Listbox.Option
                                        key={personIdx}
                                        className={({ active }) =>
                                            `adg-relative adg-cursor-default adg-select-none adg-py-2 adg-pl-10 adg-pr-4 ${active ? 'adg-bg-amber-100 adg-text-amber-900' : 'adg-text-gray-900'
                                            }`
                                        }
                                        value={person}>
                                        {({ selected }) => (
                                            <>
                                                <span
                                                    className={`adg-block adg-truncate ${selected ? 'adg-font-medium' : 'adg-font-normal'
                                                        }`}
                                                >
                                                    {person.name}
                                                </span>
                                                {selected ? (
                                                    <span className="adg-absolute adg-inset-y-0 adg-left-0 adg-flex adg-items-center adg-pl-3 adg-text-amber-600">
                                                        <CheckIcon className="adg-h-5 adg-w-5" aria-hidden="true" />
                                                    </span>
                                                ) : null}
                                            </>
                                        )}
                                    </Listbox.Option>
                                ))}
                            </Listbox.Options>
                        </div>
                    </Listbox>
                </div>
                <div className="adg-flex adg-items-center adg-justify-end adg-w-1/2">
                    <button onClick={() => { setOpenMenu(true) }}
                        type="button" className="adg-p-2 adg-text-gray-500 focus:adg-outline-none focus-visible:adg-border-indigo-500 focus-visible:adg-ring-2 focus-visible:adg-ring-white focus-visible:adg-ring-opacity-75 focus-visible:adg-ring-offset-2 focus-visible:adg-ring-offset-orange-300">
                        <ArrowPathIcon className="adg-h-5 adg-w-5" aria-hidden="true" />
                    </button>
                    <WidgetMenu open={openMenu} />
                </div>
            </div>
            <div className="adg-h-80 adg-w-full adg-overflow-hidden adg-rounded-lg adg-bg-white sm:adg-aspect-w-2 sm:adg-aspect-h-1 lg:adg-aspect-w-1 lg:adg-aspect-h-1">

                <div id="chartdiv" className="adg-h-full adg-w-full adg-object-cover adg-object-center"></div>

            </div>
            <p className="adg-text-base adg-font-semibold adg-text-gray-900 adg-py-4">
                This is a sample chart embed example.</p>
        </div>
    )
}

export default ChartWidgetComponent;

