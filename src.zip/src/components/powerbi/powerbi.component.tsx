import { PowerBIEmbed } from "powerbi-client-react";
import { IWidget } from "../widget/widget.config";
import { models, Report } from "powerbi-client"
import { Listbox } from "@headlessui/react";
import { ChevronUpDownIcon, CheckIcon, ArrowPathIcon } from "@heroicons/react/24/outline";
import WidgetMenu from "../common/widgetMenu";
import { useState } from "react";
import React from "react";

const people = [
    { name: 'Wade Cooper' },
    { name: 'Arlene Mccoy' },
    { name: 'Devon Webb' },
    { name: 'Tom Cook' },
    { name: 'Tanya Fox' },
    { name: 'Hellen Schmidt' },
]

const PowerbiWidgetComponent = (props: IWidget) => {
    const [openMenu, setOpenMenu] = useState(false);
    const [selected, setSelected] = useState(people[0]);
    const token = 'H4sIAAAAAAAEACWWtw7syBFF_-WlFEBy6AVsQO_90Gb03nsu9O-albIOCmjgdte55-8_VvL0U5L_-fcfP02n1Sga7hQBMtoS2NncujEoI_yybxwq7rOFhCr0dCPK1MvHyj4-hmgWNloCM2m_FTwWCcEg6zoZ4CekGQhL9oPzcEw4RX9v1H2xO4F8mCqOrQ6b5YMw0tI6ieIksQccniaQyzZIuFV-P2obeGAOV_uYXwF0Cff4mBAXPwn-VTGBhUre4n0luVKFJ0w_7ycVNqOav-yED1LS6IBq9HNx58A4yjrfZG43vuMUlsr7yRydAQ2K2wB4pJ1wFFhmTySx8SERcpVWYyB6P0v1JpY9_5hU3IOd5h8P7Us1s0nmo2HGrsKh6LxQFJeL6ciDlF0jYSP1YTdIunyp1wjB9m5KK6CeKrkWqqeq1AB4NxGQItC8vcf2dQou0dUD00u0Q-FzbzOpD4FyZ98SKn9FFqSGx7woZpPOXZ_uJOEo8yEyOzXP1VYpH3V0s0LmGW9o1xmbshsbU-ra9_4GXoRo9NcsbxI4l2faPcgZkxNBnQaXMIT072sRGRGhmE6ce4pEHZ76VLry5ss-4EQMSZXVDFHO4Gk353q7OwkAcLxpmpfZFBdRrHk6IaN8pUiymjS-bUvIRZx6xN2AV4J8D7eqDqsevhfVxxhptT09s970QqQNMIGj0fFSTgDPNxqFAnu2xT6C3K655ZwlJE2kOcopiSCnwVFz0q2p3Z7LSpdtNVXGSUSnf-gAEgXResKMPaEGjJ8xGiBav3yvkhdMg621PhyZNFjH8Seb5cET7bJYIGdnVBPK96SU6zl5xvZtMU1D4wOSd6Dz2yiDLcLbF5bsqktgQH1PJExB2t-AVqSZ_gBM3uO4hpRj6uPA6tPl5NTm8Wex0AM7IIfWgNdEEqAO1p2tsnyfgWQXWUeVdjDveJ7hJIEvTAcw5Oe7nKNp8gv4CwA9Vh_lEirGQGwm1Vu-AT6ctFLy5veF5HhkAday3sNnHqHPLqmYCZ2o899KAOEQPgCzfz1PeLig_8LFiUCpjHy2Rk2wwm0lZZGTwxCSipkKJoSL7nsTBQpeYXV6JFlXDHfy-Isa1COVuhvX1Wy93pOo96J_d-dTENS8BFDDamg2BKqC2YwmTdisUrxR5ambz6vgeTEZRvVoadNtt6CNcQdPT7mK4R7nEV6pyS-YL1uWZkp-TfXRWloEkY3MJ6IpzkNmL75Qsen5Gkc8QAh0YdZLUd9ync-Ey8TpHKysJFPQtMhZq_1AoxTZqg9F6J4DtUy5rfMENDT7W9UznJq3jXvgW3Jn1y3omkmnbnaK3YMb9rwR1JRhlc9IvoxHurn6YBVXoRdC23NvCbjh8v02PlXQpLd2V87ZEYx4lvO6K9r76AC_qQvC4tDAwZ1dRaUlTYsrRBuAxaJBBtWMwpHDxmBhPOndELh-7i-al2oD96w23JHdF9tan97AyJwA23do3EqzCqWctuCbtNndnyXkMCwu8jNnWDIruOs1IrJmbeaMGx6NBl5h1Z8Hw1rfTmHmE2MNEo_7WLBOw2H52V0G6uE748Po2KH7BOT1ywrBvaUtyxSyg6-vgSByFpxme_gY6NiMAUq-0n26R522RtRyWNo49HMhIPXqhFaPz5eyNSfSNCXkAxt8kEh18OptEyO3_JppHirFZCKBFgnrwRaq9TKZ7VjIpHrcG2M0XfcJr5VGU7tps697LhHf4Ea9W2cQpTxhUdC6Q8zVlJjMJd0bG9la08VaOJnch6SVXWhY7rM4Frzi0SNBXYLMuNgGd6u6nzMCUd1n8swWjF9GuOezyRzvQFIBcBcyO-U4TJ1OPMMTC3pOX6bk4hFYhD5G_5oweUGJXUPfWGlfLM1ot5McDvBSiu4-CBDopBPVKogjyPLEBOZZqMEibWr2n0BjtSdbGxbVIWN1TrKnBvfTTa18HPfmED2IOd1MW9U7UF5I48IPqTsNk7KG65IIpdqy4ZmiZCxdLlUXwYtU13HO-cPEArrbTF0ZRijxHUZrkuyb6qq7WHFEwve-eSH0dTG0moE11WV-111UcC4GGDFcckT6WVzU1kehvvi1F7subchhsiFXVVxa0u7qpjEzRrlvdyr5h4rDnZ945N7Q6KLFU3-l90mkPVMd0DE826h5_njvAYHcXvWB_aIH0xtVZUCswmJgczDV6ZvGoNPLOOvgbKcJC1gyWN0sNS88aC-N6eWy-vArGfSatVfaUyzEDPGK9oB2gaB1j1F-Le4ZVzWff-xd6ut3-mzOE8wWDVht5xQ5b3pLb04MeBMaDswwMuFr5l1gWB1CvSfFg7kDp5AV10Y0t-AvvT_rPFWpzsFg3GDulaS-8muFGSKjrIiWjjs49mcW43qqjeKXs7UPQ_18M5AjUqHWurw7uJL0AannceASry8FiGqiNNm0vNi1U_ubv--UQ5lgDZtGfmVmOe8jXNFvyY2Scu-Y2nmOtgX4gQD6bKePNPG_oAFyxO-W_CrFb5nNT9PP9oR6kh7lqJ-np5Dj6kxPHUOoERqRCf3XX3_-9Yddn3mf1OL5aVruUoLgbQMlh1uTJFz7DmpUgoiExf0I5jY9q3yPny4-AFuKCm9PKxSEoJ9vHbDduN1jC58e9F48rEc8O_lyYRVZfkDTqPTISYVyd5R91X6MeWxy40LRih7b0cKT3xvm45BGBPica0fyUodzYvP5blSGKtaw7lzeREOhsEApcqv6xp8Lft3YU_qSUOwLaI2VxaVfxa7Z4V50rK4IKZcqHYtYQRd9z-Y5BAU_SPWAva77pVk0u-610mF-cEU0oA-FIZLBXbmLD6o6cKmMtoXUkQdUvD7sd0DzZQ1CAf_dWt2rPFFm1VhTfYtCt8eTHfg61Of9-JNEUeVVzCEi6SAgPoO8ofp_zM9cF6vs_1J-IX_D5hPefgBgxmtGurpUrv9NuU01_sR2LX5jKlkLKE5lZDMtcSx86-rx-Z8x52j5WeguqnMfmlr34yS36LWX9IZ36MAzrgrqvWYfomHb-FYE_S7P3OuXDDySZe28yNMXd3ms89yY7qv_Q4bTWlg6ExaWlxGpZREe2urXNn2ZbcZ-ofCsEgL_VKnkCXDHhd47Ikrpxy0AHfrUVPzTtEAKD2GVFSJ1ts26A8Kr0vVt6x355QL13YT33NDbp9T4EqRJSqC500WXfwTJSsrKnaNSvl1o20gkrV0Xx3Na_GS-rHhuxb-b_7V8wb-Jr-2lqpFPESdgGCB8TSVy0o4m65rlSzknMbTQUhfwZMfBI9HwP1xtnbYcqJaQLS_rRPE_f_4__wVvtzpomgwAAA==.eyJjbHVzdGVyVXJsIjoiaHR0cHM6Ly9XQUJJLVVTLU5PUlRILUNFTlRSQUwtcmVkaXJlY3QuYW5hbHlzaXMud2luZG93cy5uZXQiLCJleHAiOjE2NzY4MjA3ODgsImFsbG93QWNjZXNzT3ZlclB1YmxpY0ludGVybmV0Ijp0cnVlfQ==';

    return (

        <div key="name" className="adg-group adg-relative adg-shadow adg-rounded adg-p-2">
            <div className="adg-flex adg-items-center adg-pb-2 adg-place-content-between md:adg-space-x-10">
                <div className="adg-flex adg-justify-start adg-min-w-[180px]">
                    <Listbox value={selected} onChange={setSelected}>
                        <div className="adg-relative adg-w-full">
                            <Listbox.Button className="adg-relative adg-w-full adg-cursor-default adg-rounded-lg adg-bg-white adg-py-2 adg-pl-3 adg-pr-8 adg-text-left  focus:adg-outline-none focus-visible:adg-border-indigo-500 focus-visible:adg-ring-2 focus-visible:adg-ring-white focus-visible:adg-ring-opacity-75 focus-visible:adg-ring-offset-2 focus-visible:adg-ring-offset-orange-300 sm:adg-text-sm">
                                <span className="adg-block adg-truncate">{selected.name}</span>
                                <span className="adg-pointer-events-none adg-absolute adg-inset-y-0 adg-right-0 adg-flex adg-items-center adg-pr-2">
                                    <ChevronUpDownIcon className="adg-h-4 adg-w-4 adg-text-gray-400" aria-hidden="true" />
                                </span>
                            </Listbox.Button>
                            <Listbox.Options className="adg-absolute adg-mt-1 adg-max-h-60 adg-w-full adg-overflow-auto adg-rounded-md adg-bg-white adg-py-1 adg-text-base adg-shadow-lg adg-ring-1 adg-ring-black adg-ring-opacity-5 focus:adg-outline-none sm:adg-text-sm">
                                {people.map((person, personIdx) => (
                                    <Listbox.Option
                                        key={personIdx}
                                        className={({ active }) =>
                                            `adg-relative adg-cursor-default adg-select-none adg-py-2 adg-pl-10 adg-pr-4 ${active ? 'adg-bg-amber-100 adg-text-amber-900' : 'adg-text-gray-900'
                                            }`
                                        }
                                        value={person}
                                    >
                                        {({ selected }) => (
                                            <>
                                                <span
                                                    className={`adg-block adg-truncate ${selected ? 'adg-font-medium' : 'adg-font-normal'
                                                        }`}
                                                >
                                                    {person.name}
                                                </span>
                                                {selected ? (
                                                    <span className="adg-absolute adg-inset-y-0 adg-left-0 adg-flex adg-items-center adg-pl-3 adg-text-amber-600">
                                                        <CheckIcon className="adg-h-5 adg-w-5" aria-hidden="true" />
                                                    </span>
                                                ) : null}
                                            </>
                                        )}
                                    </Listbox.Option>
                                ))}
                            </Listbox.Options>
                        </div>
                    </Listbox>
                </div>
                <div className="adg-flex adg-items-center adg-justify-end adg-w-1/2">
                    <button onClick={() => { setOpenMenu(true) }}
                        type="button" className="adg-p-2 adg-text-gray-500 focus:adg-outline-none focus-visible:adg-border-indigo-500 focus-visible:adg-ring-2 focus-visible:adg-ring-white focus-visible:adg-ring-opacity-75 focus-visible:adg-ring-offset-2 focus-visible:adg-ring-offset-orange-300">
                        <ArrowPathIcon className="adg-h-5 adg-w-5" aria-hidden="true" />
                    </button>
                    <WidgetMenu open={openMenu} />
                </div>
            </div>
            <div className="adg-h-80 adg-w-full adg-overflow-hidden adg-rounded-lg adg-bg-white sm:adg-aspect-w-2 sm:adg-aspect-h-1 lg:adg-aspect-w-1 lg:adg-aspect-h-1">
                <pre>{process.env.REACT_APP_SECRET_NAME}</pre>
                <PowerBIEmbed
                    embedConfig={{
                        type: 'report',
                        id: 'f6bfd646-b718-44dc-a378-b73e6b528204',
                        embedUrl: undefined,
                        accessToken: token,
                        tokenType: models.TokenType.Embed,
                        settings: {
                            panes: {
                                filters: {
                                    expanded: false,
                                    visible: false
                                }
                            },
                            background: models.BackgroundType.Transparent,
                        }
                    }}

                    eventHandlers={
                        new Map([
                            ['loaded', function () { console.log('Report loaded'); }],
                            ['rendered', function () { console.log('Report rendered'); }],
                            ['error', function (event) { console.log('Report error'); }]
                        ])
                    }

                    cssClassName={"adg-h-full adg-w-full adg-object-cover adg-object-center"}

                    getEmbeddedComponent={(embeddedReport) => {

                    }}
                />

            </div>
            <p className="adg-text-base adg-font-semibold adg-text-gray-900 adg-py-4">
                This is a sample powerbi embed example.</p>
        </div>
    )
}

export default PowerbiWidgetComponent;
