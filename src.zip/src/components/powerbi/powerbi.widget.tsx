import React from 'react';
import { createRoot } from 'react-dom/client';
import { IWidgetConfig } from '../widget/widget.config';
import { widgetType } from '../widget/widget.types';
import PowerbiEmbedComponent from './powerbi.component';

const widgetDivs = document.querySelectorAll("[data-widget='emf']");
widgetDivs.forEach(div => {
    const attr = div.getAttribute('data-type');
    if (attr == widgetType.powerbi) {
        const root = createRoot(div);
        const config = {
            height: div.clientHeight,
            width: div.clientWidth,
            attr: div.getAttribute('data-attr'),
            type: widgetType.powerbi
        } as IWidgetConfig;
        root.render(
            <React.StrictMode>
                <PowerbiEmbedComponent config={config} />
            </React.StrictMode>,
        );
    }
});