import { createRoot } from 'react-dom/client';
import WidgetComponent from './widget.component';

const elem = document.createElement('div');
const root = createRoot(elem);
{/* @ts-expect-error Server Component */ }
root.render(<WidgetComponent />);