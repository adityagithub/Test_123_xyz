import { widgetType } from "./widget.types";

export default class WidgetService {

    validateClient = async (apiKey: string) => {
        return await Promise.resolve(true);
    }

    getEnabledWidgetList = async (clientId: string) => {
        const enalbedList = [widgetType.chart, widgetType.powerbi];
        return await Promise.resolve(enalbedList);
    }

    getScriptParamApiKey(): string | null {
        const scripts = document.getElementsByTagName('script');
        const currentScript = scripts[scripts.length - 1];
        const query = currentScript.src.replace(/^[^\\?]+\??/, '');
        if (!query) return null;
        const urlParam = new URLSearchParams(query.toLowerCase());
        return urlParam.get('apikey');
    }
}