import { widgetType } from "./widget.types";

export interface IWidget {
    config: IWidgetConfig;
}

export interface IWidgetConfig {
    height: number;
    width: number;
    attr: string;
    type: widgetType;
}