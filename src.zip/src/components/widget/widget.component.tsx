import '../../index.css';
import WidgetService from './widget.service';

const WidgetComponent = async () => {

    const service = new WidgetService();
    const apiKey = service.getScriptParamApiKey();
    if (!apiKey) return (<><pre className='text-red-400'>Invalid Api key</pre></>);

    const validClient = await service.validateClient(apiKey);
    if (!validClient) return (<><pre className='text-red-400'>Invalid Api key</pre></>);

    if (validClient) {

        const list = await service.getEnabledWidgetList('clientId');

        list.forEach(w => {
            const wScript = document.createElement("script");
            wScript.type = 'text/javascript';
            wScript.src = `${w}.bundle.js`;
            wScript.async = true;
            document.body.appendChild(wScript);
        });
    }

    return (<></>);
}

export default WidgetComponent;
