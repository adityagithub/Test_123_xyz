
export enum widgetType {
    none = '',
    html = 'html',
    chart = 'chart',
    powerbi = 'powerbi',
    dnb = 'dnb'
}