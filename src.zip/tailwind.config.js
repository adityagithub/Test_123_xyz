/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: 'class',
  content: [
    "./src/**/*.{html,scss,ts}"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}

