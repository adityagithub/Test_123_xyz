import { Component, OnDestroy, OnInit } from '@angular/core';
import { filter, Subject, takeUntil } from 'rxjs';
import { MsalBroadcastService } from '@azure/msal-angular';
import { InteractionStatus, IPublicClientApplication } from '@azure/msal-browser';
import { AdgoAuthProviderEnum } from './adgo-central-auth-lib.models';
import { AdgoCentralAuthLibService } from './adgo-central-auth-lib.service';

@Component({
  selector: 'adgo-central-auth',
  template: '',
  styles: []
})
export class AdgoCentralAuthLibComponent implements OnInit, OnDestroy {
  private readonly _unsubscribeAll = new Subject<void>();
  constructor(
    private _centralAuthService: AdgoCentralAuthLibService) {

  }

  ngOnInit(): void {

    if (this._centralAuthService.getConfig().provider == AdgoAuthProviderEnum.MSAL) {

      let instance = this._centralAuthService.getInstance() as IPublicClientApplication;
      if (instance) {
        let _msalBroadcastService = new MsalBroadcastService(instance);
        _msalBroadcastService.inProgress$
          .pipe(
            filter((status: InteractionStatus) => status === InteractionStatus.None),
            takeUntil(this._unsubscribeAll)
          ).subscribe(() => {
            this.checkAndSetActiveAccount(instance);
          });
        instance.handleRedirectPromise().then(() => {
          const account = instance.getActiveAccount();
          if (!account) {
            instance.loginRedirect({ scopes: [] });
          }
        }).catch((err: any) => {
          console.log(err);
        });
      }
    } else if (this._centralAuthService.getConfig().provider == AdgoAuthProviderEnum.OCTA) {
      console.log('Octa provider not registered!');
    }
  }

  ngOnDestroy(): void {
    this._unsubscribeAll.next();
    this._unsubscribeAll.complete();
  }

  checkAndSetActiveAccount(instance: IPublicClientApplication) {
    let activeAccount = instance.getActiveAccount();
    if (!activeAccount && instance.getAllAccounts().length > 0) {
      let accounts = instance.getAllAccounts();
      instance.setActiveAccount(accounts[0]);
    }
  }
}
