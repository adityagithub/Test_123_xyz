import { Injectable, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ADGO_CENTRAL_AUTH_MODULE_OPTIONS, AdgoAuthProviderEnum, AdgoCentralAuthConfig, AdgoCentralAuthModuleOptions } from './adgo-central-auth-lib.models';
import { AdgoCentralAuthMsalLibService } from './adgo-central-auth-lib.msal.service';
import { AdgoCentralAuthOctaLibService } from './adgo-central-auth-lib.octa.service';

@Injectable()
export class AdgoCentralAuthLibService {

  private _config!: AdgoCentralAuthConfig;
  private _service!: AdgoCentralAuthMsalLibService | AdgoCentralAuthOctaLibService;

  constructor(
    private http: HttpClient,
    @Inject(ADGO_CENTRAL_AUTH_MODULE_OPTIONS)
    private options: AdgoCentralAuthModuleOptions
  ) {

  }

  async loadConfigAndInitialize(): Promise<AdgoCentralAuthConfig> {
    let appIdConfigPromise = new Promise<AdgoCentralAuthConfig>((resolve, reject) => {
      const url = `http://localhost:4200/api/auth/${this.options.appId}/config`;
      this.http.get<AdgoCentralAuthConfig[]>('http://localhost:4200/assets/auth-config.json')
        .subscribe({
          next: async (res) => {

            let config = res.find(r => r.appId == 'appId000');

            if (!config) throw new Error('Config not found!');

            this._config = config;

            if (config.provider == AdgoAuthProviderEnum.MSAL) {
              this._service = new AdgoCentralAuthMsalLibService();
              await this._service.loadConfigAndInitialize(config.config);
              resolve(config);
            } else {
              this._service = new AdgoCentralAuthOctaLibService();
              await this._service.loadConfigAndInitialize(config.config);
              resolve(config);
            }
          },
          error: (err) => {
            reject(err);
          }
        })
    });

    return appIdConfigPromise;
  }

  async isAuthenticated() {
    return await this._service.isAuthenticated();
  }

  async getUserAccount() {
    return await this._service.getAuthenticatedUser();
  }

  getInstance(): any {
    return this._service.getInstance();
  }

  getConfig(): AdgoCentralAuthConfig {
    return this._config;
  }
}