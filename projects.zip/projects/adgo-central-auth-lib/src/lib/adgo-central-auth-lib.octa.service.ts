import OktaAuth from '@okta/okta-auth-js';
import { AdgoOctaAuthConfig } from './adgo-central-auth-lib.models';

export class AdgoCentralAuthOctaLibService {

  private _instance!: OktaAuth;
  private _authenticated = false;

  constructor() {
  }

  async loadConfigAndInitialize(config: AdgoOctaAuthConfig): Promise<void> {

    const oktaAuth = new OktaAuth({
      issuer: 'https://{yourOktaDomain}/oauth2/default',
      clientId: '{yourClientId}',
      redirectUri: window.location.origin + '/login/callback'
    });

    this._instance = oktaAuth;
  }

  async isAuthenticated() {
    this._authenticated = await this._instance.isAuthenticated();
    return this._authenticated;
  }

  async getAuthenticatedUser() {

    if (!this._authenticated) {
      throw new Error('User not authenticated.');
    }

    let activeAccount = await this._instance.getUser();
    if (activeAccount) return activeAccount;

    throw new Error('User not found.');
  }

  getInstance(): OktaAuth {
    if (!this._instance) {
      throw new Error('OCTA instance not initialized.');
    }
    return this._instance;
  }
}