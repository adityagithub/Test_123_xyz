import { HttpClientModule } from '@angular/common/http';
import { APP_INITIALIZER, ModuleWithProviders, NgModule } from '@angular/core';
import { AdgoCentralAuthLibComponent } from './adgo-central-auth-lib.component';
import { ADGO_CENTRAL_AUTH_MODULE_OPTIONS, AdgoCentralAuthModuleOptions } from './adgo-central-auth-lib.models';
import { AdgoCentralAuthLibService } from './adgo-central-auth-lib.service';

@NgModule({
  declarations: [
    AdgoCentralAuthLibComponent
  ],
  imports: [],
  exports: [
    AdgoCentralAuthLibComponent
  ],
  providers: []
})
export class AdgoCentralAuthLibModule {
  static forRoot(options: AdgoCentralAuthModuleOptions): ModuleWithProviders<AdgoCentralAuthLibModule> {

    let initializeCentralAuthFactory = (
      service: AdgoCentralAuthLibService
    ): () => Promise<void> => {
      return async () => {
        await service.loadConfigAndInitialize();
      };
    };

    const moduleConfig = {
      ngModule: AdgoCentralAuthLibModule,
      providers: [
        { provide: ADGO_CENTRAL_AUTH_MODULE_OPTIONS, useValue: options },
        AdgoCentralAuthLibService,
        HttpClientModule,
        {
          provide: APP_INITIALIZER,
          useFactory: initializeCentralAuthFactory,
          deps: [AdgoCentralAuthLibService],
          multi: true,
        }
      ],
    };
    return moduleConfig;
  }

}
