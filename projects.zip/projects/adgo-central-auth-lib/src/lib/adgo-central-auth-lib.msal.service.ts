import {
  PublicClientApplication,
  IPublicClientApplication,
} from '@azure/msal-browser';
import { AdgoMsalAuthConfig } from './adgo-central-auth-lib.models';


export class AdgoCentralAuthMsalLibService {

  private _instance!: IPublicClientApplication;
  private _authenticated = false;


  constructor() { }

  async loadConfigAndInitialize(config: AdgoMsalAuthConfig): Promise<void> {

    if (this._instance) {
      return;
    }
    this._instance = new PublicClientApplication(config);
    await this._instance.initialize();
  }

  async isAuthenticated() {
    this._authenticated = this._instance.getAllAccounts()?.length > 0;
    return this._authenticated;
  }

  async getAuthenticatedUser() {

    if(!this._authenticated) {
      throw new Error('User not authenticated.');
    }

    let activeAccount = this._instance.getActiveAccount();
    if (activeAccount) return activeAccount;

    let allAccounts = this._instance.getAllAccounts();
    if (allAccounts?.length) return allAccounts[0];

    throw new Error('User not found.');
  }

  getInstance(): IPublicClientApplication {
    if (!this._instance) {
      throw new Error('MSAL instance not initialized.');
    }
    return this._instance;
  }
}