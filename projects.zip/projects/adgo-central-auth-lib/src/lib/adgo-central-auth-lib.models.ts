import { InjectionToken } from '@angular/core';
import { Configuration } from '@azure/msal-browser';

export interface AdgoCentralAuthModuleOptions {
  appId: string;
}

export interface AdgoMsalAuthConfig extends Configuration {

}

export interface AdgoOctaAuthConfig {
  issuer: string;
  clientId: string;
  redirectUri?: string;
}

export interface AdgoCentralAuthConfig {
  appId: string;
  provider: AdgoAuthProviderEnum.MSAL | AdgoAuthProviderEnum.OCTA | AdgoAuthProviderEnum.NONE;
  config: any;
}

export const ADGO_CENTRAL_AUTH_MODULE_OPTIONS = new InjectionToken<AdgoCentralAuthModuleOptions>('ADGO_CENTRAL_AUTH_MODULE_OPTIONS');

export enum AdgoAuthProviderEnum {
  NONE = '',
  MSAL = 'msal',
  OCTA = 'octa'
}